# Public data access and omitted large inputs

Raw sequencing reads and large downloaded objects are not bundled. The tables,
processed values and compact source inputs needed for downstream calculations
are retained. All source links below are dataset identifiers already used by
the analysis; download the released files from the source records.

| Layer | Source record | Download and processing entry points |
|---|---|---|
| Animal bulk transcriptomics | [GSE163614](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE163614) and [GSE137482](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE137482) (RNA-seq); [GSE61616](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE61616) (microarray) | `01_download_bulk_rnaseq.R`, `05_download_supplementary.R`, `06_process_rnaseq_counts.R`, `11_bulk_rnaseq_differential_analysis.R` |
| Human peripheral blood | [GSE22255](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE22255), [GSE16561](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE16561) | `02_download_human_scrnaseq.R`, `12_human_validation_analysis.R` |
| Single-cell RNA | [GSE174574](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE174574), [GSE225948](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE225948) | `02_download_human_scrnaseq.R`, `14_scrnaseq_analysis.R`; final GSE174574 export: `scripts/source_exports/03_recompute_singlecell_de.py`; corrected GSE225948 analysis: `scripts/pipeline/22_gse225948_corrected_pseudobulk.py` |
| Single-nucleus ATAC | [Figshare 25558785](https://figshare.com/articles/dataset/25558785) | `03_download_epigenomics.R`, `15_atacseq_analysis.R` |
| Microglial H3K27ac HiChIP | [GSE319240](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE319240) | `03_download_epigenomics.R`, `08_download_hichip_supplementary.R`, `19_hichip_analysis.py` |

Paths in the last column are under `scripts/pipeline/` unless explicitly given.
Run download scripts with Rscript. The stage-specific locations under
`data/external/` are defined in each script. Downloading every upstream input
is unnecessary when regenerating figures from the bundled processed tables.
See `scripts/pipeline/README.md` for dependencies and stage order.

For the compact lineage-marker source rebuild, download and extract the released
CSV matrices for GSM7060815–GSM7060826 from GSE225948 into
`data/external/03_scrnaseq/supplementary/GSE225948/extracted/`, then run
`scripts/revision_R4/extract_lineage_marker_inputs.py`. Exact source filenames,
sizes, source URLs and SHA256 values are in
`data/reference/lineage_source_manifest.csv`.

The two released HiChIP BEDs are not duplicated in this minimum package. Download
`GSE319240_RAW.tar` from the GSE319240 GEO record and extract the files named
`GSM9514203_HiCHIP_Sham_H3K27ac_interactions.bed` and
`GSM9514204_HiCHIP_Day6_H3K27ac_interactions.bed` into
`data/external/05_hichip/supplementary/GSE319240/extracted/`. The exact source
records, byte sizes, and SHA256 checksums are in
`data/reference/hichip_source_manifest.csv`; the loop script stops if the files
are absent. These are processed public interactions, not raw sequencing reads. The included
WGCNA workspace is a compact processed checkpoint, not a large raw input.

Large GSE174574 and ATAC Seurat checkpoints are not bundled. Their R source
exporters require the existing annotations and data layers and stop when inputs
are missing; see `scripts/source_exports/README.md`. Full raw-data reconstruction
has not been certified by this packaging step. Third-party source terms apply.

## GSE225948 compact analysis input

`data/main_tables/10_scrna_gse225948/GSE225948_normalized_31genes_percell.csv.gz` contains the 31 detectable curated genes after full-matrix library-size normalization and log1p, together with exact cell IDs, pooled sample-library IDs, parent labels, groups, and library sizes. It is the default input to `22_gse225948_corrected_pseudobulk.py`. The accompanying sample-library-mean table retains `n_cells` and the >=10-cell eligibility flag, so sample-library/cell-type exclusions are explicit. Legacy `animal` column/file names denote the released pooled sample libraries (four per group), not individual animals. Composition and lineage scripts additionally use the original released metadata; those recovered-cell counts are not estimates of absolute numbers of cells in brain tissue.

To rebuild the compact input, download and extract `GSE225948_RAW.tar` from the linked GEO record, then run:

```text
python scripts/pipeline/22_gse225948_corrected_pseudobulk.py --from-raw --raw-dir PATH_TO_EXTRACTED_FILES
```

This step checks exact source cell IDs and full-matrix column sums against `nCount_RNA` before transformation. It writes under `outputs/pipeline/10_gse225948/` and leaves the supplied `data/` snapshots unchanged.

## Microarray provenance

GSE61616 and the human microarray cohorts use the released processed GEO Series Matrix values, followed by the script's documented probe annotation, gene-level aggregation and limma contrast. This package does not claim a new raw-CEL/RMA preprocessing step. The upstream normalization belongs to the source investigators and should only be specified more narrowly when documented in the source record.

For human probe annotation, `scripts/pipeline/12_human_validation_analysis.R` reads the official GEO platform annotation tables for GPL570 and GPL6883 directly, using the `!platform_table_begin` / `!platform_table_end` markers. If absent, it downloads `GPL570.annot.gz` or `GPL6883.annot.gz` from `https://ftp.ncbi.nlm.nih.gov/geo/platforms/` into `data/external/02_human_validation/raw/`. No undocumented `GPL6883_clean.csv` is required. The parser retains the historical first-symbol and mean-probe-aggregation conventions.

## R-loop susceptibility proxy inputs

The compact assigned proxy parameters are `data/main_tables/12_rloop_formation_proxy/rloop_proxy_intrinsic_parameters.csv`. Stage23 obtains the observed bulk effect from `GSE163614_rloop_genes.csv` and reconstructs the raw-scale ATAC feature as `log2((M24h pooled activity + 1) / (Sham1d pooled activity + 1))` from `rloop_activity_by_timepoint.csv`. These are pooled activity totals, with unequal recovered-cell counts; the proxy's min–max scaling is a relative ranking, not a depth-normalized accessibility comparison. The final 26-gene result is `rloop_formation_potential_complete_cases.csv`; Δ is relative to a constructed cross-gene midpoint, as defined in `docs/DATA_DICTIONARY.md`.

## Species-specific GO background rerun

`scripts/revision_R4/r2_5b_go_orgdb_species_rerun.R` reads the supplied full bulk DE CSVs directly; separate DESeq2/limma RDS copies are unnecessary. The original result fields from all twelve default/detected animal-cohort tables are retained in `data/revision_R4_tables/GO_orgdb_species_all_results.csv.gz`, identified by `accession`, `direction` and `background`; the count summary is `GO_orgdb_species_summary.csv`. Rat/mouse OrgDb annotation packages and `clusterProfiler` are required. Annotation versions affect mappings and enrichment results; supplied snapshots record the results used in this revision. The approximate human GO snapshot and comparison are retained separately, with no claim that uppercasing is an orthology map.

## Cohort definitions

GSE137482: permanent MCAO versus age-matched intact controls, three days after occlusion without reperfusion; 3- and 18-month age strata are included in the age + group model. The legacy `Ctrl` code identifies the intact controls.

GSE22255: peripheral blood mononuclear cells collected at least six months after the first and only stroke episode. GSE16561: acute whole blood. The human cohorts differ in timing and cellular composition and provide cross-compartment support rather than a matched acute-brain replication.
