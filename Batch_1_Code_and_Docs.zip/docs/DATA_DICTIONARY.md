# Data and calculation conventions

`data/` holds the final supplied snapshots. Scripts write new outputs separately.
NA is retained where an estimate is absent and is not a zero biological effect.

| Family | Definition |
|---|---|
| Curated genes | 32 unique mouse/human pairs, functional categories, selection rationale and evidence tier; contextual genes are labelled. No new literature citations are inferred by packaging. |
| DESeq2 / limma | `log2FoldChange`/`logFC`, raw `pvalue`/`P.Value` and BH `padj`/`adj.P.Val`. Animal brain and human peripheral blood are separate contrasts. The three animal cohorts comprise two RNA-seq cohorts and the GSE61616 microarray cohort. RNA-seq significance uses the DESeq2 `lfcThreshold=log2(1.5)` test; microarray limma tests use a zero-effect null. |
| GSE174574 DE | `log2FC` is a legacy name for the difference in mean stored log-expression (MCAO minus Sham), not a log2 ratio. BH is applied jointly to the 335 nonmissing p-values among 341 gene/cell-type comparisons. The supplied canonical CSV retains cell counts and is the final analysis table. |
| GSE225948 DE | The released count layer is normalized over the full gene matrix to 10,000 and log1p-transformed before per pooled-sample-library × cell-type means. `logFC_D2` is Day2 minus Sham and `logFC_D14` is Day14 minus Day2. Sample-level exact two-sided Mann–Whitney p-values are adjusted by BH across the 31 detectable genes within each cell type and contrast; Welch columns are sensitivity results. Figure 5F right uses the sample-library mean-expression differences (four pooled libraries per group), not the separate exploratory per-cell estimates. The per-cell table contains unadjusted rank-sum p-values and is not a sample-library-level test. Ddx19 is NA because no exact Ddx19 row is available. |
| snATAC | Post-reperfusion timepoints vs Sham. Exact-zero stored p-values can reflect floating-point underflow. Mean activity tables differ from pooled totals. |
| WGCNA | GSE137482, 24 animals, top 5,000 variable genes; module/trait Pearson tests use df=22 and nominal p-values. Nine curated genes entered the network. kME is correlation with the assigned module eigengene. |
| HiChIP | Released processed Sham/Day6 loops; gene annotation uses mm10 TSS ±50 kb. Loop counts and common-loop changes are descriptive. Detection in both conditions does not establish biological replication or identical contacts. |
| Meta-analysis | DL random effects using sampling variance SE squared, BH across the 29 genes estimable in at least two cohorts. k=0/1 rows are retained without pooled estimates. |
| Composition | One pooled sample library per row; group summaries average libraries (four per group), distinct from pooled cell proportions. Recovered counts do not measure absolute tissue abundance. Legacy `animal` column/file names in GSE225948 refer to sample-library IDs. |
| R-loop susceptibility proxy | Transcription–accessibility-based Δ; final 26-gene complete-case uncalibrated proxy. Ddx19 lacks required bulk/ATAC values; Fancm, Fancd2, Top1, Top1mt and Pif1 lack GSE163614 bulk estimates and are also excluded. Missing input values remain NA, not zero. Intrinsic constants are assigned approximations, not sequence-derived measurements. The compact parameter table supplies assigned GC/length values only; observed bulk and pooled ATAC features are read from their canonical layer tables. This restriction does not change the 32-gene integration. |

## Final integration

`08_multiomic_integration/integrated_hub_gene_scoring.csv` is the only score
version. `21_figure7_integration.py` reconstructs it from cohort-level inputs.

| Component | Rule and score |
|---|---|
| Bulk | Number of animal cohorts with BH q<0.05, divided by 3 and multiplied by 2 |
| Human | Number of blood cohorts with BH q<0.05, divided by 2 and multiplied by 1.5 |
| Direction | Majority sign fraction among available animal estimates ×1.5; zero is grouped with nonpositive estimates |
| WGCNA | Blue/brown assigned-module kME>0.7 gives 1.5; otherwise 0. Atm enters the network but does not pass this threshold. |
| PPI | Degree above the observed median (9) gives 1.5; otherwise 0 |
| scRNA | GSE174574 q<0.05 in ≥2 cell types gives 1; GSE225948 Day2 p<0.05 in ≥1 cell type with >5 cells in each group gives another 1 |
| snATAC | q<0.05 at ≥2 timepoints gives 1 |
| HiChIP | No Day6 gene-window loop gives 0; Day6 only gives 0.75; both Sham and Day6 give 1.5 |

`composite_score` is the sum. The theoretical maximum is 12.5 and the observed
maximum is 9.0. `rank` is the ordinal display position; `tied_rank` gives shared
competition ranks for equal scores. Equal-score display order is fixed in the
script and carries no biological distinction. Missing WGCNA evidence is scored
zero for prioritization, not interpreted as negative biological evidence.

## Susceptibility-proxy midpoint

Legacy `potential` filenames and column names identify the R-loop susceptibility proxy and are retained for compatibility. They do not denote measured R-loop abundance or validated formation propensity.

The legacy `potential_sham` column is a constructed baseline: transcription and accessibility are both fixed at 0.5, the cross-gene min–max midpoint, while intrinsic and RNase H1 components are unchanged. It is not a score measured in Sham animals. Thus `potential_change = potential_mcao - potential_sham` simplifies to `0.30 × (tx_norm - 0.5) + 0.25 × (atac_norm - 0.5)`. Positive and negative values indicate positions above and below this midpoint, not an observed gain or loss of R-loops.

The ATAC feature is `log2((M24h pooled gene-activity total + 1)/(Sham1d pooled gene-activity total + 1))`. Pooled totals depend on recovered-cell counts, measurement depth and cell composition; this feature differs from the per-nucleus contrast in Figure 7. All 26 raw ratios are negative, so min–max scaling represents relative retention across genes. Figure 9A/F display this midpoint-centered proxy.

## Weight sensitivity

All eight component columns are divided by their observed maxima across 32 genes.
Equal weights sum these normalized values. Random weights use 1,000
Dirichlet(1,...,1) draws, NumPy default_rng seed 20261101; ranks use NumPy
quicksort to retain the reported random-weight convention. Equal-weight and
leave-one-dimension-out (LODO) use stable ordinal ranks in baseline display order.
LODO removes the named column and sums the seven remaining normalized columns.
Best/worst LODO ranks and all eight scenarios are retained. Ties and sorting
conventions can affect ordinal probabilities; these are prioritization summaries.

The module GO intermediate results are combined in `data/main_tables/06_wgcna_network/module_GO_enrichment.csv.gz` with a `module` field. Default/detected-background sensitivity results are combined in `data/revision_R4_tables/GO_background_sensitivity_all_results.csv.gz` with accession, direction and background fields. Every row and value from the individual tables is retained.

## Expression-matched controls

Within each animal cohort, 50 quantile bins are derived from the non-curated background mean-expression measure, then the same boundaries are applied to the curated genes. For cross-cohort controls, 30 bins use the mean of within-cohort expression percentile ranks among shared genes. Both use unbounded outer edges; empty bins fall back to the nearest five (within-cohort) or eight (cross-cohort) background genes. One control is drawn per detected target with replacement across slots. The seed is 20261027; there are 1,000 within-cohort and 2,000 cross-cohort draws. One-sided empirical p-values are `(1 + count(null >= observed)) / (B + 1)`. Reported null intervals are the 2.5th and 97.5th percentiles of draws, not confidence intervals for the observed genes.

## GO background definitions

The main species-specific background rerun uses `clusterProfiler::enrichGO` with the rat OrgDb for GSE163614/GSE61616 and the mouse OrgDb for GSE137482. It retains the original SYMBOL-to-ENTREZ mapping, first duplicate ENTREZ convention, up/down BH<0.05 selection and all-mapped-detected-gene universe. The detected universe is formed from mapped genes in the supplied bulk result tables; it is not an extra filter on nonmissing adjusted p-values. The default comparison omits an explicit universe. Both use BP, BH adjustment, `minGSSize=10`, `maxGSSize=500`, `pvalueCutoff=0.05`, and `qvalueCutoff=0.2`. `GO_orgdb_species_all_results.csv.gz` combines all twelve result tables and `GO_orgdb_species_summary.csv` reports significant-term counts.

The separate `GO_background_sensitivity_all_results.csv.gz` is an approximate human-annotation hypergeometric sensitivity using uppercased rodent symbols and its own 10–500 filter. It is not a rerun against rat or mouse OrgDb. The human GO snapshot lacks recorded database version/date. Differences between the two pipelines are expected and must retain their method labels.

The supplied species-specific sensitivity was numerically reproduced with R 4.1.3, clusterProfiler 4.2.2, org.Rn.eg.db 3.14.0, org.Mm.eg.db 3.14.0, GO.db 3.14.0, DOSE 3.20.1 and AnnotationDbi 1.56.2. This records a verified reproduction environment, not a complete historical environment lock. Its paired default/detected counts refer to this sensitivity rerun; the main Figure3/S5 enrichment snapshots from the earlier analysis are retained separately under `data/main_tables/03_functional_enrichment/` and need not have identical annotation mappings or term counts. Within-term gene-ID order is immaterial to the gene set.
