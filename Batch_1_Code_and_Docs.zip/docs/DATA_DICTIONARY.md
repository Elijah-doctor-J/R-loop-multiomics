# Data and calculation conventions

`data/` holds the final supplied snapshots. Scripts write new outputs separately.
NA is retained where an estimate is absent and is not a zero biological effect.

| Family | Definition |
|---|---|
| Curated genes | 32 unique mouse/human pairs, functional categories, selection rationale and evidence tier; contextual genes are labelled. No new literature citations are inferred by packaging. |
| DESeq2 / limma | `log2FoldChange`/`logFC`, raw `pvalue`/`P.Value` and BH `padj`/`adj.P.Val`. Animal brain and human peripheral blood are separate contrasts. |
| GSE174574 DE | `log2FC` is a legacy name for the difference in mean stored log-expression (MCAO minus Sham), not a log2 ratio. BH across 341 gene/cell-type tests. The supplied canonical CSV retains cell counts and is the final analysis table. |
| GSE225948 DE | The released count layer is normalized over the full gene matrix to 10,000 and log1p-transformed before per-animal × cell-type means. `logFC_D2` is Day2 minus Sham and `logFC_D14` is Day14 minus Day2. Sample-level exact two-sided Mann–Whitney p-values and BH values are the primary replicate-aware analysis; Welch columns are sensitivity results. The separate per-cell table contains raw exploratory rank-sum p-values and is not an independent-animal test. Ddx19 is NA because no exact Ddx19 row is available. |
| snATAC | Post-reperfusion timepoints vs Sham. Exact-zero stored p-values can reflect floating-point underflow. Mean activity tables differ from pooled totals. |
| WGCNA | GSE137482, 24 animals, top 5,000 variable genes; module/trait Pearson tests use df=22 and nominal p-values. Nine curated genes entered the network. kME is correlation with the assigned module eigengene. |
| HiChIP | Released processed Sham/Day6 loops; gene annotation uses mm10 TSS ±50 kb. Loop counts and common-loop changes are descriptive. Detection in both conditions does not establish biological replication or identical contacts. |
| Meta-analysis | DL random effects using sampling variance SE squared, BH across the 29 genes estimable in at least two cohorts. k=0/1 rows are retained without pooled estimates. |
| Composition | One animal per row; group summaries average animals, distinct from pooled cell proportions. |
| Formation potential | Final 31-gene uncalibrated proxy, excluding Ddx19. Intrinsic constants are assigned approximations, not sequence-derived measurements. The precursor feature table is retained as a necessary input. |

## Final integration

`08_multiomic_integration/integrated_hub_gene_scoring.csv` is the only score
version. `21_figure7_integration.py` reconstructs it from cohort-level inputs.

| Component | Rule and score |
|---|---|
| Bulk | Number of animal cohorts with BH q<0.05, divided by 3 and multiplied by 2 |
| Human | Number of blood cohorts with BH q<0.05, divided by 2 and multiplied by 1.5 |
| Direction | Majority sign fraction among available animal estimates ×1.5; zero is grouped with nonpositive estimates |
| WGCNA | Assigned-module kME>0.7 gives 1.5; otherwise 0. Atm enters the network but does not pass this threshold. |
| PPI | Degree above the observed median (9) gives 1.5; otherwise 0 |
| scRNA | GSE174574 q<0.05 in ≥2 cell types gives 1; GSE225948 Day2 p<0.05 in ≥1 cell type with >5 cells in each group gives another 1 |
| snATAC | q<0.05 at ≥2 timepoints gives 1 |
| HiChIP | No Day6 gene-window loop gives 0; Day6 only gives 0.75; both Sham and Day6 give 1.5 |

`composite_score` is the sum. The theoretical maximum is 12.5 and the observed
maximum is 9.0. `rank` is the ordinal display position; `tied_rank` gives shared
competition ranks for equal scores. Equal-score display order is fixed in the
script and carries no biological distinction. Missing WGCNA evidence is scored
zero for prioritization, not interpreted as negative biological evidence.

## Weight sensitivity

All eight component columns are divided by their observed maxima across 32 genes.
Equal weights sum these normalized values. Random weights use 1,000
Dirichlet(1,...,1) draws, NumPy default_rng seed 20261101; ranks use NumPy
quicksort to retain the reported random-weight convention. Equal-weight and
leave-one-dimension-out (LODO) use stable ordinal ranks in baseline display order.
LODO removes the named column and sums the seven remaining normalized columns.
Best/worst LODO ranks and all eight scenarios are retained. Ties and sorting
conventions can affect ordinal probabilities; these are prioritization summaries.

The module GO intermediate results are combined in `data/main_tables/06_wgcna_network/module_GO_enrichment.csv.gz` with a `module` field. Default/detected-background sensitivity results are combined in `data/revision_R4_tables/GO_background_sensitivity_all_results.csv.gz` with accession, direction and background fields. Every row and value from the individual tables is retained.
