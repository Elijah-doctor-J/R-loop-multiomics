# Release notes — 2026-11-03

This package contains one analysis workflow, the complete 32-gene curation table, cohort and revision result tables, compact processed inputs, and figure scripts. Generated final images, duplicate summary exports, manuscript/editing files, historical result versions and internal audit records are omitted. Public raw inputs are documented in `DATA_SOURCES.md` rather than duplicated.

Expression-matched controls use shared background-derived bins. The exploratory formation-potential proxy uses 26 complete cases, with missing bulk/ATAC measurements excluded and Δ centered on the specified cross-gene midpoint. The integration covers all 32 genes. GSE225948 uses pooled sample libraries as comparison units; Figure 5F right uses their mean-expression differences. Both trajectory denominators and the official GEO human probe-annotation parser are documented by their processing scripts.

The WGCNA checkpoint contains 24 GSE137482 animals (module–trait df=22). Meta-analysis uses SE squared as the sampling variance. HiChIP contacts remain descriptive because there is one released library per condition. Data/calculation conventions are in `DATA_DICTIONARY.md`.

The species-specific animal-cohort GO background rerun is included as one R script, one losslessly combined result table and one summary, separate from the approximate human-annotation comparison.

This package is prepared locally for manual upload; no matching GitHub commit or Zenodo release has been verified. Cite the actual deposited version after upload. Source Word and Excel files are not modified or included.
