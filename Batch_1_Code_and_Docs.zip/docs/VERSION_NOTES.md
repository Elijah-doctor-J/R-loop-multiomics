# Release notes — 2026-11-02

This upload preparation is aligned to the revised IJMS manuscript. The package keeps the complete 32-gene curation table, the final cohort result tables, revision tables, compact processed inputs, and the scripts needed to regenerate them. Generated images, duplicate exports, manuscript/editing files, old analysis versions, and internal audit records are omitted.

The GSE225948 correction uses the released count layer with full-matrix library-size normalization (10,000) followed by log1p. Sample-level means are the biological replicate analysis; the per-cell table is retained as exploratory evidence. Ddx19 remains NA because the source contains Ddx19a/Ddx19b rather than an exact Ddx19 row.

The WGCNA checkpoint is GSE137482 (24 mouse animals; module–trait df=22). The corrected meta-analysis uses SE² as the sampling variance. HiChIP is a descriptive two-condition contact annotation without biological replicates. Raw-data links and processing entry points are in `docs/DATA_SOURCES.md`.

This archive is a local upload preparation. The published Zenodo/GitHub version identifier in the manuscript must be updated to the actual public release after the final files are committed.
