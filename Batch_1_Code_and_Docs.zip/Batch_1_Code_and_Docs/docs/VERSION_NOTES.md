# Release notes — 2026-11-01

One final integration table is supplied with an implementation that rebuilds
its eight components from cohort-level tables and true HiChIP loop annotations.
The 32 baseline scores and the reported random/equal-weight summaries are
retained. LODO statistics are recomputed by removing the named dimension.

Module–trait tests use the retained 24-sample GSE137482 checkpoint (df=22).
Meta and sensitivity tables use sampling variances SE squared; k=0 and k=1
nonestimable genes remain explicit. Figure scripts read the supplied result tables. Main GO-ORA figure inputs and
detected-background sensitivity tables are both retained and distinguished.

Redundant figures, duplicate Excel exports, earlier score implementations and
internal preparation materials are omitted. Raw-data provenance and upstream
scripts are retained. Large raw-data workflows were not rerun end to end during
release preparation. This archive is a local preparation, not a published DOI.
