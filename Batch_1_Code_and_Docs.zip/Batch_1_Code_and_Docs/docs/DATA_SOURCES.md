# Public data access and omitted large inputs

Raw sequencing reads and large downloaded objects are not bundled. The tables,
processed values and compact source inputs needed for downstream calculations
are retained. All source links below are dataset identifiers already used by
the analysis; download the released files from the source records.

| Layer | Source record | Download and processing entry points |
|---|---|---|
| Animal bulk | [GSE163614](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE163614), [GSE137482](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE137482), [GSE61616](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE61616) | `01_download_bulk_rnaseq.R`, `05_download_supplementary.R`, `06_process_rnaseq_counts.R`, `11_bulk_rnaseq_differential_analysis.R` |
| Human peripheral blood | [GSE22255](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE22255), [GSE16561](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE16561) | `02_download_human_scrnaseq.R`, `12_human_validation_analysis.R` |
| Single-cell RNA | [GSE174574](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE174574), [GSE225948](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE225948) | `02_download_human_scrnaseq.R`, `14_scrnaseq_analysis.R`, `20_gse225948_analysis.py`; final DE: `scripts/source_exports/03_recompute_singlecell_de.py` |
| Single-nucleus ATAC | [Figshare 25558785](https://figshare.com/articles/dataset/25558785) | `03_download_epigenomics.R`, `15_atacseq_analysis.R` |
| Microglial H3K27ac HiChIP | [GSE319240](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE319240) | `03_download_epigenomics.R`, `08_download_hichip_supplementary.R`, `19_hichip_analysis.py` |

Paths in the last column are under `scripts/pipeline/` unless explicitly given.
Run download scripts with Rscript. The stage-specific locations under
`data/external/` are defined in each script. Downloading every upstream input
is unnecessary when regenerating figures from the bundled processed tables.
See `scripts/pipeline/README.md` for dependencies and stage order.

For the compact lineage-marker source rebuild, download and extract the released
CSV matrices for GSM7060815–GSM7060826 from GSE225948 into
`data/external/03_scrnaseq/supplementary/GSE225948/extracted/`, then run
`scripts/revision_R4/extract_lineage_marker_inputs.py`. Exact source filenames,
sizes, source URLs and SHA256 values are in
`data/reference/lineage_source_manifest.csv`.

The included HiChIP BEDs are processed interactions for GSM9514203 (Sham) and
GSM9514204 (Day6). They remain bundled because Figure8 and loop reconstruction
read these files directly; they are not raw sequencing reads. The included
WGCNA workspace is a compact processed checkpoint, not a large raw input.

Large GSE174574 and ATAC Seurat checkpoints are not bundled. Their R source
exporters require the existing annotations and data layers and stop when inputs
are missing; see `scripts/source_exports/README.md`. Full raw-data reconstruction
has not been certified by this packaging step. Third-party source terms apply.
