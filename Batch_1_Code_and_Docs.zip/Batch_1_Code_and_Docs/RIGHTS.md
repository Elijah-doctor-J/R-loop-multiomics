# Rights and third-party data

The authors' code, processed results and figures are provided for inspection of
the accompanying research. No software or data licence has been selected by the
authors for this release. Availability alone does not grant a separate reuse
licence. The authors should select and apply an appropriate licence before
archiving a formally licensed release.

Reused GEO, Figshare, STRING and annotation resources remain governed by their
original records, terms and attribution requirements. This repository does not
relicense third-party resources. Public processed HiChIP interaction BED files
from GSE319240 are included as figure inputs and retain their source attribution.
