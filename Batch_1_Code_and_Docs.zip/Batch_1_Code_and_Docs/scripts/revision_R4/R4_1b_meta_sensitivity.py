# -*- coding: utf-8 -*-
"""
R4-1 敏感性分析：RNA-seq-only 合并 + 留一法（leave-one-study-out）
用于刻画跨平台异质性（microarray vs RNA-seq），并检验排序稳健性。
"""
import os
import numpy as np
import pandas as pd
from scipy import stats

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
BULK = str(ROOT / 'data/main_tables/01_bulk_transcriptomics')
OUT_TAB = str(ROOT / 'outputs/revision_R4/tables')
os.makedirs(OUT_TAB, exist_ok=True)
# Corrected canonical sensitivity: all DL calls receive SE squared.
P_CLIP = 1e-300

d163 = pd.read_csv(os.path.join(BULK, "GSE163614_DESeq2_results.csv"))
d137 = pd.read_csv(os.path.join(BULK, "GSE137482_DESeq2_results.csv"))
d616 = pd.read_csv(os.path.join(BULK, "GSE61616_limma_results.csv"))
d616["se"] = (d616["logFC"] / d616["t"]).abs()

def grab(df, g, lc, sc, pc):
    r = df[df["gene"] == g]
    if len(r) == 0:
        return (np.nan, np.nan, np.nan)
    return (r[lc].values[0], r[sc].values[0], r[pc].values[0])

def dl(y, v):
    y = np.asarray(y, float); v = np.asarray(v, float)
    ok = ~np.isnan(y) & ~np.isnan(v) & (v > 0)
    y, v = y[ok], v[ok]
    if len(y) < 2:
        return dict(k=len(y), re=np.nan, se=np.nan, p=np.nan, I2=np.nan)
    w = 1.0 / v
    fe = np.sum(w * y) / np.sum(w)
    Q = np.sum(w * (y - fe) ** 2); dfq = len(y) - 1
    C = np.sum(w) - np.sum(w ** 2) / np.sum(w)
    tau2 = max(0.0, (Q - dfq) / C) if C > 0 else 0.0
    wr = 1.0 / (v + tau2)
    re = np.sum(wr * y) / np.sum(wr); se = np.sqrt(1.0 / np.sum(wr))
    p = 2.0 * stats.norm.sf(abs(re / se))
    I2 = max(0.0, (Q - dfq) / Q) * 100.0 if Q > 0 else 0.0
    return dict(k=len(y), re=re, se=se, p=p, I2=I2)

def stouffer(y, p):
    y = np.asarray(y, float); p = np.asarray(p, float)
    ok = ~np.isnan(y) & ~np.isnan(p)
    y, p = y[ok], np.clip(p[ok], P_CLIP, 1.0)
    if len(y) < 2:
        return np.nan
    z = np.sign(y) * stats.norm.isf(p / 2.0)
    return 2.0 * stats.norm.sf(abs(np.sum(z) / np.sqrt(len(z))))

cross = pd.read_csv(os.path.join(BULK, "rloop_genes_cross_dataset.csv"))[["gene", "gene_human"]]
rows = []
for _, r in cross.iterrows():
    g = r["gene"]
    y163, s163, p163 = grab(d163, g, "log2FoldChange", "lfcSE", "pvalue")
    y137, s137, p137 = grab(d137, g, "log2FoldChange", "lfcSE", "pvalue")
    y616, s616, p616 = grab(d616, g, "logFC", "se", "P.Value")
    Y = np.array([y163, y137, y616]); S = np.array([s163, s137, s616]); P = np.array([p163, p137, p616])
    # 全部三队列
    all3 = dl(Y, S ** 2)
    # 仅 RNA-seq（前两个）
    rnaseq = dl(Y[:2], S[:2] ** 2)
    # 留一法
    loo = {}
    for idx, name in [(0, "drop163"), (1, "drop137"), (2, "drop616")]:
        keep = np.ones(3, bool); keep[idx] = False
        loo[name] = dl(Y[keep], S[keep] ** 2)
    rows.append(dict(
        gene=g, gene_human=r["gene_human"], k=int(all3["k"]),
        re_all3=all3["re"], p_all3=all3["p"], I2_all3=all3["I2"],
        stouffer_all3=stouffer(Y, P),
        re_RNAseq=rnaseq["re"], p_RNAseq=rnaseq["p"], I2_RNAseq=rnaseq["I2"],
        re_drop163=loo["drop163"]["re"], p_drop163=loo["drop163"]["p"],
        re_drop137=loo["drop137"]["re"], p_drop137=loo["drop137"]["p"],
        re_drop616=loo["drop616"]["re"], p_drop616=loo["drop616"]["p"],
        p163=p163, p137=p137, p616=p616,
        lfc163=y163, lfc137=y137, lfc616=y616,
    ))
s = pd.DataFrame(rows)
s.to_csv(os.path.join(OUT_TAB, "meta_sensitivity_analysis_corrected_variance.csv"), index=False, encoding="utf-8-sig")

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 60)
print("===== 关键候选：三队列 vs 仅RNA-seq vs 留一法 (合并 log2FC / p) =====")
focus = ["Ddx21", "Fancd2", "Brca1", "Parp1", "Brca2", "Rnaseh2b", "Xrn2", "Dhx9", "Ddx1", "Atr"]
cols = ["gene", "re_all3", "p_all3", "I2_all3", "stouffer_all3", "re_RNAseq", "p_RNAseq",
        "re_drop616", "p_drop616", "re_drop163", "p_drop163", "re_drop137", "p_drop137"]
print(s[s.gene.isin(focus)][cols].round(3).to_string(index=False))

print("\n===== Ddx21 各队列原始 p =====")
r = s[s.gene == "Ddx21"].iloc[0]
print(f"163 p={r.p163:.2e} (lfc={r.lfc163:.2f}); 137 p={r.p137:.2e} (lfc={r.lfc137:.2f}); 616 p={r.p616:.3f} (lfc={r.lfc616:.2f})")
