# -*- coding: utf-8 -*-
"""
新主图 Panel C — Mg/MdC 亚群时间轨迹（GSE225948，n=4/组）
Nature 规范：双面板 slope plot，占全部细胞 %，n=4 个体点 + mean±SD error bar，直接标签。
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

mpl = matplotlib
mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
    "svg.fonttype": "none",
    "pdf.fonttype": 42,
    "font.size": 8,
    "axes.spines.right": False,
    "axes.spines.top": False,
    "axes.linewidth": 0.8,
    "legend.frameon": False,
})

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
META = str(ROOT / 'data/main_tables/10_scrna_gse225948/GSE225948_merged_metadata.csv')
OUT_FIG = str(ROOT / 'outputs/revision_R4/figures')
Path(OUT_FIG).mkdir(parents=True, exist_ok=True)
(ROOT / "outputs/revision_R4/tables").mkdir(parents=True, exist_ok=True)
TREATS = ["Sham", "D02", "D14"]
XLAB = ["Sham", "Day 2", "Day 14"]
X = np.array([0, 1, 2])

md = pd.read_csv(META)
ct = pd.crosstab(md["sample"], md["sub.celltype"])
info = md[["sample", "treatment", "Replicate"]].drop_duplicates().set_index("sample")
ct = ct.join(info["treatment"])
totals = ct.drop(columns=["treatment"]).sum(axis=1)
pct = ct.drop(columns=["treatment"]).div(totals, axis=0) * 100
pct["treatment"] = ct["treatment"]

# 保存每样本亚群占全部细胞比例（%），供补充表与图注溯源
tab = pct.copy()
tab.insert(0, "replicate", info["Replicate"].values)
tab.reset_index().rename(columns={"sample": "sample"}).to_csv(
    ROOT / "outputs/revision_R4/tables/subcluster_trajectory_per_sample_allcell.csv",
    encoding="utf-8-sig", index=False)

groups = {
    "Mg": {"homeostatic": ["Mg1", "Mg2"], "acute": ["Mg4", "Mg5", "Mg8"],
           "late": ["Mg3", "Mg6", "Mg7"]},
    "MdC": {"early": ["MdC1", "MdC2"], "intermediate": ["MdC3", "MdC4", "MdC5"],
            "late": ["MdC6"]},
}
colors = {
    "Mg1": "#08306b", "Mg2": "#2171b5",
    "Mg4": "#4292c6", "Mg5": "#6baed6", "Mg8": "#b3d3e8",
    "Mg3": "#6a51a3", "Mg6": "#9e9ac8", "Mg7": "#cbc9e2",
    "MdC1": "#99000d", "MdC2": "#cb181d",
    "MdC3": "#fb6a4a", "MdC4": "#f08c68", "MdC5": "#fcbba1",
    "MdC6": "#e67e22",
}
group_color = {"Mg": {"homeostatic": "#08306b", "acute": "#4292c6", "late": "#6a51a3"},
               "MdC": {"early": "#99000d", "intermediate": "#fb6a4a", "late": "#e67e22"}}
group_label = {"homeostatic": "homeostatic", "acute": "acute reactive", "late": "late / recovery",
               "early": "early infiltrating", "intermediate": "intermediate"}
bold_subs = {"Mg1", "Mg2", "Mg3", "Mg4", "Mg5", "MdC1", "MdC2", "MdC6"}

def stats_for(sub):
    means, sds, points = [], [], []
    for tr in TREATS:
        d = pct[pct["treatment"] == tr][sub]
        means.append(d.mean()); sds.append(d.std(ddof=1)); points.append(d.values)
    return np.array(means), np.array(sds), points

# 标签：(sub, anchor_x, text_x, text_y, ha)
mg_labels = [
    ("Mg1", 0, -0.24, 39.5, "right"),
    ("Mg2", 0, -0.24, 26.5, "right"),
    ("Mg4", 1, 0.80, 9.8, "right"),
    ("Mg5", 1, 1.20, 11.2, "left"),
    ("Mg3", 2, 2.20, 24.5, "left"),
    ("Mg6", 2, 2.20, 4.0, "left"),
]
mdc_labels = [
    ("MdC1", 1, 0.80, 17.4, "right"),
    ("MdC2", 1, 1.20, 15.6, "left"),
    ("MdC3", 1, 0.78, 9.2, "right"),
    ("MdC6", 2, 2.20, 8.4, "left"),
    ("MdC4", 2, 2.20, 5.6, "left"),
    ("MdC5", 2, 2.20, 3.4, "left"),
]

fig, axes = plt.subplots(1, 2, figsize=(7.1, 3.3), gridspec_kw={"wspace": 0.30})
rng = np.random.default_rng(7)

def draw(ax, lineage, title, ytop, labels):
    cache = {}
    for gname, gsubs in groups[lineage].items():
        for sub in gsubs:
            means, sds, pts = stats_for(sub)
            cache[sub] = means
            lw = 2.0 if sub in bold_subs else 1.1
            ax.errorbar(X, means, yerr=sds, fmt="-", color=colors[sub], lw=lw,
                        capsize=2.2, capthick=0.9, elinewidth=0.9, zorder=3,
                        marker="o", ms=3.5 if sub in bold_subs else 2.5,
                        mfc=colors[sub], mec="white", mew=0.4)
            for xi, arr in zip(X, pts):
                ax.scatter(np.full(len(arr), xi) + rng.uniform(-0.05, 0.05, len(arr)), arr,
                           s=9, color=colors[sub], alpha=0.45, zorder=2, edgecolors="none")
    for sub, ax_i, tx, ty, ha in labels:
        ay = cache[sub][ax_i]
        ax.annotate(sub, xy=(ax_i, ay), xytext=(tx, ty), ha=ha, va="center",
                    fontsize=7.4, color=colors[sub],
                    fontweight="bold" if sub in bold_subs else "normal",
                    arrowprops=dict(arrowstyle="-", color=colors[sub], lw=0.6,
                                    alpha=0.7, shrinkA=2, shrinkB=2))
    ax.set_xticks(X); ax.set_xticklabels(XLAB, fontsize=8)
    ax.set_ylim(0, ytop); ax.set_xlim(-0.66, 2.66)
    ax.set_ylabel("Fraction of all cells (%)", fontsize=8)
    ax.set_title(title, fontsize=8.6, fontweight="bold")
    ax.grid(axis="y", ls=":", alpha=0.35, lw=0.6)
    ax.text(0.02, 0.97, "n = 4 mice/group", transform=ax.transAxes, fontsize=6.8,
            va="top", ha="left", color="0.35")
    handles = [Line2D([0], [0], color=group_color[lineage][g], lw=3,
                      label=group_label[g]) for g in
               (["homeostatic", "acute", "late"] if lineage == "Mg"
                else ["early", "intermediate", "late"])]
    ax.legend(handles=handles, loc="upper right", fontsize=6.6, handlelength=1.1,
              borderpad=0.3, labelspacing=0.22, bbox_to_anchor=(1.0, 0.99))

draw(axes[0], "Mg", "Resident microglia (Mg1–8)", 52, mg_labels)
draw(axes[1], "MdC", "Monocyte-derived cells (MdC1–6)", 20, mdc_labels)

fig.text(0.5, -0.015, "Time after reperfusion", ha="center", fontsize=8)
base = os.path.join(OUT_FIG, "Fig_panelC_subcluster_trajectory")
fig.savefig(base + ".png", dpi=600, bbox_inches="tight")
fig.savefig(base + ".tiff", dpi=600, bbox_inches="tight")
fig.savefig(base + ".svg", bbox_inches="tight")
fig.savefig(base + ".pdf", bbox_inches="tight")
plt.close()
print("saved")
