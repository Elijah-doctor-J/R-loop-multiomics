# -*- coding: utf-8 -*-
"""
R4-2b 驻留小胶质 vs 单核来源细胞的判别验证（Reviewer 4, comment 2b）
======================================================================
GSE225948 现有注释已把 Mg（resident microglia, Mg1-8）与 MdC
（monocyte-derived cells, MdC1-6）分开。本脚本用经典 canonical marker 独立验证
该区分是否稳健：
  - 驻留小胶质：Tmem119, P2ry12, Hexb, Cx3cr1, Sall1, Gpr34, Slc2a5, Siglech
  - 单核来源  ：Ccr2, Plac8, Ly6c2, Ly6c1, Ifitm1, Fn1, S100a4, Chil3, Cd52
  - BAM/巨噬  ：Mrc1, Cd163, Lyve1, Pf4, F13a1
  - 泛髓系    ：Aif1(Iba1), Itgam(CD11b), Ptprc(CD45)
  - 激活/DAM  ：Cst7, Itgax, Lpl, Apoe, Trem2, Tyrobp, Axl, Ccl2, Clec7a

输出：
  tables/parent_marker_expression.csv     各 parent 细胞类型 marker 平均表达/检出率
  tables/subcluster_marker_expression.csv Mg1-8 / MdC1-6 亚群 marker 表达
  tables/Mg_vs_MdC_score_classification.csv  逐细胞评分与分类一致率
  figures/Fig_marker_dotplot_parent.png/.pdf
  figures/Fig_mg_mdc_score.png/.pdf
"""
import os, glob
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
EXTR = ROOT / 'data/external/03_scrnaseq/supplementary/GSE225948/extracted'
META = str(ROOT / 'data/main_tables/10_scrna_gse225948/GSE225948_merged_metadata.csv')
OUT_TAB = str(ROOT / 'outputs/revision_R4/tables')
OUT_FIG = str(ROOT / 'outputs/revision_R4/figures')
os.makedirs(OUT_TAB, exist_ok=True); os.makedirs(OUT_FIG, exist_ok=True)

RESIDENT = ["Tmem119", "P2ry12", "Hexb", "Cx3cr1", "Sall1", "Gpr34", "Slc2a5", "Siglech"]
MONO     = ["Ccr2", "Plac8", "Ly6c2", "Ly6c1", "Ifitm1", "Fn1", "S100a4", "Chil3", "Cd52"]
BAM      = ["Mrc1", "Cd163", "Lyve1", "Pf4", "F13a1"]
PANMYE   = ["Aif1", "Itgam", "Ptprc"]
DAM      = ["Cst7", "Itgax", "Lpl", "Apoe", "Trem2", "Tyrobp", "Axl", "Ccl2", "Clec7a"]
MARKERS = RESIDENT + MONO + BAM + PANMYE + DAM
GENE_GROUP = {**{g: "Resident microglia" for g in RESIDENT},
              **{g: "Monocyte-derived" for g in MONO},
              **{g: "BAM/macrophage" for g in BAM},
              **{g: "Pan-myeloid" for g in PANMYE},
              **{g: "DAM/activated" for g in DAM}}

# ---------- 1. 读 metadata，确定脑样本 ----------
meta = pd.read_csv(META)
meta = meta.set_index("cell_id")
brain_gsms = sorted(meta["sample"].unique())
print("脑样本数:", len(brain_gsms), brain_gsms)

# ---------- 2. 逐个样本读 marker 行 ----------
marker_input = ROOT / 'data/reference/GSE225948_lineage_markers.csv.gz'
if not marker_input.exists():
    marker_input = ROOT / 'outputs/revision_R4/inputs/GSE225948_lineage_markers.csv.gz'
if not marker_input.exists():
    raise FileNotFoundError("Run extract_lineage_marker_inputs.py after downloading the 12 GEO source matrices.")
expr = pd.read_csv(marker_input, index_col=0)
print("合并 marker 矩阵:", expr.shape, "（markers x cells）")

# 与 metadata 对齐
common = expr.columns.intersection(meta.index)
print("匹配细胞数:", len(common), "/ metadata", len(meta))
if len(common) != len(meta):
    raise ValueError("Not all metadata cells align with raw expression inputs; refusing a partial analysis.")
expr = expr[common]
meta = meta.loc[common]
det = (expr > 0).astype(np.float64)          # 检出矩阵
logexpr = np.log1p(expr)                     # 归一化值按 log1p 处理

# ---------- 3. 按 parent 聚合 ----------
def summarize(by_col, labels_order):
    avg_frames, pct_frames = [], []
    for lab in labels_order:
        cells = meta.index[meta[by_col] == lab]
        if len(cells) == 0:
            continue
        le = logexpr[cells]
        de = det[cells]
        avg_frames.append(le.mean(axis=1).rename(lab))
        pct_frames.append(de.mean(axis=1).rename(lab))
    avg = pd.concat(avg_frames, axis=1).reindex(MARKERS)
    pct = pd.concat(pct_frames, axis=1).reindex(MARKERS)
    return avg, pct

# parent 顺序：髓系在前，神经/淋巴在后
parent_order = ["Mg", "MdC", "BAM", "MaC", "DC", "MC", "Gran", "NK", "Tc", "Bc", "EC", "OD", "Epi"]
parent_order = [p for p in parent_order if p in meta["parent"].unique()]
avg_p, pct_p = summarize("parent", parent_order)

# 长表
long = []
for g in MARKERS:
    for ct in parent_order:
        long.append(dict(gene=g, group=GENE_GROUP[g], celltype=ct,
                         avg_logexpr=avg_p.loc[g, ct], pct_expressing=pct_p.loc[g, ct] * 100,
                         n_cells=int((meta["parent"] == ct).sum())))
pd.DataFrame(long).to_csv(os.path.join(OUT_TAB, "parent_marker_expression.csv"),
                          index=False, encoding="utf-8-sig")
avg_p.to_csv(os.path.join(OUT_TAB, "parent_avg_logexpr_matrix.csv"), encoding="utf-8-sig")
pct_p.to_csv(os.path.join(OUT_TAB, "parent_pct_matrix.csv"), encoding="utf-8-sig")

# 亚群（Mg1-8, MdC1-6）
sub_order = [c for c in (["Mg%d" % i for i in range(1, 9)] + ["MdC%d" % i for i in range(1, 7)])
             if c in meta["sub.celltype"].unique()]
avg_s, pct_s = summarize("sub.celltype", sub_order)
avg_s.to_csv(os.path.join(OUT_TAB, "subcluster_avg_logexpr_matrix.csv"), encoding="utf-8-sig")
pct_s.to_csv(os.path.join(OUT_TAB, "subcluster_pct_matrix.csv"), encoding="utf-8-sig")

# ---------- 4. 打印 Mg vs MdC 关键 marker 对比 ----------
print("\n===== parent 细胞类型 marker 检出率 (%) =====")
show = pct_p.loc[RESIDENT + MONO + BAM + PANMYE, ["Mg", "MdC", "BAM", "DC"]].round(1)
print(show.to_string())
print("\n===== 平均 log 表达（关键 marker） =====")
show2 = avg_p.loc[RESIDENT[:5] + MONO[:5], ["Mg", "MdC", "BAM"]].round(2)
print(show2.to_string())

# ---------- 5. 逐细胞评分：resident score vs monocyte score ----------
# 简单模块评分：每个 marker 在细胞内的 log 表达，按基因标准化（z-score）后取均值
Z = logexpr.copy()
# 仅用全数据各基因均值/标准差做标准化
mu = Z.mean(axis=1); sd = Z.std(axis=1).replace(0, np.nan)
Z = Z.sub(mu, axis=0).div(sd, axis=0)
rscore = Z.loc[[g for g in RESIDENT if g in Z.index]].mean(axis=0)
mscore = Z.loc[[g for g in MONO if g in Z.index]].mean(axis=0)
score_df = pd.DataFrame({"parent": meta["parent"], "sub": meta["sub.celltype"],
                         "treatment": meta["treatment"],
                         "resident_score": rscore, "monocyte_score": mscore,
                         "nCount": meta["nCount_RNA"]})
score_df.to_csv(os.path.join(OUT_TAB, "Mg_vs_MdC_scores_percell.csv"), encoding="utf-8-sig")

# 分类一致率：在 Mg 与 MdC 细胞内，比较 score 大小与注释是否一致
mm = score_df[score_df["parent"].isin(["Mg", "MdC"])]
pred = np.where(mm["resident_score"] > mm["monocyte_score"], "Mg", "MdC")
acc = (pred == mm["parent"].values).mean()
# 分别报告
acc_mg = (pred[mm["parent"] == "Mg"] == "Mg").mean()
acc_md = (pred[mm["parent"] == "MdC"] == "MdC").mean()
print("\n===== Mg/MdC marker 评分分类一致率 =====")
print(f"整体: {acc*100:.2f}%  Mg 被判为 Mg: {acc_mg*100:.2f}%  MdC 被判为 MdC: {acc_md*100:.2f}%")
print("各 parent 平均 resident / monocyte score:")
print(score_df.groupby("parent")[["resident_score", "monocyte_score"]].mean().round(3).loc[
    ["Mg", "MdC", "BAM", "DC"]].to_string())
pd.DataFrame([{"metric": "overall_agreement", "value": acc},
              {"metric": "Mg_agreement", "value": acc_mg},
              {"metric": "MdC_agreement", "value": acc_md}]).to_csv(
    os.path.join(OUT_TAB, "Mg_vs_MdC_score_classification.csv"), index=False, encoding="utf-8-sig")

# ---------- 6. dotplot（parent，大字号） ----------
fig, ax = plt.subplots(figsize=(13.5, 11))
# 颜色：每个基因跨细胞类型 z-score
zmat = avg_p.T.apply(lambda col: (col - col.mean()) / col.std(ddof=0), axis=0).T
# 基因分组排列，细胞类型髓系在前
genes_order = RESIDENT + MONO + BAM + PANMYE + DAM
cts = parent_order
data = zmat.loc[genes_order, cts].values
sizes = pct_p.loc[genes_order, cts].values * 100
import matplotlib.colors as mcolors
cmap = plt.cm.RdYlBu_r
vmin, vmax = -2.0, 2.0
for i, g in enumerate(genes_order):
    for j, ct in enumerate(cts):
        z = data[i, j]; ps = sizes[i, j]
        if np.isnan(z): continue
        ax.scatter(j, i, s=ps * 6.0, c=[cmap(np.clip((z - vmin) / (vmax - vmin), 0, 1))],
                   edgecolors="gray", linewidths=0.3, zorder=3)
ax.set_xticks(range(len(cts))); ax.set_xticklabels(cts, rotation=45, ha="right", fontsize=11)
ax.set_yticks(range(len(genes_order))); ax.set_yticklabels(genes_order, fontsize=10.5, style="italic")
ax.set_xlim(-0.6, len(cts) - 0.4); ax.set_ylim(len(genes_order) - 0.6, -0.6)
ax.set_xticks(np.arange(-0.5, len(cts), 1), minor=True)
ax.set_yticks(np.arange(-0.5, len(genes_order), 1), minor=True)
ax.grid(which="minor", color="0.9", linewidth=0.7); ax.tick_params(which="minor", length=0)
# 分组分隔线与标签
bounds = np.cumsum([len(RESIDENT), len(MONO), len(BAM), len(PANMYE)]) - 0.5
for b in bounds[:-1]:
    ax.axhline(b, color="black", lw=1.2)
group_labels = [(RESIDENT, "Resident microglia"), (MONO, "Monocyte-derived"),
                (BAM, "BAM/macrophage"), (PANMYE, "Pan-myeloid"), (DAM, "DAM/activated")]
for glist, lab in group_labels:
    yc = genes_order.index(glist[0]) + (len(glist) - 1) / 2
    ax.text(len(cts) - 0.35, yc, lab, ha="left", va="center", fontsize=10, rotation=-90,
            color="#333333")
ax.set_title("Canonical marker expression by major cell type (GSE225948)\n"
             "Color = scaled average log-expression; size = % expressing cells",
             fontsize=13)
plt.tight_layout()
plt.savefig(os.path.join(OUT_FIG, "Fig_marker_dotplot_parent.png"), dpi=300, bbox_inches="tight")
plt.savefig(os.path.join(OUT_FIG, "Fig_marker_dotplot_parent.pdf"), bbox_inches="tight")
plt.close()

# ---------- 7. Mg vs MdC 评分密度/小提琴 ----------
fig, ax = plt.subplots(figsize=(8.5, 6))
plot_df = score_df[score_df["parent"].isin(["Mg", "MdC", "BAM"])].copy()
for k, (lab, col) in enumerate([("Mg", "#2166ac"), ("MdC", "#b2182b"), ("BAM", "#5aae61")]):
    for j, score_col in enumerate(["resident_score", "monocyte_score"]):
        v = plot_df.loc[plot_df["parent"] == lab, score_col].values
        pos = k * 2 + j + (1 if j == 1 else 0)
        parts = ax.violinplot(v, positions=[pos], showmedians=True, widths=0.85)
        for pc in parts["bodies"]:
            pc.set_facecolor(col); pc.set_alpha(0.6 if score_col == "resident_score" else 0.25)
ax.set_xticks([0, 1, 2, 3, 4, 5])
ax.set_xticklabels(["Mg\nresident", "Mg\nmonocyte", "MdC\nresident", "MdC\nmonocyte",
                    "BAM\nresident", "BAM\nmonocyte"], fontsize=11)
ax.set_ylabel("Module score (mean z-scored expression)", fontsize=12)
ax.set_title("Resident-microglia vs monocyte-derived module scores\n"
             f"Marker-based classification agreement with annotation: {acc*100:.1f}%",
             fontsize=12.5)
ax.grid(axis="y", ls=":", alpha=0.5)
plt.tight_layout()
plt.savefig(os.path.join(OUT_FIG, "Fig_mg_mdc_score.png"), dpi=300)
plt.savefig(os.path.join(OUT_FIG, "Fig_mg_mdc_score.pdf"))
plt.close()
print("\n图表已保存至:", OUT_FIG)
