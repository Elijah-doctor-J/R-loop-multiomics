# -*- coding: utf-8 -*-
"""
R4-2c 细胞组成的组成约束处理（Reviewer 4, comment 2c）
======================================================================
细胞比例是组成数据（和为 1，各类别非独立）：一类增多会机械性压低其他类的比例。
本脚本：
  1) 不再用池化比例，而是在每只小鼠（n=4/组）层面计算 Mg/MdC 比例与绝对细胞数，
     报告 mean±SD 与每只动物的分布；
  2) 同时报告绝对细胞数（每样本回收细胞数），区分“真实涌入”与“比例稀释”；
  3) 增加不受和为 1 约束的组成感知指标：Mg/MdC 的 log-ratio；
  4) 组间比较在样本层面进行（Welch t / Mann-Whitney，n=4）。

输出：
  tables/composition_per_sample.csv
  figures/Fig_composition.png/.pdf
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
META = str(ROOT / 'data/main_tables/10_scrna_gse225948/GSE225948_merged_metadata.csv')
OUT_TAB = str(ROOT / 'outputs/revision_R4/tables')
OUT_FIG = str(ROOT / 'outputs/revision_R4/figures')
os.makedirs(OUT_TAB, exist_ok=True); os.makedirs(OUT_FIG, exist_ok=True)

md = pd.read_csv(META)
TREAT_ORDER = ["Sham", "D02", "D14"]
TREAT_LABEL = {"Sham": "Sham", "D02": "D2", "D14": "D14"}
KEY_TYPES = ["Mg", "MdC", "BAM", "DC"]

# ---------- 1. 每样本细胞数 / 比例 ----------
counts = pd.crosstab(md["sample"], md["parent"])
sample_info = md[["sample", "treatment", "study.ident", "Replicate"]].drop_duplicates().set_index("sample")
counts = counts.join(sample_info["treatment"])
counts["total"] = counts.drop(columns=["treatment"]).sum(axis=1)

rows = []
for s, r in counts.iterrows():
    total = r["total"]
    row = dict(sample=s, study_ident=r.get("study.ident", np.nan) if False else
               sample_info.loc[s, "study.ident"], treatment=r["treatment"],
               replicate=sample_info.loc[s, "Replicate"], total_cells=int(total))
    for t in counts.columns:
        if t in ("treatment", "total"): continue
        n = int(r[t])
        row[f"{t}_n"] = n
        row[f"{t}_pct"] = 100.0 * n / total
    # 组成感知 log-ratio（+0.5 伪计数）
    row["logratio_Mg_vs_MdC"] = np.log((r["Mg"] + 0.5) / (r["MdC"] + 0.5))
    row["logratio_Mg_vs_rest"] = np.log((r["Mg"] + 0.5) / (total - r["Mg"] + 0.5))
    rows.append(row)
psd = pd.DataFrame(rows)
psd.to_csv(os.path.join(OUT_TAB, "composition_per_sample.csv"), index=False, encoding="utf-8-sig")

# ---------- 2. 组层面 mean±SD 与检验 ----------
def summarize_type(t):
    recs = []
    for tr in TREAT_ORDER:
        d = psd[psd["treatment"] == tr]
        recs.append(dict(type=t, treatment=tr,
                         pct_mean=d[f"{t}_pct"].mean(), pct_sd=d[f"{t}_pct"].std(),
                         n_mean=d[f"{t}_n"].mean(), n_sd=d[f"{t}_n"].std(),
                         total_mean=d["total_cells"].mean(), total_sd=d["total_cells"].std()))
    return pd.DataFrame(recs)

summary = pd.concat([summarize_type(t) for t in KEY_TYPES], ignore_index=True)
summary.to_csv(os.path.join(OUT_TAB, "composition_group_summary.csv"), index=False, encoding="utf-8-sig")

print("===== 池化比例（原始口径） =====")
tot = md.groupby("treatment")["parent"].size()
for tr in TREAT_ORDER:
    nmg = (md[md["treatment"] == tr]["parent"] == "Mg").sum()
    nmd = (md[md["treatment"] == tr]["parent"] == "MdC").sum()
    print(f"{tr:4s}: Mg={nmg/tot[tr]*100:5.1f}%  MdC={nmd/tot[tr]*100:5.1f}%")

print("\n===== 样本层面 mean±SD（n=4，比例%） =====")
for t in ["Mg", "MdC"]:
    print(f"-- {t} --")
    for tr in TREAT_ORDER:
        d = psd[psd["treatment"] == tr]
        print(f"  {TREAT_LABEL[tr]:4s}: pct={d[t+'_pct'].mean():5.1f}±{d[t+'_pct'].std():4.1f}%  "
              f"绝对数={d[t+'_n'].mean():6.1f}±{d[t+'_n'].std():5.1f}")

print("\n===== 样本层面检验（D2 vs Sham, D14 vs Sham；Welch t 与 Mann-Whitney） =====")
for t in ["Mg", "MdC"]:
    sham = psd[psd["treatment"] == "Sham"][f"{t}_pct"]
    for tr in ["D02", "D14"]:
        x = psd[psd["treatment"] == tr][f"{t}_pct"]
        tw = stats.ttest_ind(x, sham, equal_var=False)
        try:
            mw = stats.mannwhitneyu(x, sham, alternative="two-sided")
            mwp = mw.pvalue
        except Exception:
            mwp = np.nan
        print(f"  {t} {TREAT_LABEL[tr]} vs Sham: Welch p={tw.pvalue:.4f}  MW p={mwp:.4f}")
# log-ratio 检验
lr = psd.groupby("treatment")["logratio_Mg_vs_MdC"].agg(["mean", "std"])
print("\nlog(Mg/MdC) 组均值:"); print(lr.round(3).to_string())
for tr in ["D02", "D14"]:
    x = psd[psd["treatment"] == tr]["logratio_Mg_vs_MdC"]
    sh = psd[psd["treatment"] == "Sham"]["logratio_Mg_vs_MdC"]
    print(f"  logratio {TREAT_LABEL[tr]} vs Sham: Welch p={stats.ttest_ind(x,sh,equal_var=False).pvalue:.5f}")

# ---------- 3. 图：每只动物点 + mean±SD（左：比例，右：绝对数，下：log-ratio） ----------
fig, axes = plt.subplots(1, 3, figsize=(15, 5.2))
xpos = [0, 1, 2]; jitter = 0.07
colors = {"Mg": "#2166ac", "MdC": "#b2182b"}
for ax, t, ylab in [(axes[0], None, "Proportion of cells (%)"),
                    (axes[1], None, "Cells recovered per mouse")]:
    pass

# 图A：比例（Mg + MdC 两组）
ax = axes[0]
for t, off in [("Mg", -0.18), ("MdC", 0.18)]:
    means, sds, pts = [], [], []
    for x, tr in zip(xpos, TREAT_ORDER):
        d = psd[psd["treatment"] == tr]
        means.append(d[f"{t}_pct"].mean()); sds.append(d[f"{t}_pct"].std()); pts.append(d[f"{t}_pct"].values)
    means = np.array(means); sds = np.array(sds)
    ax.errorbar(np.array(xpos) + off, means, yerr=sds, fmt="o", color=colors[t], lw=2, ms=9, capsize=5,
                label=t, zorder=3)
    for x, arr in zip(xpos, pts):
        rng = np.random.default_rng(1)
        ax.scatter(np.full(len(arr), x + off) + rng.uniform(-jitter, jitter, len(arr)), arr,
                   color=colors[t], alpha=0.45, s=28, zorder=2)
ax.set_xticks(xpos); ax.set_xticklabels(["Sham", "D2", "D14"], fontsize=12)
ax.set_ylabel("Proportion of cells (%)", fontsize=12)
ax.set_title("Sample-level proportions (n=4/group)", fontsize=12.5)
ax.legend(fontsize=11); ax.grid(axis="y", ls=":", alpha=0.5)

# 图B：绝对细胞数
ax = axes[1]
for t, off in [("Mg", -0.18), ("MdC", 0.18)]:
    means, sds, pts = [], [], []
    for x, tr in zip(xpos, TREAT_ORDER):
        d = psd[psd["treatment"] == tr]
        means.append(d[f"{t}_n"].mean()); sds.append(d[f"{t}_n"].std()); pts.append(d[f"{t}_n"].values)
    means = np.array(means); sds = np.array(sds)
    ax.errorbar(np.array(xpos) + off, means, yerr=sds, fmt="o", color=colors[t], lw=2, ms=9, capsize=5,
                label=t, zorder=3)
    for x, arr in zip(xpos, pts):
        rng = np.random.default_rng(2)
        ax.scatter(np.full(len(arr), x + off) + rng.uniform(-jitter, jitter, len(arr)), arr,
                   color=colors[t], alpha=0.45, s=28, zorder=2)
ax.set_xticks(xpos); ax.set_xticklabels(["Sham", "D2", "D14"], fontsize=12)
ax.set_ylabel("Cells recovered per mouse", fontsize=12)
ax.set_title("Absolute counts (captures influx vs dilution)", fontsize=12.5)
ax.legend(fontsize=11); ax.grid(axis="y", ls=":", alpha=0.5)

# 图C：log-ratio
ax = axes[2]
means, sds, pts = [], [], []
for x, tr in zip(xpos, TREAT_ORDER):
    d = psd[psd["treatment"] == tr]
    means.append(d["logratio_Mg_vs_MdC"].mean()); sds.append(d["logratio_Mg_vs_MdC"].std())
    pts.append(d["logratio_Mg_vs_MdC"].values)
ax.errorbar(xpos, means, yerr=sds, fmt="o", color="#333333", lw=2, ms=9, capsize=5, zorder=3)
for x, arr in zip(xpos, pts):
    rng = np.random.default_rng(3)
    ax.scatter(np.full(len(arr), x) + rng.uniform(-jitter, jitter, len(arr)), arr,
               color="#666666", alpha=0.6, s=30, zorder=2)
ax.axhline(0, color="gray", ls="--", lw=1)
ax.set_xticks(xpos); ax.set_xticklabels(["Sham", "D2", "D14"], fontsize=12)
ax.set_ylabel("log(Mg / MdC)  (+0.5 pseudocount)", fontsize=12)
ax.set_title("Composition-aware log-ratio", fontsize=12.5)
ax.grid(axis="y", ls=":", alpha=0.5)

plt.suptitle("Microglia vs monocyte-derived cell abundance (GSE225948): proportions, counts, and log-ratio",
             fontsize=13, y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(OUT_FIG, "Fig_composition.png"), dpi=300, bbox_inches="tight")
plt.savefig(os.path.join(OUT_FIG, "Fig_composition.pdf"), bbox_inches="tight")
plt.close()
print("\n图已保存:", os.path.join(OUT_FIG, "Fig_composition.png"))
