# -*- coding: utf-8 -*-
"""
Recompute R-loop formation potential after excluding Ddx19.
This is an uncalibrated heuristic. GC and gene length in the input table
are author-assigned approximations, not sequence-derived measurements. They
cancel in the potential_change contrast together with the constant RNaseH term.
Ddx19 had bulk_log2FC=0 and atac_log2FC=0 due to missing data (fillna).
Its atac=0 was the MAX in the 32-gene set, inflating its atac_norm to 1.0.
After exclusion, re-minmax normalize atac over the remaining 31 genes,
recompute potential_change and rank. tx_norm is unchanged because Ddx19's
bulk=0 was neither min nor max in the 32-gene set.
"""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/pipeline/12_rloop_proxy"
OUT.mkdir(parents=True, exist_ok=True)
import pandas as pd
import numpy as np

SRC = ROOT / 'data/main_tables/12_rloop_formation_proxy/rloop_formation_potential.csv'
DST = OUT / 'rloop_formation_potential_excl_ddx19.csv'

df = pd.read_csv(SRC)
print(f"Original: {len(df)} genes")
print(f"Ddx19 row: bulk={df.loc[df.gene=='Ddx19','bulk_log2FC'].values[0]}, "
      f"atac={df.loc[df.gene=='Ddx19','atac_log2FC'].values[0]}, "
      f"atac_norm={df.loc[df.gene=='Ddx19','atac_norm'].values[0]:.4f}, "
      f"rank={df.loc[df.gene=='Ddx19','rank'].values[0]}")

# Exclude Ddx19
df31 = df[df.gene != 'Ddx19'].copy().reset_index(drop=True)
print(f"\nAfter exclusion: {len(df31)} genes")

# Verify tx range unchanged (Ddx19 bulk=0 was neither min nor max)
print(f"bulk range (31): min={df31.bulk_log2FC.min():.4f} ({df31.loc[df31.bulk_log2FC.idxmin(),'gene']}), "
      f"max={df31.bulk_log2FC.max():.4f} ({df31.loc[df31.bulk_log2FC.idxmax(),'gene']})")
print(f"atac range (31): min={df31.atac_log2FC.min():.4f} ({df31.loc[df31.atac_log2FC.idxmin(),'gene']}), "
      f"max={df31.atac_log2FC.max():.4f} ({df31.loc[df31.atac_log2FC.idxmax(),'gene']})")

# Re-minmax normalize atac over 31 genes
atac_min = df31.atac_log2FC.min()
atac_max = df31.atac_log2FC.max()
df31['atac_norm'] = (df31.atac_log2FC - atac_min) / (atac_max - atac_min)

# tx_norm: recompute to be safe (should be identical to original)
tx_min = df31.bulk_log2FC.min()
tx_max = df31.bulk_log2FC.max()
df31['tx_norm'] = (df31.bulk_log2FC - tx_min) / (tx_max - tx_min)

# Recompute potential with weights: intrinsic 0.25, tx 0.30, atac 0.25, rnaseh1 0.20
# Sham baseline: tx=atac=0.5
df31['potential_sham'] = (0.25 * df31['intrinsic'] + 0.30 * 0.5 +
                           0.25 * 0.5 + 0.20 * df31['rnaseh1_effect'])
df31['potential_mcao'] = (0.25 * df31['intrinsic'] + 0.30 * df31['tx_norm'] +
                           0.25 * df31['atac_norm'] + 0.20 * df31['rnaseh1_effect'])
df31['potential_change'] = df31['potential_mcao'] - df31['potential_sham']

# Re-rank
df31 = df31.sort_values('potential_change', ascending=False).reset_index(drop=True)
df31['rank'] = df31.index + 1

# Summary
n_up = (df31.potential_change > 0).sum()
n_down = (df31.potential_change < 0).sum()
print(f"\n=== Result (31 genes, Ddx19 excluded) ===")
print(f"potential_change > 0: {n_up} ({df31.loc[df31.potential_change>0,'gene'].tolist()})")
print(f"potential_change < 0: {n_down}")
print(f"\nTop 5:")
print(df31[['gene','bulk_log2FC','atac_log2FC','tx_norm','atac_norm','potential_change','rank']].head(5).to_string(index=False))
print(f"\nBottom 3:")
print(df31[['gene','potential_change','rank']].tail(3).to_string(index=False))

# Compare Ddx21 old vs new
ddx21_old = df.loc[df.gene=='Ddx21'].iloc[0]
ddx21_new = df31.loc[df31.gene=='Ddx21'].iloc[0]
print(f"\nDdx21 comparison:")
print(f"  old: atac_norm={ddx21_old.atac_norm:.4f}, Δ={ddx21_old.potential_change:.6f}, rank={ddx21_old['rank']}")
print(f"  new: atac_norm={ddx21_new.atac_norm:.4f}, Δ={ddx21_new.potential_change:.6f}, rank={ddx21_new['rank']}")

# Save
df31.to_csv(DST, index=False)
print(f"\nSaved to {DST}")
