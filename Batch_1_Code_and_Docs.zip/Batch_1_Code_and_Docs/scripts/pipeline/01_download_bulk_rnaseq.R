# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 01_download_bulk_rnaseq.R
# 下载第一批：Bulk RNA-seq 发现集 + 验证集
# 数据集：GSE163614, GSE61616, GSE32529, GSE137482
# ============================================================

# 设置工作目录

# 加载包
suppressPackageStartupMessages({
  library(GEOquery)
  library(Biobase)
  library(tidyverse)
})

# 创建子目录
dir.create("01_bulk_rnaseq", showWarnings = FALSE, recursive = TRUE)
dir.create("01_bulk_rnaseq/raw", showWarnings = FALSE, recursive = TRUE)
dir.create("01_bulk_rnaseq/processed", showWarnings = FALSE, recursive = TRUE)
dir.create("01_bulk_rnaseq/qc", showWarnings = FALSE, recursive = TRUE)

# ============================================================
# 数据集元信息（基于GEO官方页面核实）
# ============================================================
datasets <- list(
  GSE163614 = list(
    name = "GSE163614",
    species = "Rattus norvegicus",
    model = "脑缺血再灌注(IRI)",
    platform = "Illumina NovaSeq 6000 (RNA-seq)",
    description = "大鼠脑缺血再灌注损伤，4 IRI + 3对照",
    note = "主发现集，RNA-seq counts数据"
  ),
  GSE61616 = list(
    name = "GSE61616",
    species = "Rattus norvegicus",
    model = "MCAO",
    platform = "Affymetrix Rat Genome 230 2.0 Array",
    description = "大鼠MCAO模型，5缺血+5对照",
    note = "验证集1，微阵列数据"
  ),
  GSE32529 = list(
    name = "GSE32529",
    species = "Mus musculus",
    model = "tMCAO",
    platform = "Affymetrix Mouse Genome 430 2.0 Array",
    description = "小鼠tMCAO模型，4对MCAO/sham",
    note = "验证集2，微阵列数据"
  ),
  GSE137482 = list(
    name = "GSE137482",
    species = "Mus musculus",
    model = "MCAO",
    platform = "RNA-seq",
    description = "小鼠MCAO模型，12 MCAO + 12 sham",
    note = "验证集3，大样本RNA-seq"
  )
)

# ============================================================
# 下载函数
# ============================================================
download_gse <- function(gse_id, dest_dir) {
  cat("\n", strrep("=", 60), "\n", sep = "")
  cat("下载数据集:", gse_id, "\n")
  cat(strrep("=", 60), "\n", sep = "")
  
  # 打印元信息
  if (gse_id %in% names(datasets)) {
    info <- datasets[[gse_id]]
    cat("物种:", info$species, "\n")
    cat("模型:", info$model, "\n")
    cat("平台:", info$platform, "\n")
    cat("描述:", info$description, "\n")
    cat("备注:", info$note, "\n\n")
  }
  
  # 下载GEO series matrix
  tryCatch({
    gse <- getGEO(
      GEO = gse_id,
      destdir = file.path(dest_dir, "raw"),
      GSEMatrix = TRUE,
      AnnotGPL = TRUE
    )
    
    # 如果有多个platform，取第一个
    if (is.list(gse)) {
      gse <- gse[[1]]
    }
    
    cat("下载成功！\n")
    cat("样本数:", ncol(gse), "\n")
    cat("探针数:", nrow(gse), "\n")
    cat("平台:", annotation(gse), "\n")
    
    # 保存ExpressionSet
    saveRDS(gse, file = file.path(dest_dir, "processed", paste0(gse_id, "_eset.rds")))
    cat("已保存ExpressionSet到:", paste0(gse_id, "_eset.rds"), "\n")
    
    # 提取表达矩阵和表型信息
    expr_mat <- exprs(gse)
    pdata <- pData(gse)
    
    # 保存表达矩阵
    write.csv(expr_mat, file = file.path(dest_dir, "processed", paste0(gse_id, "_expression_matrix.csv")),
              row.names = TRUE)
    cat("已保存表达矩阵\n")
    
    # 保存表型信息
    write.csv(pdata, file = file.path(dest_dir, "processed", paste0(gse_id, "_phenotype_data.csv")),
              row.names = TRUE)
    cat("已保存表型信息\n")
    
    # 打印样本信息（前10列的关键信息）
    cat("\n样本标题列表:\n")
    for (i in 1:min(ncol(gse), 20)) {
      cat(sprintf("  %2d. %s\n", i, pdata$title[i]))
    }
    if (ncol(gse) > 20) {
      cat(sprintf("  ... 共 %d 个样本\n", ncol(gse)))
    }
    
    return(list(
      success = TRUE,
      gse = gse,
      n_samples = ncol(gse),
      n_probes = nrow(gse),
      platform = annotation(gse)
    ))
    
  }, error = function(e) {
    cat("下载失败:", conditionMessage(e), "\n")
    cat("可能原因：网络问题、GEO服务器暂时不可用、或数据集不存在\n")
    return(list(success = FALSE, error = conditionMessage(e)))
  })
}

# ============================================================
# 执行下载
# ============================================================
cat("========================================\n")
cat("  Bulk RNA-seq 数据下载\n")
cat("========================================\n\n")

results <- list()
for (gse_id in names(datasets)) {
  results[[gse_id]] <- download_gse(gse_id, "01_bulk_rnaseq")
  # 每个数据集之间暂停2秒，避免给GEO服务器太大压力
  Sys.sleep(2)
}

# ============================================================
# 汇总报告
# ============================================================
cat("\n\n", strrep("=", 60), "\n", sep = "")
cat("下载汇总报告\n")
cat(strrep("=", 60), "\n", sep = "")

report <- data.frame(
  Dataset = character(),
  Species = character(),
  Model = character(),
  Platform = character(),
  Samples = integer(),
  Probes = integer(),
  Status = character(),
  stringsAsFactors = FALSE
)

for (gse_id in names(datasets)) {
  res <- results[[gse_id]]
  info <- datasets[[gse_id]]
  if (res$success) {
    report <- rbind(report, data.frame(
      Dataset = gse_id,
      Species = info$species,
      Model = info$model,
      Platform = info$platform,
      Samples = res$n_samples,
      Probes = res$n_probes,
      Status = "OK",
      stringsAsFactors = FALSE
    ))
  } else {
    report <- rbind(report, data.frame(
      Dataset = gse_id,
      Species = info$species,
      Model = info$model,
      Platform = info$platform,
      Samples = NA,
      Probes = NA,
      Status = paste("FAIL:", res$error),
      stringsAsFactors = FALSE
    ))
  }
}

print(report, row.names = FALSE)

# 保存报告
write.csv(report, file = "01_bulk_rnaseq/qc/01_download_report.csv", row.names = FALSE)
cat("\n报告已保存到: 01_bulk_rnaseq/qc/01_download_report.csv\n")

cat("\n第一批下载完成！\n")
