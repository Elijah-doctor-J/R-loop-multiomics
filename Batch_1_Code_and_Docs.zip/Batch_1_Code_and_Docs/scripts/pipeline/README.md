# Analysis workflow

Run R sources with `Rscript path/to/script.R` and Python sources with
`python path/to/script.py`. Scripts resolve the project root from their location.
Downloaded inputs belong under `data/external/`; new results go under
`outputs/pipeline/` or the output directory stated by each script. Stored
`data/main_tables/` snapshots are not replaced automatically.

## Processing stages

| Scripts | Purpose / prerequisites |
|---|---|
| `00_install_packages.R`, `10_install_analysis_packages.R` | R package setup helpers; require internet |
| `01_download_bulk_rnaseq.R`, `02_download_human_scrnaseq.R`, `03_download_epigenomics.R` | Public dataset downloads; see `docs/DATA_SOURCES.md` |
| `04_qc_batch1.R`, `05_download_supplementary.R`, `06_process_rnaseq_counts.R` | Bulk QC, supplementary downloads and count preparation |
| `08_download_hichip_supplementary.R` | HiChIP supplements; requires GEO record downloaded by stage03 |
| `11_bulk_rnaseq_differential_analysis.R` | Bulk inputs -> DESeq2/limma tables and DESeq2 objects |
| `12_human_validation_analysis.R` | Human microarrays -> blood-support DE |
| `13_functional_enrichment.R`, `13b_enrichment_supplement.R` | Bulk DE and annotation -> GO/GSEA results |
| `14_scrnaseq_analysis.R` | GSE174574 matrices -> Seurat processing; canonical final DE uses the source-export script below |
| `15_atacseq_analysis.R` | Figshare gene scores/metadata -> ATAC processing |
| `16_wgcna_analysis.R` | GSE137482 DESeq2 object -> 24-mouse-sample network, modules, GO and checkpoint |
| `16b_module_trait_statistics.R` | Bundled 24-sample checkpoint -> module/trait statistics (df=22) and sample traits |
| `17_ppi_network.R` | STRING API and bulk DE -> PPI edges, metrics and integrated cohort evidence |
| `19_hichip_analysis.py` | Bundled processed BEDs and mm10 coordinate table -> loop statistics, common-loop comparisons and 32-gene annotation |
| `20_gse225948_analysis.py` | Released GSE225948 count/metadata files -> compact 32-gene expression and metadata |
| `21_figure7_integration.py` | Cohort DE, network, ATAC and true loop evidence -> final 32-gene scores, weight sensitivity and proxy correlation |
| `23_figure5_5_rloop_potential.py` | Supplied feature intermediate -> final 31-gene proxy excluding Ddx19 |

For both single-cell cohorts, run the single canonical downstream step:

```text
python scripts/source_exports/03_recompute_singlecell_de.py
```

The duplicate 14b/20b wrappers are omitted. This step reads bundled processed
expression and metadata, not original reads. Its two output schemas serve
different downstream consumers. Details are in `scripts/source_exports/README.md`.

## Execution and interpretation

Stage21 is the single final integration implementation. It reads supplied
cohort-level tables and produces one score table plus sensitivity results.
To use upstream reruns instead, deliberately stage their validated result
tables into the documented `data/main_tables/` locations. Scripts do not
silently overwrite the supplied evidence snapshots.

STRING download failure is explicit; no hand-assigned substitute network is
used. HiChIP uses supplied mm10 TSS ±50-kb windows and descriptive loop changes.
The potential proxy uses assigned intrinsic features rather than measured
R-loops. Large raw workflows have not been rerun end to end. R before4.2 on
Windows may need the conditional native locale included in these sources.
