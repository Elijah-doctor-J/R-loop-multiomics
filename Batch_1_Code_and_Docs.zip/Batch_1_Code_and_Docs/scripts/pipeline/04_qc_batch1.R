# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(file.path(EXTERNAL, "01_bulk_rnaseq/processed"))

# ============================================================
# 04_qc_batch1.R
# 核查第一批下载的数据完整性
# ============================================================


suppressPackageStartupMessages({
  library(Biobase)
  library(tidyverse)
})

datasets <- c("GSE163614", "GSE61616", "GSE32529", "GSE137482")

for (gse_id in datasets) {
  cat("\n", strrep("=", 70), "\n", sep = "")
  cat("核查数据集:", gse_id, "\n")
  cat(strrep("=", 70), "\n", sep = "")
  
  eset_file <- paste0(gse_id, "_eset.rds")
  
  if (!file.exists(eset_file)) {
    cat("错误: 文件不存在\n")
    next
  }
  
  eset <- readRDS(eset_file)
  
  cat("样本数:", ncol(eset), "\n")
  cat("特征数:", nrow(eset), "\n")
  cat("平台:", annotation(eset), "\n")
  
  # 检查表达矩阵
  expr_mat <- exprs(eset)
  cat("表达矩阵维度:", dim(expr_mat)[1], "x", dim(expr_mat)[2], "\n")
  cat("表达矩阵前3行前3列:\n")
  if (nrow(expr_mat) > 0 && ncol(expr_mat) > 0) {
    print(head(expr_mat[, 1:min(3, ncol(expr_mat))], 3))
  } else {
    cat("  [空矩阵!]\n")
    # 检查是否有assayData
    cat("assayData名称:", names(assayData(eset)), "\n")
  }
  
  # 表型信息
  pdata <- pData(eset)
  cat("\n表型信息列名:", paste(colnames(pdata), collapse=", "), "\n")
  
  # 打印所有样本标题和关键信息
  cat("\n完整样本列表:\n")
  for (i in 1:ncol(eset)) {
    title <- if ("title" %in% colnames(pdata)) pdata$title[i] else "N/A"
    geo_accession <- if ("geo_accession" %in% colnames(pdata)) pdata$geo_accession[i] else "N/A"
    cat(sprintf("  %2d. [%s] %s\n", i, geo_accession, title))
  }
  
  # 检查分组信息
  cat("\n分组推断:\n")
  if ("title" %in% colnames(pdata)) {
    titles <- tolower(pdata$title)
    sham_idx <- grep("sham|ctrl|control|normal", titles)
    mcao_idx <- grep("mcao|model|ischemia|iri|stroke", titles)
    cat("  疑似对照组:", length(sham_idx), "个\n")
    cat("  疑似缺血组:", length(mcao_idx), "个\n")
    if (length(sham_idx) > 0) cat("    对照样本:", paste(pdata$title[sham_idx], collapse="; "), "\n")
    if (length(mcao_idx) > 0) cat("    缺血样本:", paste(pdata$title[mcao_idx], collapse="; "), "\n")
  }
  
  cat("\n")
}

cat("\n", strrep("=", 70), "\n", sep = "")
cat("第一批数据核查完成\n")
cat(strrep("=", 70), "\n", sep = "")
