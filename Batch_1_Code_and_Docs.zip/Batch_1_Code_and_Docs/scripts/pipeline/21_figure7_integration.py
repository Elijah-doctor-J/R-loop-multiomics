"""Rebuild final 32-gene scores and weight sensitivity from cohort-level tables.

HiChIP support comes from loop annotations. See docs/DATA_DICTIONARY.md.
Outputs: outputs/pipeline/08_integration/.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / 'data/main_tables'
OUT = ROOT / 'outputs/pipeline/08_integration'
DIMS = ['bulk_evidence_score', 'human_evidence_score', 'direction_score',
        'wgcna_score', 'ppi_score', 'scrna_score', 'atac_score', 'hichip_score']
LABELS = ['bulk', 'human', 'direction', 'wgcna', 'ppi', 'scrna', 'atac', 'hichip']
# Display order resolves equal scores only; it does not affect score values.
TIE_ORDER = ('Dhx9 Brca1 Pif1 Rnaseh1 Parp1 Ddx21 Brca2 Top1 Rnaseh2a '
             'Thoc6 Vdac1 Bcl7b Thoc7 Thoc2 Ddx1 Ddx3x Rnaseh2b Atm Fancd2 '
             'Thoc1 Thoc3 Thoc5 Ddx5 Fancm Xrn2 Prmt5 Rnaseh2c Aqr Top1mt Setx Atr Ddx19').split()


def read(path):
    return pd.read_csv(DATA / path)


def build_scores():
    curation = pd.read_csv(ROOT / 'data/curated_gene_list/curated_32_rloop_genes.csv')
    s = curation[['gene_mouse', 'gene']].copy().set_index('gene_mouse')
    assert len(s) == 32 and s.index.is_unique
    for acc in ['GSE163614', 'GSE137482', 'GSE61616']:
        d = read(f'01_bulk_transcriptomics/{acc}_rloop_genes.csv').set_index('gene')
        fc, q = ('logFC', 'adj.P.Val') if acc == 'GSE61616' else ('log2FoldChange', 'padj')
        assert d.index.is_unique
        s[f'{acc}_log2FC'] = d[fc]
        s[f'{acc}_padj'] = d[q]
        s[f'{acc}_sig'] = s[f'{acc}_padj'] < .05
    for acc in ['GSE22255', 'GSE16561']:
        d = read(f'02_human_validation/{acc}_rloop_genes.csv').set_index('gene')
        assert d.index.is_unique
        s[f'{acc}_logFC'] = s['gene'].map(d['logFC'])
        s[f'{acc}_padj'] = s['gene'].map(d['adj.P.Val'])
        s[f'{acc}_sig'] = s[f'{acc}_padj'] < .05
    s['bulk_sig_count'] = s[[f'{x}_sig' for x in ['GSE163614', 'GSE137482', 'GSE61616']]].sum(axis=1)
    s['human_sig_count'] = s[['GSE22255_sig', 'GSE16561_sig']].sum(axis=1)
    def majority(row):
        values = row.dropna().to_numpy()
        return max((values > 0).sum(), (values <= 0).sum()) / len(values) if len(values) else 0.
    s['dir_consistency'] = s[['GSE163614_log2FC', 'GSE137482_log2FC', 'GSE61616_log2FC']].apply(majority, axis=1)
    w = read('06_wgcna_network/rloop_module_membership.csv').set_index('gene')
    s['WGCNA_module'] = w['module']
    s['WGCNA_kME'] = w['kME']
    s['wgcna_hub'] = (s['WGCNA_kME'] > .7).astype(int)
    p = read('07_ppi_network/rloop_genes_network_metrics.csv').set_index('gene')
    for col in ['degree', 'betweenness', 'eigenvector']:
        s[f'PPI_{col}'] = s['gene'].map(p[col])
    s['ppi_hub'] = (s['PPI_degree'] > s['PPI_degree'].median()).astype(int)
    d = read('04_scrna_gse174574/GSE174574_rloop_DE_by_celltype.csv')
    sig = d[d.p_adj < .05]
    s['scRNA_sig_celltypes'] = sig.groupby('gene').cell_type.nunique().reindex(s.index, fill_value=0)
    s['scrna_evidence'] = (s.scRNA_sig_celltypes >= 2).astype(int)
    d = read('10_scrna_gse225948/GSE225948_rloop_DE_by_celltype.csv')
    sig = d[(d.pval_D2 < .05) & (d.n_ShamD2 > 5) & (d.n_StrokeD2 > 5)]
    s['gse225948_sig_celltypes'] = sig.groupby('gene').celltype.nunique().reindex(s.index, fill_value=0)
    s['gse225948_evidence'] = (s.gse225948_sig_celltypes > 0).astype(int)
    d = read('05_snatac_accessibility/rloop_differential_accessibility.csv')
    s['ATAC_sig_timepoints'] = d[d.p_adj < .05].groupby('gene').timepoint.nunique().reindex(s.index, fill_value=0)
    s['atac_evidence'] = (s.ATAC_sig_timepoints >= 2).astype(int)
    h = read('09_hichip_contacts/hichip_rloop_gene_loop_annotation.csv').set_index('gene')
    s['HiChIP_Sham_loops'] = h.n_sham
    s['HiChIP_Day6_loops'] = h.n_day6
    assert s[['HiChIP_Sham_loops', 'HiChIP_Day6_loops']].notna().all().all()
    s['hichip_level'] = np.where(s.HiChIP_Day6_loops == 0, 0,
                                np.where(s.HiChIP_Sham_loops > 0, 2, 1))
    s['bulk_evidence_score'] = s.bulk_sig_count.clip(0, 3) / 3 * 2
    s['human_evidence_score'] = s.human_sig_count.clip(0, 2) / 2 * 1.5
    s['direction_score'] = s.dir_consistency * 1.5
    s['wgcna_score'] = s.wgcna_hub * 1.5
    s['ppi_score'] = s.ppi_hub * 1.5
    s['scrna_score'] = s.scrna_evidence + s.gse225948_evidence
    s['atac_score'] = s.atac_evidence.astype(float)
    s['hichip_score'] = s.hichip_level * .75
    s['composite_score'] = s[DIMS].sum(axis=1)
    s = s.reindex(TIE_ORDER).sort_values('composite_score', ascending=False, kind='stable').reset_index()
    s['rank'] = np.arange(1, 33)
    s['tied_rank'] = s.composite_score.round(12).rank(ascending=False, method='min').astype(int)
    return s


def ordinal(values, kind='stable'):
    order = np.argsort(-values, kind=kind)
    ranks = np.empty_like(order)
    ranks[order] = np.arange(1, len(order) + 1)
    return ranks


def sensitivity(s):
    a = s[DIMS].to_numpy(float)
    norm = np.divide(a, a.max(axis=0), out=np.zeros_like(a), where=a.max(axis=0) > 0)
    out = s[['gene_mouse', 'composite_score', 'rank']].rename(columns={
        'gene_mouse': 'gene', 'composite_score': 'baseline_score', 'rank': 'baseline_rank'}).copy()
    out['equalweight_rank'] = ordinal(norm.sum(axis=1))
    weights = np.random.default_rng(20261101).dirichlet(np.ones(8), size=1000)
    # Retain NumPy quicksort for random draws to match the reported convention.
    random_ranks = np.array([ordinal(norm @ w, kind='quicksort') for w in weights])
    out['random_rank_median'] = np.median(random_ranks, axis=0)
    out['random_rank_p5'] = np.percentile(random_ranks, 5, axis=0)
    out['random_rank_p95'] = np.percentile(random_ranks, 95, axis=0)
    out['prob_Top5'] = (random_ranks <= 5).mean(axis=0)
    out['prob_Top10'] = (random_ranks <= 10).mean(axis=0)
    for j, label in enumerate(LABELS):
        out[f'LODO_drop_{label}'] = ordinal(np.delete(norm, j, axis=1).sum(axis=1))
    out['LODO_best_rank'] = out.filter(like='LODO_drop_').min(axis=1)
    out['LODO_worst_rank'] = out.filter(like='LODO_drop_').max(axis=1)
    return out


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    score = build_scores()
    score.to_csv(OUT / 'integrated_hub_gene_scoring.csv', index=False)
    sensitivity(score).to_csv(OUT / 'composite_weight_sensitivity.csv', index=False)
    proxy = read('12_rloop_formation_proxy/rloop_formation_potential_excl_ddx19.csv')
    merged = score.merge(proxy[['gene', 'potential_change']].rename(columns={'gene': 'gene_mouse'}), on='gene_mouse')
    r, p = pearsonr(merged.potential_change, merged.composite_score)
    rho, ps = spearmanr(merged.potential_change, merged.composite_score)
    pd.DataFrame([dict(n=len(merged), pearson_r=r, pearson_p=p, spearman_rho=rho,
                       spearman_p=ps)]).to_csv(OUT / 'proxy_integration_correlation.csv', index=False)
    print(score[['rank', 'gene_mouse', 'composite_score']].head(6).to_string(index=False))
    print(f'Genes with score >= 7: {(score.composite_score >= 7).sum()}')
    print(f'Proxy correlation, n={len(merged)}: r={r:.6f}, p={p:.6f}; rho={rho:.6f}, p={ps:.6f}')


if __name__ == '__main__':
    main()
