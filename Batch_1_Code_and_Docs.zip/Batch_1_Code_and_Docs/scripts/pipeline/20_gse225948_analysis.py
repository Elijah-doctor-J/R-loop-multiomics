"""Extract original GSE225948 per-cell32gene matrix and metadata.
Final rank-sum DE is computed by scripts/source_exports/03_recompute_singlecell_de.py.
This raw extraction stage has not been rerun during public-package preparation.
"""
import pandas as pd
import numpy as np
import os, gzip, traceback
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 9

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
BASE = str(ROOT / 'data/external')
EXT = f'{BASE}/03_scrnaseq/supplementary/GSE225948/extracted'
OUT = str(ROOT / 'outputs/pipeline/10_gse225948')
os.makedirs(f'{OUT}/figures', exist_ok=True)

sample_info = {
    'GSM7060815': ('Sham', 'D2'), 'GSM7060816': ('Sham', 'D2'),
    'GSM7060817': ('Sham', 'D2'), 'GSM7060818': ('Sham', 'D2'),
    'GSM7060819': ('Stroke', 'D2'), 'GSM7060820': ('Stroke', 'D2'),
    'GSM7060821': ('Stroke', 'D2'), 'GSM7060822': ('Stroke', 'D2'),
    'GSM7060823': ('Stroke', 'D14'), 'GSM7060824': ('Stroke', 'D14'),
    'GSM7060825': ('Stroke', 'D14'), 'GSM7060826': ('Stroke', 'D14'),
}
rloop_genes = ['Rnaseh1','Rnaseh2a','Rnaseh2b','Rnaseh2c','Top1','Top1mt','Setx','Dhx9',
                'Ddx1','Ddx3x','Ddx5','Ddx19','Ddx21','Aqr','Pif1','Fancm','Brca1','Brca2',
                'Fancd2','Atr','Atm','Parp1','Thoc1','Thoc2','Thoc3','Thoc5','Thoc6','Thoc7',
                'Xrn2','Prmt5','Bcl7b','Vdac1']
groups = ['Sham_D2', 'Stroke_D2', 'Stroke_D14']

def mannwhitney_u(x, y):
    x = np.array(x, dtype=float); y = np.array(y, dtype=float)
    x = x[~np.isnan(x)]; y = y[~np.isnan(y)]
    n1, n2 = len(x), len(y)
    if n1 < 3 or n2 < 3: return 1.0
    combined = np.concatenate([x, y])
    ranks = pd.Series(combined).rank().values
    r1 = ranks[:n1].sum()
    u1 = r1 - n1 * (n1 + 1) / 2
    u = min(u1, n1 * n2 - u1)
    mu = n1 * n2 / 2
    sigma = np.sqrt(n1 * n2 * (n1 + n2 + 1) / 12)
    if sigma == 0: return 1.0
    z = (u - mu) / sigma
    from math import erf, sqrt
    return 2 * (1 - 0.5 * (1 + erf(abs(z) / sqrt(2))))

# Load one sample
def load_sample(gsm, group, time):
    counts_file = [f for f in os.listdir(EXT) if gsm in f and 'counts' in f][0]
    meta_file = [f for f in os.listdir(EXT) if gsm in f and 'metadata' in f][0]

    with gzip.open(f'{EXT}/{meta_file}', 'rt') as fh:
        meta = pd.read_csv(fh, index_col=0)
    meta['sample'] = gsm; meta['group'] = group; meta['timepoint'] = time
    meta['cell_id'] = meta.index

    with gzip.open(f'{EXT}/{counts_file}', 'rt') as fh:
        header = fh.readline().strip().split(',')
        cell_barcodes = [c.strip('"') for c in header[1:]]
        rloop_data = {g: [0.0]*len(cell_barcodes) for g in rloop_genes}
        for line in fh:
            parts = line.strip().split(',')
            gene = parts[0].strip('"')
            if gene in rloop_data:
                try:
                    rloop_data[gene] = [float(x) for x in parts[1:]]
                except ValueError as exc:
                    raise ValueError(f'Invalid counts for {gsm} / {gene}') from exc

    expr_df = pd.DataFrame(rloop_data, index=cell_barcodes)
    expr_df.index = [f'{gsm}_{c}' for c in expr_df.index]
    meta['cell_id'] = meta['cell_id'].apply(lambda c: f'{gsm}_{c}')
    return expr_df, meta

# Load all samples
all_expr = []
all_meta = []
for gsm, (group, time) in sample_info.items():
    try:
        expr, meta = load_sample(gsm, group, time)
        all_expr.append(expr)
        all_meta.append(meta)
        print(f'  {gsm} ({group} {time}): {len(expr)} cells OK')
    except Exception as e:
        print(f'  {gsm}: FAILED - {e}')
        traceback.print_exc()

assert len(all_expr) == 12, 'All 12 public source samples must load; partial cohorts are not accepted.'
print(f'\nLoaded {len(all_expr)}/12 samples')
expr_all = pd.concat(all_expr)
meta_all = pd.concat(all_meta, ignore_index=True)
print(f'Total cells: expr={len(expr_all)}, meta={len(meta_all)}')

# Save
meta_all.to_csv(f'{OUT}/GSE225948_merged_metadata.csv', index=False)
expr_all.to_csv(f'{OUT}/GSE225948_rloop_expression.csv')
print('Saved CSV')
