# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 12_human_validation_analysis.R
# 人源缺血性卒中血液微阵列验证分析
# 数据集: GSE22255 (20 IS + 20 Control, GPL570)
#         GSE16561 (39 IS + 24 Control, GPL6883)
# ============================================================


suppressPackageStartupMessages({
  library(limma)
  library(Biobase)
  library(tidyverse)
  library(pheatmap)
  library(EnhancedVolcano)
  library(org.Hs.eg.db)
  library(clusterProfiler)
})

dir.create(file.path(RESULTS, "02_human_validation"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(RESULTS, "02_human_validation/figures"), recursive = TRUE, showWarnings = FALSE)

# R-loop基因集（人类）
rloop_genes <- c(
  "RNASEH1", "RNASEH2A", "RNASEH2B", "RNASEH2C",
  "TOP1", "TOP1MT", "SETX", "DHX9", "DDX1", "DDX3X", "DDX5",
  "DDX19", "DDX21", "AQR", "PIF1", "FANCM",
  "BRCA1", "BRCA2", "FANCD2", "ATR", "ATM", "PARP1",
  "THOC1", "THOC2", "THOC3", "THOC5", "THOC6", "THOC7",
  "XRN2", "PRMT5", "BCL7B", "VDAC1"
)

# ============================================================
# 1. GSE22255: 人缺血性卒中PBMC (GPL570, Affymetrix HG-U133 Plus 2.0)
# ============================================================
cat("========================================\n")
cat("  1. GSE22255 差异分析 (limma)\n")
cat("========================================\n")

eset_222 <- readRDS("02_human_validation/processed/GSE22255_eset.rds")
expr_222 <- exprs(eset_222)
pdata_222 <- pData(eset_222)
cat("表达矩阵:", nrow(expr_222), "probes x", ncol(expr_222), "samples\n")

# 分组
pdata_222$group <- ifelse(grepl("IS_", pdata_222$title), "IS", "Control")
cat("分组:\n"); print(table(pdata_222$group))

group_222 <- factor(pdata_222$group, levels = c("Control", "IS"))

# 探针注释：GPL570 -> Gene Symbol
gpl_222 <- read.delim(gzfile("02_human_validation/raw/GPL570.annot.gz"),
                      skip = 27, stringsAsFactors = FALSE,
                      check.names = FALSE, quote = "", sep = "\t")
id_col <- grep("^ID$", colnames(gpl_222), value = TRUE)[1]
symbol_col <- grep("Gene [Ss]ymbol", colnames(gpl_222), value = TRUE)[1]
cat("注释列:", id_col, "/", symbol_col, "\n")

probe_map_222 <- gpl_222[, c(id_col, symbol_col)]
colnames(probe_map_222) <- c("probe_id", "symbol")
probe_map_222$symbol <- sapply(strsplit(as.character(probe_map_222$symbol), " /// "),
                                function(x) x[1])
probe_map_222 <- probe_map_222[probe_map_222$symbol != "" & !is.na(probe_map_222$symbol), ]
probe_map_222 <- probe_map_222[!duplicated(probe_map_222$probe_id), ]

common_probes_222 <- intersect(rownames(expr_222), probe_map_222$probe_id)
expr_222_annot <- expr_222[common_probes_222, ]
symbols_222 <- probe_map_222$symbol[match(common_probes_222, probe_map_222$probe_id)]

expr_222_df <- as.data.frame(expr_222_annot)
expr_222_df$symbol <- symbols_222
expr_222_collapsed <- expr_222_df %>%
  group_by(symbol) %>%
  summarise(across(everything(), mean)) %>%
  column_to_rownames("symbol")
cat("注释后:", nrow(expr_222_collapsed), "genes x", ncol(expr_222_collapsed), "samples\n")

# limma
design_222 <- model.matrix(~ group_222)
fit_222 <- lmFit(as.matrix(expr_222_collapsed), design_222)
fit_222 <- eBayes(fit_222)
res_222 <- topTable(fit_222, coef = 2, number = Inf, adjust.method = "BH")
res_222$gene <- rownames(res_222)

deg_222_up <- sum(res_222$adj.P.Val < 0.05 & res_222$logFC > log2(1.5), na.rm = TRUE)
deg_222_down <- sum(res_222$adj.P.Val < 0.05 & res_222$logFC < -log2(1.5), na.rm = TRUE)
cat(sprintf("GSE22255差异基因: %d上调, %d下调\n", deg_222_up, deg_222_down))

rloop_in_222 <- res_222[res_222$gene %in% rloop_genes, ]
cat("\nR-loop基因在GSE22255中的变化:\n")
print(rloop_in_222[, c("gene", "logFC", "adj.P.Val")])

write.csv(res_222, file.path(RESULTS, "02_human_validation/GSE22255_limma_results.csv"), row.names = FALSE)
write.csv(rloop_in_222, file.path(RESULTS, "02_human_validation/GSE22255_rloop_genes.csv"), row.names = FALSE)
saveRDS(res_222, file.path(RESULTS, "02_human_validation/GSE22255_res.rds"))

# ============================================================
# 2. GSE16561: 人缺血性卒中血液 (GPL6883, Illumina humanRef-8 v3.0)
# ============================================================
cat("\n\n========================================\n")
cat("  2. GSE16561 差异分析 (limma)\n")
cat("========================================\n")

eset_165 <- readRDS("02_human_validation/processed/GSE16561_eset.rds")
expr_165 <- exprs(eset_165)
pdata_165 <- pData(eset_165)
cat("表达矩阵:", nrow(expr_165), "probes x", ncol(expr_165), "samples\n")

# 分组
pdata_165$group <- ifelse(grepl("Stroke", pdata_165$title), "IS", "Control")
cat("分组:\n"); print(table(pdata_165$group))

group_165 <- factor(pdata_165$group, levels = c("Control", "IS"))

# 探针注释：GPL6883 -> Gene Symbol（使用预处理好的干净注释文件）
gpl_165 <- read.csv("02_human_validation/raw/GPL6883_clean.csv",
                    stringsAsFactors = FALSE)
id_col_165 <- "ID"
symbol_col_165 <- "Gene symbol"
cat("注释列:", id_col_165, "/", symbol_col_165, "\n")

probe_map_165 <- gpl_165[, c(1, 2)]
colnames(probe_map_165) <- c("probe_id", "symbol")
probe_map_165$symbol <- sapply(strsplit(as.character(probe_map_165$symbol), " /// "),
                                function(x) x[1])
probe_map_165 <- probe_map_165[probe_map_165$symbol != "" & !is.na(probe_map_165$symbol), ]
probe_map_165 <- probe_map_165[!duplicated(probe_map_165$probe_id), ]

common_probes_165 <- intersect(rownames(expr_165), probe_map_165$probe_id)
expr_165_annot <- expr_165[common_probes_165, ]
symbols_165 <- probe_map_165$symbol[match(common_probes_165, probe_map_165$probe_id)]

expr_165_df <- as.data.frame(expr_165_annot)
expr_165_df$symbol <- symbols_165
expr_165_collapsed <- expr_165_df %>%
  group_by(symbol) %>%
  summarise(across(everything(), mean)) %>%
  column_to_rownames("symbol")
cat("注释后:", nrow(expr_165_collapsed), "genes x", ncol(expr_165_collapsed), "samples\n")

# limma
design_165 <- model.matrix(~ group_165)
fit_165 <- lmFit(as.matrix(expr_165_collapsed), design_165)
fit_165 <- eBayes(fit_165)
res_165 <- topTable(fit_165, coef = 2, number = Inf, adjust.method = "BH")
res_165$gene <- rownames(res_165)

deg_165_up <- sum(res_165$adj.P.Val < 0.05 & res_165$logFC > log2(1.5), na.rm = TRUE)
deg_165_down <- sum(res_165$adj.P.Val < 0.05 & res_165$logFC < -log2(1.5), na.rm = TRUE)
cat(sprintf("GSE16561差异基因: %d上调, %d下调\n", deg_165_up, deg_165_down))

rloop_in_165 <- res_165[res_165$gene %in% rloop_genes, ]
cat("\nR-loop基因在GSE16561中的变化:\n")
print(rloop_in_165[, c("gene", "logFC", "adj.P.Val")])

write.csv(res_165, file.path(RESULTS, "02_human_validation/GSE16561_limma_results.csv"), row.names = FALSE)
write.csv(rloop_in_165, file.path(RESULTS, "02_human_validation/GSE16561_rloop_genes.csv"), row.names = FALSE)
saveRDS(res_165, file.path(RESULTS, "02_human_validation/GSE16561_res.rds"))

# ============================================================
# 3. 两个人源数据集meta分析（取交集）
# ============================================================
cat("\n\n========================================\n")
cat("  3. 人源数据集交集分析\n")
cat("========================================\n")

# 显著差异基因交集
sig_222 <- res_222$gene[res_222$adj.P.Val < 0.05]
sig_165 <- res_165$gene[res_165$adj.P.Val < 0.05]
common_sig <- intersect(sig_222, sig_165)
cat(sprintf("GSE22255显著基因: %d\n", length(sig_222)))
cat(sprintf("GSE16561显著基因: %d\n", length(sig_165)))
cat(sprintf("交集: %d\n", length(common_sig)))

# R-loop基因在人源数据中的一致性
rloop_human_summary <- data.frame(
  gene = rloop_genes,
  GSE22255_logFC = NA, GSE22255_padj = NA,
  GSE16561_logFC = NA, GSE16561_padj = NA
)
for (g in rloop_genes) {
  if (g %in% res_222$gene) {
    rloop_human_summary[rloop_human_summary$gene == g, c("GSE22255_logFC", "GSE22255_padj")] <-
      res_222[res_222$gene == g, c("logFC", "adj.P.Val")]
  }
  if (g %in% res_165$gene) {
    rloop_human_summary[rloop_human_summary$gene == g, c("GSE16561_logFC", "GSE16561_padj")] <-
      res_165[res_165$gene == g, c("logFC", "adj.P.Val")]
  }
}
cat("\nR-loop基因在人源数据中的变化:\n")
print(rloop_human_summary, row.names = FALSE)
write.csv(rloop_human_summary, file.path(RESULTS, "02_human_validation/rloop_genes_human.csv"), row.names = FALSE)

# 核心分子
cat("\n核心分子在人源数据中的验证:\n")
for (g in c("RNASEH1", "BCL7B", "VDAC1")) {
  cat(sprintf("\n%s:\n", g))
  if (g %in% res_222$gene) {
    r <- res_222[res_222$gene == g, ]
    cat(sprintf("  GSE22255: logFC=%.3f, padj=%.4f %s\n",
                r$logFC, r$adj.P.Val, ifelse(r$adj.P.Val < 0.05, "*", "")))
  }
  if (g %in% res_165$gene) {
    r <- res_165[res_165$gene == g, ]
    cat(sprintf("  GSE16561: logFC=%.3f, padj=%.4f %s\n",
                r$logFC, r$adj.P.Val, ifelse(r$adj.P.Val < 0.05, "*", "")))
  }
}

cat("\n\n人源验证分析完成！\n")
