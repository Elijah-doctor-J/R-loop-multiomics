# Final source exports and single-cell differential results

This directory consolidates the scientific export/correction steps that were
performed after the initial analysis. It contains one version of each operation,
with project-relative paths. It does not edit manuscript files, replace stored
tables, create backups or silently update the evidence snapshots.

| Script | Required input | Generated output | Figure/table use |
|---|---|---|---|
| `01_export_gse174574_sources.R` | `data/external/checkpoints/GSE174574_seurat.rds` with RNA data layer, UMAP and `cell_type/group/sample` metadata | `outputs/source_exports/gse174574/`: UMAP, composition, 31-gene expression, mean expression score, AddModuleScore, dot-plot and selected marker sources; sessionInfo | Figure 5A–G; final GSE174574 DE in S3 |
| `02_export_atac_sources.R` | `data/external/checkpoints/atac_seurat.rds` with data/counts, PCA, `timepoint/cell_type/Sample` metadata | `outputs/source_exports/atac/`: per-cell-mean gene activity by timepoint/cell type, composition and PCA-based UMAP; sessionInfo | Figure 7A–D; final per-cell-mean activity inputs |
| `03_recompute_singlecell_de.py` | Bundled `data/figure_source/gse174574/gse174574_31genes_expression.csv`; Figure 5 UMAP cell annotations; bundled GSE225948 metadata/expression and final DE snapshots | `outputs/source_exports/`: two GSE174574 DE CSVs, GSE225948 DE CSV and `singlecell_de_comparison.json` | Figure 5E–F; single-cell sheets of S3; DE evidence used downstream |

## Run the verified processed-data step

From the repository root:

```sh
python scripts/source_exports/03_recompute_singlecell_de.py
```

The script checks exact cell-ID mapping and result-key coverage, computes
Mann–Whitney rank-sum tests, writes new outputs separately, and compares every
numeric column against the supplied final tables. It fails visibly if result
keys or numeric values differ. It does not overwrite `data/`.

## Meaning of the legacy columns

- GSE174574: `log2FC` is the difference in mean stored log-normalized expression
  (MCAO minus Sham). Its name is retained for compatibility with the final files;
  it is not a base-2 fold change. `p_value` is the two-sided per-cell rank-sum
  p-value. `p_adj` is Benjamini–Hochberg correction across all 341 tests.
- GSE225948: `logFC_D2` is mean supplied expression at Stroke D2 minus Sham.
  `logFC_D14` is mean supplied expression at Stroke D14 minus Stroke D2.
  `pval_D2` and `pval_D14` are raw two-sided per-cell rank-sum p-values. These
  columns do not contain a multiple-testing correction. The script reproduces
  the stored data layer; it does not relabel that layer as Seurat-normalized
  expression or convert its means into fold changes.
- Cells are the units of these rank-sum tests. They do not provide an
  animal-level inferential analysis. Per-animal composition and other revision
  analyses are described in `scripts/revision_R4/README.md`.

## Checkpoint exports and limits

The R exporters require a Seurat version supporting the `layer=` API. Large
GSE174574 and ATAC checkpoints (approximately 684 MB and 4.8 GB) are not included.
Both exporters stop with a specific missing-input message when required.

Existing checkpoint cell annotations and embeddings are required, and the
original historical package versions were not fully recorded. The ATAC UMAP
export uses PCA dimensions 1:30 and seed 42, matching the final export settings;
identical coordinates across package versions are not guaranteed. Bundled
coordinate/summary CSVs permit panel regeneration without the checkpoints.
