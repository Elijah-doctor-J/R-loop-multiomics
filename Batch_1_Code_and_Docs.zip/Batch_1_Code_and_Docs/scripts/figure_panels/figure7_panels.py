# -*- coding: utf-8 -*-
"""
Figure 6: snATAC-seq chromatin accessibility dynamics around R-loop genes.
Panels:
  A  UMAP (cell type + timepoint)           <- atac_umap_coords.csv (computed in R)
  B  Cell composition across timepoints     <- atac_composition.csv
  C  R-loop gene activity across timepoints <- rloop_activity_by_timepoint.csv
  D  R-loop gene activity across cell types <- rloop_activity_by_celltype.csv
  E  31-gene x 6-timepoint log2FC heatmap   <- rloop_differential_accessibility.csv
  F  Representative gene trajectories       <- rloop_activity_by_timepoint.csv
  G  scRNA vs snATAC log2FC concordance     <- GSE174574 DE + rloop_DE_by_celltype_M24h.csv
"""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
import os, sys
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from scipy import stats

# ---------- global style ----------
mpl.rcParams.update({
    'font.family': 'Arial',
    'font.size': 9,
    'axes.linewidth': 0.8,
    'axes.edgecolor': '#333333',
    'axes.labelcolor': '#222222',
    'xtick.color': '#333333',
    'ytick.color': '#333333',
    'xtick.major.width': 0.8,
    'ytick.major.width': 0.8,
    'pdf.fonttype': 42, 'ps.fonttype': 42,
    'svg.fonttype': 'none',
})

BASE = ROOT / 'data/main_tables/05_snatac_accessibility'
RNA_DE = ROOT / 'data/main_tables/04_scrna_gse174574/GSE174574_rloop_DE_by_celltype.csv'
TMP = ROOT / 'data/figure_source/atac'
OUT = ROOT / 'outputs/figures/Figure7'
os.makedirs(OUT, exist_ok=True)

TP_ORDER = ['Sham1d','M0h','M6h','M12h','M24h','M7d','M14d']
TP_LABEL = {'Sham1d':'Sham','M0h':'0 h','M6h':'6 h','M12h':'12 h','M24h':'24 h','M7d':'7 d','M14d':'14 d'}
DA_ORDER = ['M0h','M6h','M12h','M24h','M7d','M14d']
DA_LABEL = {'M0h':'0 h','M6h':'6 h','M12h':'12 h','M24h':'24 h','M7d':'7 d','M14d':'14 d'}

# 8 cell types, display names and colors
CT_ORDER = ['Ex_Neurons','In_Neurons','Astrocytes','Olig.','Microglia','OPC','Endothelial','Fibroblast']
CT_DISPLAY = {'Ex_Neurons':'Ex neurons','In_Neurons':'In neurons','Astrocytes':'Astrocytes',
              'Olig.':'Oligodendrocytes','Microglia':'Microglia','OPC':'OPC',
              'Endothelial':'Endothelial','Fibroblast':'Fibroblast'}
CT_COLORS = {'Ex_Neurons':'#4C72B0','In_Neurons':'#7BA7D7','Astrocytes':'#55A868',
             'Olig.':'#8172B3','Microglia':'#C44E52','OPC':'#CCB974',
             'Endothelial':'#DD8452','Fibroblast':'#937860'}

# functional modules (same scheme as Figure 4/5)
FUNC_OF = {}
for g in ['Rnaseh1','Rnaseh2a','Rnaseh2b','Rnaseh2c','Setx','Top1','Top1mt','Pif1']: FUNC_OF[g]=1
for g in ['Ddx1','Ddx3x','Ddx5','Ddx21','Dhx9','Aqr']: FUNC_OF[g]=2
for g in ['Atm','Atr','Brca1','Brca2','Parp1','Fancd2','Fancm']: FUNC_OF[g]=3
for g in ['Thoc1','Thoc2','Thoc3','Thoc5','Thoc6','Thoc7','Xrn2','Prmt5']: FUNC_OF[g]=4
FUNC_OF['Bcl7b']=5; FUNC_OF['Vdac1']=6
FUNC_COLORS = {1:'#c0504d',2:'#e0a030',3:'#7a8fb0',4:'#5a8a6a',5:'#8e7ab5',6:'#6fb3b8'}
FUNC_NAMES = {1:'R-loop/hybrid resolution',2:'RNA helicases & RNP',3:'DNA-damage response',
              4:'RNA processing/export',5:'Chromatin',6:'Mitochondrial'}
GENE_ORDER = sorted(FUNC_OF, key=lambda g:(FUNC_OF[g], g))

# timepoint gradient colors (Sham gray -> acute red -> late blue)
TP_COLORS = {'Sham1d':'#999999','M0h':'#d6604d','M6h':'#f4a582','M12h':'#fddbc7',
             'M24h':'#d1e5f0','M7d':'#92c5de','M14d':'#4393c3'}

def save(fig, name):
    for ext in ['png','pdf','svg']:
        fig.savefig(os.path.join(OUT, f'{name}.{ext}'), dpi=600, bbox_inches='tight',
                    facecolor='white', edgecolor='none')
    plt.close(fig)
    print('saved', name)

# ============================================================ A: UMAP dual
def panel_a():
    um = pd.read_csv(os.path.join(TMP,'atac_umap_coords.csv'), index_col=0)
    # subsample for plotting: cap each cell_type at 3000
    rng = np.random.RandomState(42)
    parts = []
    for ct, d in um.groupby('cell_type'):
        if len(d) > 3000:
            d = d.sample(3000, random_state=rng)
        parts.append(d)
    sub = pd.concat(parts).sample(frac=1, random_state=1)  # shuffle to avoid overlay bias

    fig, axs = plt.subplots(1, 2, figsize=(9.6, 5.0))
    # --- left: cell type ---
    ax = axs[0]
    for ct in CT_ORDER:
        d = sub[sub.cell_type==ct]
        ax.scatter(d.umap_1, d.umap_2, s=1.2, color=CT_COLORS[ct], label=CT_DISPLAY[ct],
                   alpha=0.7, linewidths=0, rasterized=True)
    ax.set_title(f'Cell types (n = {len(um):,})', fontsize=9.5, fontweight='bold')
    ax.set_xlabel('UMAP 1'); ax.set_ylabel('UMAP 2')
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_linewidth(0.8)
    ax.legend(markerscale=4, frameon=False, fontsize=7.2, loc='upper center',
              bbox_to_anchor=(0.5,-0.06), ncol=2, handletextpad=0.3, columnspacing=1.0)
    # --- right: timepoint ---
    ax = axs[1]
    for t in TP_ORDER:
        d = sub[sub.timepoint==t]
        ax.scatter(d.umap_1, d.umap_2, s=1.2, color=TP_COLORS[t], label=TP_LABEL[t],
                   alpha=0.7, linewidths=0, rasterized=True)
    ax.set_title('Time after reperfusion', fontsize=9.5, fontweight='bold')
    ax.set_xlabel('UMAP 1'); ax.set_ylabel('UMAP 2')
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_linewidth(0.8)
    ax.legend(markerscale=4, frameon=False, fontsize=7.2, loc='upper center',
              bbox_to_anchor=(0.5,-0.06), ncol=4, handletextpad=0.3, columnspacing=1.0,
              title='Timepoint', title_fontsize=7.5)
    fig.subplots_adjust(left=0.04, right=0.98, top=0.93, bottom=0.18, wspace=0.12)
    save(fig,'Figure7A_umap')

# ============================================================ B: composition
def panel_b():
    comp = pd.read_csv(os.path.join(TMP,'atac_composition.csv'))
    pv = comp.pivot(index='timepoint', columns='cell_type', values='n').reindex(TP_ORDER)[CT_ORDER]
    pct = pv.div(pv.sum(axis=1), axis=0) * 100

    fig, ax = plt.subplots(figsize=(5.2, 2.8))
    left = np.zeros(len(TP_ORDER))
    x = np.arange(len(TP_ORDER))
    for ct in CT_ORDER:
        vals = pct[ct].values
        ax.bar(x, vals, bottom=left, width=0.72, color=CT_COLORS[ct], label=CT_DISPLAY[ct],
               edgecolor='white', linewidth=0.4)
        left += vals
    ax.set_xticks(x); ax.set_xticklabels([TP_LABEL[t] for t in TP_ORDER], fontsize=8)
    ax.set_ylabel('Cell composition (%)')
    ax.set_xlabel('Time after reperfusion')
    ax.set_ylim(0,100)
    ax.set_xlim(-0.5, len(TP_ORDER)-0.5)
    ax.legend(bbox_to_anchor=(1.01,1), loc='upper left', frameon=False, fontsize=7,
              title='Cell type', title_fontsize=7.5, handlelength=1.0, borderaxespad=0)
    ax.spines[['top','right']].set_visible(False)
    save(fig,'Figure7B_composition')

# ============================================================ C: activity by timepoint (PER-CELL MEAN, cell-count adjusted)
def panel_c():
    tp = pd.read_csv(os.path.join(BASE,'rloop_mean_activity_by_timepoint.csv'))
    fig, ax = plt.subplots(figsize=(4.6,3.2))
    data = [tp[tp.timepoint==t]['mean_logdata'].values for t in TP_ORDER]
    bp = ax.boxplot(data, positions=range(len(TP_ORDER)), widths=0.55, patch_artist=True,
                    showfliers=False, zorder=2,
                    medianprops=dict(color='#222222', linewidth=1.1),
                    whiskerprops=dict(color='#555555', linewidth=0.8),
                    capprops=dict(color='#555555', linewidth=0.8),
                    boxprops=dict(linewidth=0.8))
    for patch, t in zip(bp['boxes'], TP_ORDER):
        patch.set_facecolor(TP_COLORS[t]); patch.set_alpha(0.85)
    # overlay individual genes as light dots
    for i, t in enumerate(TP_ORDER):
        vals = tp[tp.timepoint==t]['mean_logdata'].values
        xj = np.random.RandomState(i).normal(i, 0.06, len(vals))
        ax.scatter(xj, vals, s=6, color='#333333', alpha=0.3, zorder=3, linewidths=0)
    ax.set_xticks(range(len(TP_ORDER)))
    ax.set_xticklabels([TP_LABEL[t] for t in TP_ORDER], fontsize=8)
    ax.set_ylabel('Mean gene activity per nucleus\n(log-normalized)')
    ax.set_xlabel('Time after reperfusion')
    ax.grid(axis='y', alpha=0.25, linewidth=0.5, zorder=0)
    ax.spines[['top','right']].set_visible(False)
    save(fig,'Figure7C_activity_timepoint')

# ============================================================ D: activity by celltype (PER-CELL MEAN)
def panel_d():
    ct = pd.read_csv(os.path.join(BASE,'rloop_mean_activity_by_celltype.csv'))
    ct['cell_type'] = ct['cell_type'].replace({'Ex-Neurons':'Ex_Neurons','In-Neurons':'In_Neurons'})
    order = CT_ORDER
    fig, ax = plt.subplots(figsize=(5.0,3.2))
    data = [ct[ct.cell_type==c]['mean_logdata'].values for c in order]
    bp = ax.boxplot(data, positions=range(len(order)), widths=0.6, patch_artist=True,
                    showfliers=False, zorder=2,
                    medianprops=dict(color='#222222', linewidth=1.1),
                    whiskerprops=dict(color='#555555', linewidth=0.8),
                    capprops=dict(color='#555555', linewidth=0.8),
                    boxprops=dict(linewidth=0.8))
    for patch, c in zip(bp['boxes'], order):
        patch.set_facecolor(CT_COLORS[c]); patch.set_alpha(0.85)
    for i, c in enumerate(order):
        vals = ct[ct.cell_type==c]['mean_logdata'].values
        xj = np.random.RandomState(i+100).normal(i, 0.06, len(vals))
        ax.scatter(xj, vals, s=6, color='#333333', alpha=0.3, zorder=3, linewidths=0)
    ax.set_xticks(range(len(order)))
    ax.set_xticklabels([CT_DISPLAY[c] for c in order], rotation=35, ha='right', fontsize=7.5)
    ax.set_ylabel('Mean gene activity per nucleus\n(log-normalized)')
    ax.grid(axis='y', alpha=0.25, linewidth=0.5, zorder=0)
    ax.spines[['top','right']].set_visible(False)
    save(fig,'Figure7D_activity_celltype')

# ============================================================ E: temporal heatmap
def panel_e():
    da = pd.read_csv(os.path.join(BASE,'rloop_differential_accessibility.csv'))
    mat = da.pivot(index='gene', columns='timepoint', values='log2FC').reindex(index=GENE_ORDER, columns=DA_ORDER)
    padj = da.pivot(index='gene', columns='timepoint', values='p_adj').reindex(index=GENE_ORDER, columns=DA_ORDER)
    Z = mat.values
    vmax = np.nanmax(np.abs(Z))
    vmax = 0.12  # symmetric clip for readability

    fig, axs = plt.subplots(1, 2, gridspec_kw={'width_ratios':[0.035,1]}, figsize=(4.8,7.2))
    # left functional strip
    axs[0].set_xlim(0,1); axs[0].set_ylim(len(GENE_ORDER),0)
    for i,g in enumerate(GENE_ORDER):
        axs[0].add_patch(plt.Rectangle((0,i),1,1, color=FUNC_COLORS[FUNC_OF[g]]))
    axs[0].set_xticks([]); axs[0].set_yticks([])
    for s in axs[0].spines.values(): s.set_visible(False)

    ax = axs[1]
    cmap = LinearSegmentedColormap.from_list('rb', ['#2166ac','#f7f7f7','#b2182b'])
    im = ax.imshow(Z, aspect='auto', cmap=cmap, vmin=-vmax, vmax=vmax, interpolation='nearest')
    ax.set_xticks(range(len(DA_ORDER)))
    ax.set_xticklabels([DA_LABEL[t] for t in DA_ORDER], fontsize=8)
    ax.set_yticks(range(len(GENE_ORDER)))
    ax.set_yticklabels(GENE_ORDER, fontsize=7.5, style='italic')
    ax.set_xlabel('Time after reperfusion (vs Sham)')
    # outline significant cells (all are significant here, but mark strong ones)
    for i in range(Z.shape[0]):
        for j in range(Z.shape[1]):
            if not np.isnan(Z[i,j]) and padj.values[i,j] < 0.05 and abs(Z[i,j]) >= 0.05:
                ax.add_patch(plt.Rectangle((j-0.5,i-0.5),1,1, fill=False,
                                           edgecolor='#333333', linewidth=0.5))
    ax.set_xticks(np.arange(-.5,len(DA_ORDER),1), minor=True)
    ax.set_yticks(np.arange(-.5,len(GENE_ORDER),1), minor=True)
    ax.grid(which='minor', color='white', linewidth=0.4)
    ax.tick_params(which='minor', length=0)
    for s in ['top','bottom','left','right']:
        ax.spines[s].set_linewidth(0.8)
    # colorbar
    cbar = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02)
    cbar.set_label('log2 fold-change (accessibility)', fontsize=8)
    cbar.ax.tick_params(labelsize=7)
    # module legend
    handles = [plt.Rectangle((0,0),1,1, color=FUNC_COLORS[k]) for k in range(1,7)]
    ax.legend(handles, [FUNC_NAMES[k] for k in range(1,7)], loc='upper left',
              bbox_to_anchor=(1.18,1.0), frameon=False, fontsize=6.8, title='Functional module',
              title_fontsize=7.2, handlelength=1.0)
    fig.subplots_adjust(left=0.02, right=0.82, top=0.99, bottom=0.06, wspace=0.03)
    save(fig,'Figure7E_temporal_heatmap')

# ============================================================ F: representative gene log2FC trajectories (same source as Panel E, per-cell-mean based)
def panel_f():
    da = pd.read_csv(os.path.join(BASE,'rloop_differential_accessibility.csv'))
    rep = ['Rnaseh1','Bcl7b','Ddx21','Top1','Pif1']
    rep_color = {'Rnaseh1':'#c0504d','Bcl7b':'#8e7ab5','Ddx21':'#e0a030','Top1':'#4C72B0','Pif1':'#55A868'}
    # x positions: Sham (=0) then 6 MCAO timepoints
    xlabels = ['Sham'] + [DA_LABEL[t] for t in DA_ORDER]
    x = np.arange(len(xlabels))
    fig, ax = plt.subplots(figsize=(4.9,3.4))
    for g in rep:
        s = da[da.gene==g].set_index('timepoint')['log2FC'].reindex(DA_ORDER).values
        y = np.concatenate([[0.0], s])  # Sham reference = 0
        ax.plot(x, y, '-o', color=rep_color[g], lw=1.6, ms=4.5, label=g, zorder=3)
    ax.axhline(0, color='#888888', ls='--', lw=0.9, zorder=1)
    ax.set_xticks(x); ax.set_xticklabels(xlabels, fontsize=8)
    ax.set_ylabel('Accessibility log2FC vs Sham')
    ax.set_xlabel('Time after reperfusion')
    ax.set_ylim(-0.145, 0.135)
    ax.legend(frameon=False, fontsize=7.5, ncol=1, loc='upper right', handlelength=1.6)
    ax.grid(axis='y', alpha=0.25, linewidth=0.5)
    ax.spines[['top','right']].set_visible(False)
    save(fig,'Figure7F_gene_trajectories')

# ============================================================ G: RNA vs ATAC concordance
def panel_g():
    rna = pd.read_csv(RNA_DE)
    atac = pd.read_csv(os.path.join(BASE,'rloop_DE_by_celltype_M24h.csv'))
    # map ATAC cell types to RNA naming; average Ex/In neurons
    ct_map = {'Ex_Neurons':'Neurons','In_Neurons':'Neurons','Astrocytes':'Astrocytes',
              'Olig.':'Oligodendrocytes','Microglia':'Microglia','OPC':'OPCs',
              'Endothelial':'Endothelial','Fibroblast':None}
    atac['ct_rna'] = atac.cell_type.map(ct_map)
    atac = atac.dropna(subset=['ct_rna'])
    atac_agg = atac.groupby(['gene','ct_rna'])['log2FC'].mean().reset_index()
    m = rna.merge(atac_agg, left_on=['gene','cell_type'], right_on=['gene','ct_rna'])
    m = m.rename(columns={'log2FC_x':'rna','log2FC_y':'atac'})

    fig, ax = plt.subplots(figsize=(4.6,4.2))
    cts_show = ['Neurons','Astrocytes','Oligodendrocytes','Microglia','OPCs','Endothelial']
    markers = {'Neurons':'o','Astrocytes':'s','Oligodendrocytes':'D','Microglia':'^','OPCs':'v','Endothelial':'P'}
    for ct in cts_show:
        d = m[m.cell_type==ct]
        ax.scatter(d.rna, d.atac, s=22, alpha=0.75, label=ct, marker=markers[ct],
                   edgecolors='white', linewidths=0.4, zorder=3)
    ax.axhline(0, color='#999999', lw=0.8, ls='-', zorder=1)
    ax.axvline(0, color='#999999', lw=0.8, ls='-', zorder=1)
    # overall regression
    r,p = stats.pearsonr(m.rna, m.atac)
    rho, p_s = stats.spearmanr(m.rna, m.atac)
    # fit line
    coef = np.polyfit(m.rna, m.atac, 1)
    xx = np.linspace(m.rna.min(), m.rna.max(), 50)
    ax.plot(xx, np.polyval(coef, xx), color='#333333', lw=1.4, ls='--', zorder=2)
    ax.text(0.04, 0.96, f'Pearson r = {r:.3f}\nSpearman ρ = {rho:.3f}\nn = {len(m)} gene–cell pairs',
            transform=ax.transAxes, va='top', ha='left', fontsize=8,
            bbox=dict(boxstyle='round,pad=0.4', fc='white', ec='#cccccc', lw=0.6, alpha=0.92))
    ax.set_xlabel('scRNA-seq log2FC (MCAO vs Sham, GSE174574)')
    ax.set_ylabel('snATAC-seq log2FC (24 h vs Sham)')
    ax.legend(frameon=False, fontsize=7, loc='lower right', markerscale=0.9, ncol=2, columnspacing=0.6)
    ax.grid(alpha=0.2, linewidth=0.5)
    ax.spines[['top','right']].set_visible(False)
    save(fig,'Figure7G_rna_atac_concordance')
    # print per-celltype correlations for the record
    print('--- Panel G per-celltype ---')
    for ct in cts_show:
        d = m[m.cell_type==ct]
        rr,_ = stats.pearsonr(d.rna, d.atac)
        print(f'  {ct:18s} n={len(d)} r={rr:+.3f}')
    print(f'  OVERALL n={len(m)} Pearson r={r:.4f} Spearman rho={rho:.4f}')

if __name__ == '__main__':
    panel_a(); panel_b(); panel_c(); panel_d(); panel_e(); panel_f(); panel_g()
    print('All A-G done.')
