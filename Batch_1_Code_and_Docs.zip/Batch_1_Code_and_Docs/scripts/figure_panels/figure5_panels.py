# -*- coding: utf-8 -*-
"""
Figure 5 panels — Single-cell transcriptomics localizes R-loop-associated
transcriptional changes to specific cell populations (GSE174574 primary; GSE225948 validation).
Every panel is driven strictly by exported Seurat data / result CSVs. No mock data.
A  UMAP: cell-type annotation + MCAO/Sham split        <- umap_coords.csv
B  Cell-type composition (MCAO vs Sham, %)             <- composition.csv
C  R-loop AddModuleScore by cell type x group          <- module_score_addmodule.csv
D  R-loop gene x cell-type dotplot                     <- dotplot_source.csv
E  MCAO-vs-Sham log2FC heatmap (genes x cell types)    <- GSE174574_rloop_DE_by_celltype.csv
F  Microglia-focused changes (+ GSE225948 validation)  <- DE tables of both cohorts
G  Representative-gene UMAP feature plots              <- marker_expression.csv
"""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
import sys, os
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Patch

mpl.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'svg.fonttype': 'none', 'pdf.fonttype': 42, 'font.size': 7,
    'axes.spines.right': False, 'axes.spines.top': False,
    'axes.linewidth': 0.8, 'legend.frameon': False,
    'xtick.major.width': 0.8, 'ytick.major.width': 0.8,
    'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5,
})

RES = ROOT / 'data/main_tables'
SC = os.path.join(RES, r'04_scrna_gse174574')
SRC = os.path.join(SC, 'figure5_source')
SC2 = os.path.join(RES, r'10_scrna_gse225948')
OUT = ROOT / 'outputs/figures/Figure5'
os.makedirs(OUT, exist_ok=True)

C_UP, C_DOWN, C_MCAO, C_SHAM = '#e0524d', '#48639a', '#e0634f', '#4f9bb0'

# 11 cell types: coordinated, colour-blind aware; microglia emphasised
CT_ORDER = ['Endothelial','Microglia','Astrocytes','Pericytes','Neutrophils',
            'Oligodendrocytes','Macrophages','T_cells','OPCs','B_cells','Neurons']
CT_COLOR = {
    'Microglia':'#d64f4d', 'Macrophages':'#ef9a6a', 'Neutrophils':'#f2cf5b',
    'T_cells':'#5b8fc4', 'B_cells':'#93b8dd',
    'Astrocytes':'#4fae87', 'Oligodendrocytes':'#9b6bb3', 'OPCs':'#c9a6db',
    'Endothelial':'#3f7d9e', 'Pericytes':'#86b8b0', 'Neurons':'#d4a017'}
CT_DISP = {k: k.replace('_',' ') for k in CT_ORDER}

def save(fig, name):
    for ext in ('png','pdf','svg'):
        fig.savefig(os.path.join(OUT, f'{name}.{ext}'), dpi=600, bbox_inches='tight')
    plt.close(fig)
    print('saved', name)

# ============================================================ A: UMAP
# hand-tuned label anchors (small immune clusters overlap in UMAP space)
LABEL_POS = {
    'Endothelial':(-7.3,-0.4), 'Microglia':(6.1,10.0), 'Astrocytes':(0.5,-2.5),
    'Neutrophils':(7.8,-4.7), 'Macrophages':(8.8,1.9), 'T_cells':(2.7,2.7),
    'B_cells':(4.9,3.7), 'Neurons':(4.4,-6.5), 'Pericytes':(4.5,-8.5),
    'OPCs':(5.0,-12.4), 'Oligodendrocytes':(13.1,-7.6)}

def panel_a():
    from matplotlib import patheffects
    um = pd.read_csv(os.path.join(SRC,'umap_coords.csv'), index_col=0)
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 4.0))
    sizes = um.groupby('cell_type').size().sort_values(ascending=False)
    # ---- left: cell types (large populations first)
    ax = axes[0]
    for ct in sizes.index:
        d = um[um.cell_type==ct]
        ax.scatter(d.umap_1, d.umap_2, s=1.6, color=CT_COLOR[ct], alpha=0.55,
                   edgecolors='none', rasterized=True)
    for ct in CT_ORDER:
        d = um[um.cell_type==ct]
        cx, cy = d.umap_1.median(), d.umap_2.median()
        lx, ly = LABEL_POS[ct]
        if abs(lx-cx)>0.9 or abs(ly-cy)>0.9:   # leader line for displaced labels
            ax.plot([cx,lx],[cy,ly], color='#888', lw=0.4, zorder=3, alpha=0.7)
        ax.text(lx, ly, CT_DISP[ct], ha='center', va='center', fontsize=6.0,
                color='#222', fontweight='bold', zorder=5,
                path_effects=[patheffects.withStroke(linewidth=2.2, foreground='white')])
    ax.set_title('Cell types (n = 58,333)', fontsize=8, fontweight='bold', loc='left')
    ax.set_xlabel('UMAP 1'); ax.set_ylabel('UMAP 2')
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_aspect('equal')
    # ---- right: condition; draw the larger MCAO first so Sham stays visible on top
    ax = axes[1]
    for g, c in [('MCAO', C_MCAO), ('Sham', C_SHAM)]:
        d = um[um.group==g]
        ax.scatter(d.umap_1, d.umap_2, s=1.6, color=c, alpha=0.48,
                   edgecolors='none', rasterized=True, label=f'{g} (n={len(d):,})')
    ax.set_title('Condition', fontsize=8, fontweight='bold', loc='left')
    ax.set_xlabel('UMAP 1'); ax.set_ylabel('UMAP 2')
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_aspect('equal')
    ax.legend(markerscale=4, loc='upper right', fontsize=6.6, handletextpad=0.3)
    fig.tight_layout(w_pad=1.2)
    save(fig, 'Figure5A_umap')

# functional-module grouping of the 31 mouse genes (same scheme as Figure 4)
FUNC_OF = {}
for g in ['Rnaseh1','Rnaseh2a','Rnaseh2b','Rnaseh2c','Setx','Top1','Top1mt','Pif1']: FUNC_OF[g]=1
for g in ['Ddx1','Ddx3x','Ddx5','Ddx21','Dhx9','Aqr']: FUNC_OF[g]=2
for g in ['Atm','Atr','Brca1','Brca2','Parp1','Fancd2','Fancm']: FUNC_OF[g]=3
for g in ['Thoc1','Thoc2','Thoc3','Thoc5','Thoc6','Thoc7','Xrn2','Prmt5']: FUNC_OF[g]=4
FUNC_OF['Bcl7b']=5; FUNC_OF['Vdac1']=6
FUNC_COLORS = {1:'#c0504d',2:'#e0a030',3:'#7a8fb0',4:'#5a8a6a',5:'#8e7ab5',6:'#6fb3b8'}
GENE_ORDER = sorted(FUNC_OF, key=lambda g:(FUNC_OF[g], g))

# ============================================================ B: composition
def panel_b():
    co = pd.read_csv(os.path.join(SRC,'composition.csv'))
    pv = co.pivot(index='group', columns='cell_type', values='n').reindex(['Sham','MCAO'])
    pct = pv.div(pv.sum(1), axis=0)*100
    fig, ax = plt.subplots(figsize=(6.2,2.2))
    y = np.arange(2)
    left = np.zeros(2)
    for ct in CT_ORDER:
        v = pct[ct].values
        ax.barh(y, v, left=left, color=CT_COLOR[ct], height=0.62, ec='white', lw=0.8)
        for yi,(l,vv) in enumerate(zip(left,v)):
            if vv>=5:
                ax.text(l+vv/2, yi, f'{vv:.0f}', ha='center', va='center',
                        fontsize=5.8, color='white', fontweight='bold')
        left += v
    ax.set_yticks(y); ax.set_yticklabels([f'Sham\n(n={int(pv.loc["Sham"].sum()):,})',
                                          f'MCAO\n(n={int(pv.loc["MCAO"].sum()):,})'])
    ax.set_xlim(0,100); ax.set_xlabel('Cell composition (%)')
    ax.set_ylim(-0.6,1.2)
    handles=[Patch(fc=CT_COLOR[ct], label=CT_DISP[ct]) for ct in CT_ORDER]
    ax.legend(handles=handles, ncol=6, fontsize=5.6, loc='lower left',
              bbox_to_anchor=(0,1.02), columnspacing=1.0, handletextpad=0.3,
              borderaxespad=0)
    ax.tick_params(length=0)
    ax.spines['left'].set_visible(False)
    fig.tight_layout()
    save(fig,'Figure5B_composition')

# ============================================================ C: module score
def panel_c():
    ms = pd.read_csv(os.path.join(SRC,'module_score_addmodule.csv'), index_col=0)
    order = (ms.groupby('cell_type').ms.mean().sort_values(ascending=False)).index.tolist()
    fig, ax = plt.subplots(figsize=(6.6,3.4))
    pos = np.arange(len(order)); w=0.38
    for k,(g,c,off) in enumerate([('Sham',C_SHAM,-w/2),('MCAO',C_MCAO,w/2)]):
        data=[ms[(ms.cell_type==ct)&(ms.group==g)].ms.values for ct in order]
        bp=ax.boxplot(data, positions=pos+off, widths=w, patch_artist=True, showfliers=False,
                      medianprops=dict(color='#222',lw=0.9), whiskerprops=dict(lw=0.7),
                      boxprops=dict(facecolor=c,alpha=0.75,ec='#444',lw=0.7),
                      capprops=dict(lw=0.7))
    ax.axhline(0,color='#bbb',lw=0.7,ls='--',zorder=0)
    ax.set_xticks(pos); ax.set_xticklabels([CT_DISP[c] for c in order], rotation=35, ha='right', fontsize=6.2)
    ax.set_ylabel('R-loop module score (AddModuleScore)')
    # highlight microglia
    mi=order.index('Microglia')
    ax.axvspan(mi-0.5,mi+0.5,color=CT_COLOR['Microglia'],alpha=0.08,zorder=0)
    ax.text(mi, ax.get_ylim()[1]*0.96, 'highest', ha='center', va='top', fontsize=5.6,
            color=CT_COLOR['Microglia'], fontweight='bold')
    ax.legend([plt.Rectangle((0,0),1,1,fc=C_SHAM,alpha=0.75),
               plt.Rectangle((0,0),1,1,fc=C_MCAO,alpha=0.75)],['Sham','MCAO'],
              loc='upper right', fontsize=6.4)
    ax.tick_params(axis='x',length=0)
    fig.tight_layout()
    save(fig,'Figure5C_module_score')

# ============================================================ D: dotplot
def panel_d():
    dp = pd.read_csv(os.path.join(SRC,'dotplot_source.csv'))
    genes = GENE_ORDER
    cts = CT_ORDER
    M_avg = dp.pivot(index='gene', columns='cell_type', values='avg').reindex(index=genes, columns=cts)
    M_pct = dp.pivot(index='gene', columns='cell_type', values='pct').reindex(index=genes, columns=cts)
    fig, ax = plt.subplots(figsize=(6.8,7.6))
    vmax = 0.6   # ~95th percentile; ubiquitous Ddx5 saturates, which is correct
    cmap = LinearSegmentedColormap.from_list('exp',['#eef1f6','#a9c6e0','#4a7cb0','#20385f'])
    norm = Normalize(0, vmax)
    for i,g in enumerate(genes):
        for j,ct in enumerate(cts):
            a, p = M_avg.iloc[i,j], M_pct.iloc[i,j]
            if pd.isna(a): continue
            ax.scatter(j, i, s=10+ p*4.6, color=cmap(norm(np.clip(a,0,vmax))), ec='#c4ccd8', lw=0.4, zorder=3)
    ax.set_xticks(range(len(cts))); ax.set_xticklabels([CT_DISP[c] for c in cts], rotation=40, ha='right', fontsize=6.4)
    ax.set_yticks(range(len(genes))); ax.set_yticklabels(genes, fontsize=6.4, style='italic')
    ax.set_xlim(-0.6,len(cts)-0.4); ax.set_ylim(len(genes)-0.5,-0.8)
    ax.tick_params(length=0)
    for s in ['top','right']: ax.spines[s].set_visible(False)
    ax.grid(axis='x', color='#f0f1f4', lw=0.6, zorder=0)
    # functional-module side strip
    for i,g in enumerate(genes):
        ax.add_patch(plt.Rectangle((-1.35,i-0.5),0.5,1,color=FUNC_COLORS[FUNC_OF[g]],clip_on=False))
    ax.set_title('R-loop-associated gene expression across cell types', fontsize=8, fontweight='bold', loc='left', pad=6)
    # size legend (percent expressed) — top right
    lx0=len(cts)-3.4
    for k,pv in enumerate([10,30,60]):
        ax.scatter(lx0+k*1.15, -1.55, s=10+pv*4.6, facecolor='#d7dde7', ec='#9aa3b0', lw=0.5, clip_on=False)
        ax.text(lx0+k*1.15, -2.25, f'{pv}%', ha='center', va='top', fontsize=5.6, clip_on=False)
    ax.text(lx0-0.95, -1.55, '% expressed', ha='right', va='center', fontsize=5.8, clip_on=False)
    # color legend
    sm=ScalarMappable(norm,cmap); sm.set_array([])
    cb=fig.colorbar(sm, ax=ax, fraction=0.022, pad=0.03, aspect=18)
    cb.set_label('Avg. expression (log-normalized)', fontsize=6.2); cb.ax.tick_params(labelsize=5.8)
    fig.tight_layout()
    save(fig,'Figure5D_dotplot')

# ============================================================ E: DE heatmap
def panel_e():
    de = pd.read_csv(os.path.join(SC,'GSE174574_rloop_DE_by_celltype.csv'))
    genes=GENE_ORDER; cts=CT_ORDER
    F = de.pivot(index='gene',columns='cell_type',values='log2FC').reindex(index=genes,columns=cts)
    P = de.pivot(index='gene',columns='cell_type',values='p_adj').reindex(index=genes,columns=cts)
    vlim=0.3
    cmap=LinearSegmentedColormap.from_list('rb',['#2f5fa0','#f7f9fc','#d6453e'])
    fig,ax=plt.subplots(figsize=(6.6,7.4))
    for i in range(len(genes)):
        for j in range(len(cts)):
            v=np.clip(F.iloc[i,j],-vlim,vlim)
            ax.add_patch(plt.Rectangle((j-0.5,i-0.5),1,1,color=cmap((v+vlim)/(2*vlim))))
            if P.iloc[i,j]<0.05:
                ax.add_patch(plt.Rectangle((j-0.5,i-0.5),1,1,fill=False,ec='#333',lw=0.5))
    for i,g in enumerate(genes):
        ax.add_patch(plt.Rectangle((-1.35,i-0.5),0.5,1,color=FUNC_COLORS[FUNC_OF[g]],clip_on=False))
    ax.set_xticks(range(len(cts))); ax.set_xticklabels([CT_DISP[c] for c in cts],rotation=40,ha='right',fontsize=6.4)
    ax.set_yticks(range(len(genes))); ax.set_yticklabels(genes,fontsize=6.4,style='italic')
    ax.set_xlim(-0.5,len(cts)-0.5); ax.set_ylim(len(genes)-0.5,-0.8)
    ax.tick_params(length=0)
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_title('MCAO vs Sham log2 fold-change (boxed if padj<0.05)',fontsize=8,fontweight='bold',loc='left',pad=6)
    sm=ScalarMappable(Normalize(-vlim,vlim),cmap); sm.set_array([])
    cb=fig.colorbar(sm,ax=ax,fraction=0.03,pad=0.02,aspect=22,ticks=[-0.3,-0.15,0,0.15,0.3])
    cb.set_label('log2 fold-change (clipped at ±0.3)',fontsize=6.2); cb.ax.tick_params(labelsize=5.8)
    # module legend
    fn={1:'R-loop/hybrid resolution',2:'RNA helicases & RNP',3:'DNA-damage response',
        4:'RNA processing/export',5:'Chromatin',6:'Mitochondrial'}
    handles=[Patch(fc=FUNC_COLORS[k],label=fn[k]) for k in [1,2,3,4,5,6]]
    ax.legend(handles=handles,loc='lower left',bbox_to_anchor=(-0.16,-0.13),ncol=2,fontsize=5.5,
              columnspacing=0.9,handletextpad=0.3)
    fig.tight_layout()
    save(fig,'Figure5E_DE_heatmap')

# ============================================================ F: microglia focus
def panel_f():
    de = pd.read_csv(os.path.join(SC,'GSE174574_rloop_DE_by_celltype.csv'))
    mg = de[de.cell_type=='Microglia'].sort_values('log2FC').reset_index(drop=True)
    tc = pd.read_csv(os.path.join(SC2,'GSE225948_rloop_DE_by_celltype.csv'))
    mg2 = tc[tc.celltype=='Mg'].copy()
    fig=plt.figure(figsize=(8.6,4.6))
    gs=fig.add_gridspec(1,2,width_ratios=[1.05,1],wspace=0.34)
    # left: GSE174574 microglia log2FC bars
    ax=fig.add_subplot(gs[0,0]); y=np.arange(len(mg))
    cols=[('#d9d9d9' if r.p_adj>=0.05 else (C_UP if r.log2FC>0 else C_DOWN)) for _,r in mg.iterrows()]
    ax.barh(y,mg.log2FC,color=cols,height=0.72)
    ax.axvline(0,color='#888',lw=0.8)
    ax.set_yticks(y); ax.set_yticklabels(mg.gene,fontsize=5.8,style='italic')
    ax.set_xlabel('log2 fold-change (MCAO vs Sham)')
    ax.set_title('Microglia, GSE174574 (26/31 significant)',fontsize=7.4,fontweight='bold',loc='left')
    ax.tick_params(axis='y',length=0)
    ax.spines['left'].set_visible(False)
    # right: GSE225948 Mg temporal dynamics
    ax=fig.add_subplot(gs[0,1])
    d=mg2.dropna(subset=['logFC_D2','logFC_D14'])
    d=d[d.gene!='Ddx19']
    for _,r in d.iterrows():
        c=FUNC_COLORS.get(FUNC_OF.get(r.gene,0),'#999999')
        ax.scatter(r.logFC_D2,r.logFC_D14,s=26,color=c,ec='white',lw=0.5,zorder=3,alpha=0.9)
    ax.axhline(0,color='#bbb',lw=0.8,ls='--'); ax.axvline(0,color='#bbb',lw=0.8,ls='--')
    # sparse, manually offset labels to avoid overlap
    annoff={'Ddx5':(-4,6,'left'),'Ddx21':(4,-2,'left'),'Rnaseh1':(4,6,'left'),
            'Ddx1':(0,8,'center'),'Vdac1':(0,-9,'center')}
    for _,r in d.iterrows():
        if r.gene in annoff:
            dx,dy,ha=annoff[r.gene]
            ax.annotate(r.gene,(r.logFC_D2,r.logFC_D14),xytext=(dx,dy),textcoords='offset points',
                        ha=ha,fontsize=5.6,style='italic',color='#333')
    lim=max(abs(d.logFC_D2).max(),abs(d.logFC_D14).max())*1.12
    ax.set_xlim(-lim,lim); ax.set_ylim(-lim,lim)
    ax.set_xlabel('logFC, Stroke D2 vs Sham D2')
    ax.set_ylabel('logFC, Stroke D14 vs Stroke D2')
    ax.set_title('Microglia temporal dynamics, GSE225948',fontsize=7.4,fontweight='bold',loc='left')
    ax.text(0.03,0.97,'acute induction at D2,\nresolution by D14',transform=ax.transAxes,
            fontsize=5.8,color='#666',va='top',ha='left')
    fig.tight_layout()
    save(fig,'Figure5F_microglia_focus')

# ============================================================ G: feature plots
def panel_g():
    mk=pd.read_csv(os.path.join(SRC,'marker_expression.csv'),index_col=0)
    genes=['Ddx21','Ddx5','Rnaseh1','Bcl7b']
    cmap=LinearSegmentedColormap.from_list('fp',['#e9edf2','#9db4d0','#3f6fa5','#1d2f52'])
    fig,axes=plt.subplots(2,2,figsize=(7.2,6.4))
    for ax,g in zip(axes.ravel(),genes):
        # background all cells light gray, then colored by expression
        ax.scatter(mk.umap_1,mk.umap_2,s=1.7,color='#dde3ec',edgecolors='none',rasterized=True)
        order=np.argsort(mk[g].values)
        v=mk[g].values[order]; xy=mk[['umap_1','umap_2']].values[order]
        vmax=np.quantile(v,0.98)
        ax.scatter(xy[:,0],xy[:,1],s=1.8,c=np.clip(v,0,vmax),cmap=cmap,vmin=0,vmax=vmax,
                   edgecolors='none',rasterized=True)
        ax.set_title(g,fontsize=8,fontweight='bold',style='italic',loc='left')
        ax.set_xticks([]); ax.set_yticks([])
        for s in ax.spines.values(): s.set_visible(False)
        ax.set_aspect('equal')
        sm=ScalarMappable(Normalize(0,vmax),cmap); sm.set_array([])
        cb=fig.colorbar(sm,ax=ax,fraction=0.046,pad=0.02,aspect=18)
        cb.set_label('Expression',fontsize=5.8); cb.ax.tick_params(labelsize=5.4,length=2)
    fig.tight_layout(h_pad=0.4,w_pad=0.6)
    save(fig,'Figure5G_featureplots')

if __name__ == '__main__':
    panel_a(); panel_b(); panel_c(); panel_d(); panel_e(); panel_f(); panel_g()
    print('ALL FIGURE 5 PANELS DONE ->', OUT)
