# -*- coding: utf-8 -*-
"""
Figure 7 (HiChIP) panels — microglia H3K27ac HiChIP, Sham vs MCAO Day6 (GSE319240)
All numbers derived from real FitHiChIP interaction BEDs + authoritative mm10 TSS.
Outputs independent panels (png 600dpi + pdf + svg); user assembles manually.
"""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
import os, numpy as np, pandas as pd
import matplotlib as mpl
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Arc, Polygon
from scipy.stats import pearsonr, spearmanr

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
    "svg.fonttype": "none", "pdf.fonttype": 42, "font.size": 7,
    "axes.spines.right": False, "axes.spines.top": False,
    "axes.linewidth": 0.8, "legend.frameon": False, "xtick.major.width": 0.8, "ytick.major.width": 0.8,
})

BASE = str(ROOT / 'data')
EX = str(ROOT / 'data/figure_source/hichip')
RES = str(ROOT / 'data/main_tables')
HIC = str(ROOT / 'data/main_tables/09_hichip_contacts')
OUT = str(ROOT / 'outputs/figures/Figure8')
os.makedirs(OUT, exist_ok=True)

C_SHAM = '#3C5488'   # deep blue
C_DAY6 = '#E64B35'   # red
C_UP   = '#E64B35'
C_DOWN = '#3C5488'
C_STAB = '#D6D6D6'
C_HL   = '#E6A519'   # gold highlight for R-loop loci
C_ACC  = '#00A087'

# ─────────────── Load data ───────────────
sham = pd.read_csv(EX + '/GSM9514203_HiCHIP_Sham_H3K27ac_interactions.bed', sep='\t')
day6 = pd.read_csv(EX + '/GSM9514204_HiCHIP_Day6_H3K27ac_interactions.bed', sep='\t')
diff = pd.read_csv(HIC + '/differential_loops.csv')
coords = pd.read_csv(HIC + '/mm10_rloop_gene_coords.csv')
genetab = pd.read_csv(HIC + '/hichip_rloop_gene_loop_annotation.csv')

for d in (sham, day6):
    d['intra'] = d['chr1'] == d['chr2']
    d['length_kb'] = np.where(d['intra'], np.abs(d['s2'] - d['s1']) / 1000, np.nan)

WIN = 50000

def lid_of(r):
    c1, s1, e1, c2, s2, e2 = r['chr1'], r['s1'], r['e1'], r['chr2'], r['s2'], r['e2']
    if c1 == c2 and s1 > s2: s1, e1, s2, e2 = s2, e2, s1, e1
    return f"{c1}:{s1}-{e1}|{s2}-{e2}"
sham['lid'] = sham.apply(lid_of, axis=1)
day6['lid'] = day6.apply(lid_of, axis=1)

def nearby(df, g, win=WIN):
    lo, hi = g['tss'] - win, g['tss'] + win
    same = df[df['chr1'] == g['chr']]
    return same[((same['s1'] <= hi) & (same['e1'] >= lo)) | ((same['s2'] <= hi) & (same['e2'] >= lo))]

def save(fig, name):
    for ext in ('png', 'pdf', 'svg'):
        fig.savefig(f'{OUT}/{name}.{ext}', dpi=600 if ext == 'png' else None,
                    bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print('saved', name)

# ═══════════════════════ Panel A: workflow + global counts ═══════════════════════
def panel_a():
    fig, ax = plt.subplots(figsize=(7.4, 2.5))
    ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis('off')
    steps = [
        "GSE319240 microglia\nH3K27ac HiChIP\nSham | MCAO Day 6",
        "HiC-Pro 3.1.0\nalignment\n(mm10)",
        "Peak reference\nmerged microglia ATAC\nexpanded to 1 kb",
        "FitHiChIP(S)\n10-kb bins\n10 kb–1 Mb",
        "Significant\npeak-to-peak loops",
    ]
    n = len(steps); w = 16.5; gap = (100 - n * w) / (n + 1); h = 38; y = 47
    xs = []
    for i, t in enumerate(steps):
        x = gap + i * (w + gap); xs.append(x)
        box = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.6,rounding_size=2.2",
                             linewidth=0.9, edgecolor='#4A4A4A', facecolor='#F2F4F7')
        ax.add_patch(box)
        ax.text(x + w / 2, y + h / 2, t, ha='center', va='center', fontsize=6.4, color='#222222')
        if i < n - 1:
            ax.add_patch(FancyArrowPatch((x + w + 0.4, y + h / 2), (x + w + gap - 0.4, y + h / 2),
                                         arrowstyle='-|>', mutation_scale=9, linewidth=1.1, color='#4A4A4A'))
    # count cards
    cardw = 22; ch = 22; cy = 12
    for x, col, t1, t2 in [
        (14, C_SHAM, 'Sham', '19,061 loops'),
        (39, C_DAY6, 'Day 6', '42,905 loops'),
        (64, '#333333', 'Expansion', '×2.25')]:
        box = FancyBboxPatch((x, cy), cardw, ch, boxstyle="round,pad=0.4,rounding_size=2",
                             linewidth=0, facecolor=col, alpha=0.92)
        ax.add_patch(box)
        ax.text(x + cardw / 2, cy + ch * 0.66, t1, ha='center', va='center', fontsize=7, color='white', fontweight='bold')
        ax.text(x + cardw / 2, cy + ch * 0.28, t2, ha='center', va='center', fontsize=7.5, color='white')
    ax.text(50, 96, "Microglial H3K27ac HiChIP processing and global loop repertoire",
            ha='center', va='top', fontsize=8, fontweight='bold')
    save(fig, 'Figure8A_hichip_workflow')

# ═══════════════════════ Panel B: length & contact distributions ═══════════════════════
def panel_b():
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 2.9))
    ax = axes[0]
    sl = sham.loc[sham['intra'], 'length_kb']
    dl = day6.loc[day6['intra'], 'length_kb']
    bins = np.linspace(0, 1000, 41)
    ax.hist(sl, bins=bins, density=True, histtype='stepfilled', alpha=0.45, color=C_SHAM, label='Sham')
    ax.hist(dl, bins=bins, density=True, histtype='stepfilled', alpha=0.45, color=C_DAY6, label='Day 6')
    ax.set_xlim(0, 1000)
    for v, c, t in [(sl.mean(), C_SHAM, '228 kb'), (dl.mean(), C_DAY6, '343 kb')]:
        ax.axvline(v, color=c, ls='--', lw=1.1)
        ax.text(v + 6, ax.get_ylim()[1] * 0.96, t, rotation=90, va='top', ha='left', fontsize=6, color=c)
    ax.set_xlabel('Loop length (kb)'); ax.set_ylabel('Density'); ax.legend(fontsize=6.5, loc='upper right')
    ax.set_title('Intra-chromosomal loop length', fontsize=7.5, fontweight='bold')

    ax = axes[1]
    bins = np.logspace(0, np.log10(300), 40)
    ax.hist(sham['cc'].clip(upper=300), bins=bins, density=True, histtype='stepfilled', alpha=0.45, color=C_SHAM, label='Sham')
    ax.hist(day6['cc'].clip(upper=300), bins=bins, density=True, histtype='stepfilled', alpha=0.45, color=C_DAY6, label='Day 6')
    ax.set_xscale('log'); ax.set_xlabel('Contact count (cc, log scale)'); ax.set_ylabel('Density')
    ax.legend(fontsize=6.5, loc='upper right')
    ax.set_title('Per-loop contact count', fontsize=7.5, fontweight='bold')
    fig.tight_layout()
    save(fig, 'Figure8B_loop_distributions')

# ═══════════════════════ Panel C: 32-gene loop overlap dumbbell ═══════════════════════
def panel_c():
    g = genetab.sort_values(['n_day6', 'n_sham']).reset_index(drop=True)
    fig, ax = plt.subplots(figsize=(3.7, 7.4))
    y = np.arange(len(g))
    for i, r in g.iterrows():
        ax.plot([r['n_sham'], r['n_day6']], [i, i], color='#9AA5B1', lw=0.9, zorder=1)
    ax.scatter(g['n_sham'], y, s=14, color=C_SHAM, zorder=3, label='Sham')
    ax.scatter(g['n_day6'], y, s=14, color=C_DAY6, zorder=3, label='Day 6')
    ax.set_yticks(y); ax.set_yticklabels(g['gene'], fontstyle='italic', fontsize=6.3)
    ax.set_xlabel('Loops within TSS ± 50 kb (n)')
    ax.set_ylim(-0.7, len(g) - 0.3)
    ax.invert_yaxis()
    ax.legend(fontsize=6.8, loc='upper right', borderaxespad=0.3)
    ax.set_title('R-loop gene–loop overlap\n(26/32 genes at Sham → 30/32 at Day 6)', fontsize=7.2, fontweight='bold')
    ax.grid(axis='x', lw=0.4, color='#E8E8E8')
    save(fig, 'Figure8C_gene_loop_overlap')

# ═══════════════════════ Panel D: locus arc diagrams ═══════════════════════
def draw_arcs(ax, df, direction, color):
    ccmax = max(df['cc'].max(), 1)
    for _, r in df.iterrows():
        a = (r['s1'] + r['e1']) / 2; b = (r['s2'] + r['e2']) / 2
        if b <= a: a, b = b, a
        width = b - a
        if width <= 0: continue
        lw = 0.4 + 2.0 * min(r['cc'] / 60, 1)
        HF = 0.38  # arc height factor
        if direction == 'up':
            arc = Arc(((a + b) / 2, 0), width=width, height=width * HF, theta1=0, theta2=180,
                      lw=lw, edgecolor=color, alpha=0.55)
        else:
            arc = Arc(((a + b) / 2, 0), width=width, height=width * HF, theta1=180, theta2=360,
                      lw=lw, edgecolor=color, alpha=0.55)
        ax.add_patch(arc)

def panel_d():
    targets = ['Rnaseh1', 'Bcl7b', 'Vdac1', 'Ddx21']
    fig, axes = plt.subplots(2, 2, figsize=(7.4, 5.6))
    for ax, tgt in zip(axes.flat, targets):
        grow = coords[coords['gene'] == tgt].iloc[0]
        ns, nd = nearby(sham, grow), nearby(day6, grow)
        allx = pd.concat([ns[['s1', 'e2']].rename(columns={'e2': 'e'}),
                          nd[['s1', 'e2']].rename(columns={'e2': 'e'})])
        if len(allx):
            lo, hi = allx['s1'].min(), allx['e'].max(); pad = (hi - lo) * 0.06
        else:
            lo, hi = grow['tss'] - 200000, grow['tss'] + 200000; pad = 0
        lo -= pad; hi += pad
        draw_arcs(ax, ns, 'up', C_SHAM)
        draw_arcs(ax, nd, 'down', C_DAY6)
        yt = (hi - lo) * 0.24
        # TSS guide line
        ax.plot([grow['tss'], grow['tss']], [-yt, yt], color='#C8C8C8', lw=0.7, ls=':', zorder=1)
        # gene baseline + TSS triangle
        ax.axhline(0, color='#333333', lw=1.2, zorder=5)
        ax.text(grow['tss'], 0, '▲', ha='center', va='center', fontsize=6.5, color='black', zorder=7)
        # gene label above TSS
        ax.text(grow['tss'], yt * 0.96, tgt, fontstyle='italic', fontsize=7.5, ha='center', va='top',
                zorder=8, bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='none', alpha=0.85))
        ax.set_xlim(lo, hi); ax.set_ylim(-yt, yt)
        ax.set_yticks([])
        ax.set_xticks([lo, hi])
        ax.set_xticklabels([f'{lo/1e6:.2f}', f'{hi/1e6:.2f}'], fontsize=6)
        ax.set_xlabel(f"{grow['chr']} (Mb)", fontsize=6.3)
        for s in ['left', 'right', 'top']:
            ax.spines[s].set_visible(False)
        ax.set_title(f"{len(ns)} → {len(nd)} loops", fontsize=7, fontweight='bold', loc='right')
    # shared legend
    from matplotlib.lines import Line2D
    leg = [Line2D([0], [0], color=C_SHAM, lw=2, label='Sham (arcs up)'),
           Line2D([0], [0], color=C_DAY6, lw=2, label='Day 6 (arcs down)')]
    fig.legend(handles=leg, loc='upper center', ncol=2, fontsize=7, bbox_to_anchor=(0.5, 1.01))
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    save(fig, 'Figure8D_locus_arcs')

# ═══════════════════════ Panel E: common-loop MA plot ═══════════════════════
def panel_e():
    d = diff.copy()
    d['mean_cc'] = (d['Sham_cc'] + d['Day6_cc']) / 2
    # set of common loops near any R-loop gene
    rloop_common = set()
    for _, grow in coords.iterrows():
        if pd.isna(grow['tss']): continue
        lo, hi = grow['tss'] - WIN, grow['tss'] + WIN
        gchr = grow['chr']
        for lid in d['loop_id']:
            c, rest = lid.split(':'); c2 = rest.split('|')
            a = c2[0].split('-'); b = c2[1].split('-')
            if c == gchr and ((float(a[0]) <= hi and float(a[1]) >= lo) or (float(b[0]) <= hi and float(b[1]) >= lo)):
                rloop_common.add(lid)
    d['near_rloop'] = d['loop_id'].isin(rloop_common)
    print('Panel E: common loops near R-loop genes =', d['near_rloop'].sum())

    fig, ax = plt.subplots(figsize=(3.7, 3.3))
    stab = d[(~d['Day6_up']) & (~d['Day6_down'])]
    ax.scatter(np.log10(stab['mean_cc']), stab['log2FC'], s=3, color=C_STAB, alpha=0.7, label=f'Stable (n={len(stab)})', zorder=2)
    up = d[d['Day6_up']]; dn = d[d['Day6_down']]
    ax.scatter(np.log10(up['mean_cc']), up['log2FC'], s=5, color=C_UP, label=f'Strengthened (n={len(up)})', zorder=3)
    ax.scatter(np.log10(dn['mean_cc']), dn['log2FC'], s=5, color=C_DOWN, label=f'Weakened (n={len(dn)})', zorder=3)
    nr = d[d['near_rloop']]
    ax.scatter(np.log10(nr['mean_cc']), nr['log2FC'], s=26, facecolors='none', edgecolors=C_HL, lw=1.1, zorder=4, label='Near R-loop genes')
    ax.axhline(1, color=C_UP, ls='--', lw=0.8); ax.axhline(-1, color=C_DOWN, ls='--', lw=0.8); ax.axhline(0, color='#888', lw=0.6)
    # label the 3 differential R-loop loops
    for _, r in nr[nr['Day6_up'] | nr['Day6_down']].iterrows():
        gene = ''
        for _, grow in coords.iterrows():
            if pd.isna(grow['tss']): continue
            lo, hi = grow['tss'] - WIN, grow['tss'] + WIN
            c, rest = r['loop_id'].split(':'); c2 = rest.split('|'); a = c2[0].split('-'); b = c2[1].split('-')
            if c == grow['chr'] and ((float(a[0]) <= hi and float(a[1]) >= lo) or (float(b[0]) <= hi and float(b[1]) >= lo)):
                gene = grow['gene']; break
        ax.annotate(gene, (np.log10(r['mean_cc']), r['log2FC']), fontsize=6, fontstyle='italic',
                    xytext=(3, 3), textcoords='offset points')
    ax.set_xlabel('Mean contact count (log10)'); ax.set_ylabel('Day 6 / Sham log2 ratio')
    ax.set_title('Shared-loop remodeling (4,698 common loops)', fontsize=7.3, fontweight='bold')
    ax.legend(fontsize=5.8, loc='lower right')
    save(fig, 'Figure8E_common_loop_MA')

# ═══════════════════════ Panel F: three-omics concordance bubble ═══════════════════════
def panel_f():
    bulk = pd.read_csv(RES + '/01_bulk_transcriptomics/GSE163614_rloop_genes.csv')
    bulk = bulk.rename(columns={'gene': 'gene', 'log2FoldChange': 'rna_lfc'})[['gene', 'rna_lfc']]
    atac = pd.read_csv(RES + '/05_snatac_accessibility/rloop_differential_accessibility.csv')
    atac = atac[atac['timepoint'] == 'M7d'].rename(columns={'log2FC': 'atac_lfc'})[['gene', 'atac_lfc']]
    m = genetab.rename(columns={'gene': 'gene'})[['gene', 'n_sham', 'n_day6']].copy()
    m['gain'] = m['n_day6'] - m['n_sham']
    m = m.merge(bulk, on='gene', how='left').merge(atac, on='gene', how='left')
    plot = m.dropna(subset=['rna_lfc', 'atac_lfc'])
    r_p, p_p = pearsonr(plot['rna_lfc'], plot['atac_lfc'])
    r_s, p_s = spearmanr(plot['rna_lfc'], plot['atac_lfc'])
    print(f'Panel F genes plotted={len(plot)}, RNA-ATAC Pearson r={r_p:.3f} p={p_p:.3g}, Spearman={r_s:.3f}')

    fig, ax = plt.subplots(figsize=(3.9, 3.4))
    sizes = 8 + (plot['gain'].clip(lower=0)) * 2.2
    sc = ax.scatter(plot['rna_lfc'], plot['atac_lfc'], s=sizes, c=plot['gain'], cmap='RdYlBu_r',
                    edgecolors='#333', linewidths=0.5, alpha=0.9, zorder=3, vmin=-10, vmax=45)
    ax.axhline(0, color='#999', lw=0.7); ax.axvline(0, color='#999', lw=0.7)
    ax.set_xlim(-0.42, 1.68); ax.set_ylim(-0.105, 0.135)
    label_genes = ['Ddx21', 'Pif1', 'Rnaseh2c', 'Parp1', 'Brca1', 'Rnaseh2a', 'Ddx5', 'Bcl7b', 'Vdac1']
    for t in label_genes:
        rr = plot[plot['gene'] == t]
        if len(rr):
            rr = rr.iloc[0]
            ax.annotate(t, (rr['rna_lfc'], rr['atac_lfc']), fontsize=5.8, fontstyle='italic',
                        xytext=(2.5, 2.5), textcoords='offset points')
    cb = fig.colorbar(sc, ax=ax, fraction=0.046, pad=0.03)
    cb.set_label('HiChIP loop gain (Day 6 − Sham)', fontsize=6.3); cb.ax.tick_params(labelsize=6)
    ax.set_xlabel('Bulk RNA log2FC (GSE163614, MCAO vs Sham)')
    ax.set_ylabel('snATAC accessibility log2FC (Day 7)')
    ax.set_title(f'Transcription–accessibility–HiChIP concordance\nPearson r = {r_p:.2f}', fontsize=7.2, fontweight='bold')
    save(fig, 'Figure8F_three_omics_concordance')
    m.to_csv(OUT + '/hichip_three_omics_concordance.csv', index=False)

panel_a(); panel_b(); panel_c(); panel_d(); panel_e(); panel_f()
print('ALL FIGURE 8 PANELS DONE ->', OUT)
