# Rights and third-party data

The authors' code and processed results are provided for inspection of the
accompanying research. Generated final figures are not duplicated in this
package. No software or data licence has been selected by the authors for this
release. Availability alone does not grant a separate reuse licence.

Reused GEO, Figshare, STRING and annotation resources remain governed by their
original records, terms and attribution requirements. This repository does not
relicense third-party resources. Public processed HiChIP interaction BED files from GSE319240 are identified by source accession and checksum and downloaded on demand; they are not redistributed in this package.
