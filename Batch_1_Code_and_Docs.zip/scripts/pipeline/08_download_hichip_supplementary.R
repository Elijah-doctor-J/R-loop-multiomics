# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 08_download_hichip_supplementary.R
# 下载GSE319240 HiChIP的supplementary files (peaks和loops)
# ============================================================


suppressPackageStartupMessages({
  library(GEOquery)
  library(Biobase)
  library(tidyverse)
})

# ============================================================
# 检查GSE319240的supplementary files
# ============================================================
cat("========================================\n")
cat("  检查GSE319240 supplementary files\n")
cat("========================================\n")

eset319 <- readRDS("05_hichip/processed/GSE319240_eset.rds")
pdata319 <- pData(eset319)

supp_cols <- grep("supplementary", colnames(pdata319), value = TRUE)
cat("Supplementary列:", paste(supp_cols, collapse=", "), "\n")

for (col in supp_cols) {
  cat("\n", col, ":\n", sep="")
  for (i in 1:nrow(pdata319)) {
    val <- pdata319[i, col]
    if (!is.na(val) && val != "") {
      cat(sprintf("  %s: %s\n", pdata319$geo_accession[i], val))
    }
  }
}

# ============================================================
# 下载GSE319240的supplementary files
# ============================================================
cat("\n\n========================================\n")
cat("  下载GSE319240 supplementary files\n")
cat("========================================\n")

dir.create("05_hichip/supplementary/GSE319240", showWarnings = FALSE, recursive = TRUE)

tryCatch({
  supp_files <- getGEOSuppFiles("GSE319240", baseDir = "05_hichip/supplementary", fetch_files = TRUE)
  cat("下载的文件:\n")
  print(rownames(supp_files))
  cat("文件大小:\n")
  for (f in rownames(supp_files)) {
    cat(sprintf("  %s: %.1f MB\n", basename(f), file.info(f)$size / 1024 / 1024))
  }
}, error = function(e) {
  cat("下载失败:", conditionMessage(e), "\n")
})

cat("\n完成！\n")
