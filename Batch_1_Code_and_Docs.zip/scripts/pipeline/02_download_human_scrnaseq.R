# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 02_download_human_validation_scrnaseq.R
# 下载第二批：人源验证集 + 单细胞RNA-seq
# 人源：GSE22255, GSE16561
# 单细胞：GSE174574, GSE225948
# ============================================================


suppressPackageStartupMessages({
  library(GEOquery)
  library(Biobase)
  library(tidyverse)
})

# 创建子目录
dir.create("02_human_validation", showWarnings = FALSE, recursive = TRUE)
dir.create("02_human_validation/raw", showWarnings = FALSE, recursive = TRUE)
dir.create("02_human_validation/processed", showWarnings = FALSE, recursive = TRUE)
dir.create("02_human_validation/qc", showWarnings = FALSE, recursive = TRUE)

dir.create("03_scrnaseq", showWarnings = FALSE, recursive = TRUE)
dir.create("03_scrnaseq/raw", showWarnings = FALSE, recursive = TRUE)
dir.create("03_scrnaseq/processed", showWarnings = FALSE, recursive = TRUE)
dir.create("03_scrnaseq/qc", showWarnings = FALSE, recursive = TRUE)

# ============================================================
# 人源验证集元信息
# ============================================================
human_datasets <- list(
  GSE22255 = list(
    name = "GSE22255",
    species = "Homo sapiens",
    model = "缺血性卒中(血液)",
    platform = "GPL570 [HG-U133_Plus_2] Affymetrix Human Genome U133 Plus 2.0 Array",
    description = "人缺血性卒中外周血，20 IS + 20对照",
    note = "人源验证集1"
  ),
  GSE16561 = list(
    name = "GSE16561",
    species = "Homo sapiens",
    model = "缺血性卒中(血液)",
    platform = "GPL6883 Illumina humanRef-8 v3.0 expression beadchip",
    description = "人缺血性卒中外周血，39 IS + 24对照",
    note = "人源验证集2"
  )
)

# ============================================================
# 单细胞数据集元信息
# ============================================================
sc_datasets <- list(
  GSE174574 = list(
    name = "GSE174574",
    species = "Mus musculus",
    model = "MCAO(急性期)",
    platform = "GPL21103 10X Genomics Chromium",
    description = "小鼠MCAO后急性期脑组织单细胞，3缺血+3对照",
    note = "主单细胞分析集"
  ),
  GSE225948 = list(
    name = "GSE225948",
    species = "Mus musculus",
    model = "tMCAO后2天和14天",
    platform = "GPL9057 10X Genomics Chromium",
    description = "小鼠tMCAO后2d/14d免疫细胞+内皮细胞单细胞，4对MCAO/sham",
    note = "急慢性对比验证集"
  )
)

# ============================================================
# 通用下载函数
# ============================================================
download_gse_generic <- function(gse_id, dest_dir, info_list) {
  cat("\n", strrep("=", 60), "\n", sep = "")
  cat("下载数据集:", gse_id, "\n")
  cat(strrep("=", 60), "\n", sep = "")
  
  info <- info_list[[gse_id]]
  cat("物种:", info$species, "\n")
  cat("模型:", info$model, "\n")
  cat("平台:", info$platform, "\n")
  cat("描述:", info$description, "\n")
  cat("备注:", info$note, "\n\n")
  
  tryCatch({
    gse <- getGEO(
      GEO = gse_id,
      destdir = file.path(dest_dir, "raw"),
      GSEMatrix = TRUE,
      AnnotGPL = TRUE
    )
    
    if (is.list(gse)) {
      gse <- gse[[1]]
    }
    
    cat("下载成功！\n")
    cat("样本数:", ncol(gse), "\n")
    cat("探针/基因数:", nrow(gse), "\n")
    cat("平台:", annotation(gse), "\n")
    
    saveRDS(gse, file = file.path(dest_dir, "processed", paste0(gse_id, "_eset.rds")))
    
    expr_mat <- exprs(gse)
    pdata <- pData(gse)
    
    write.csv(expr_mat, file = file.path(dest_dir, "processed", paste0(gse_id, "_expression_matrix.csv")),
              row.names = TRUE)
    write.csv(pdata, file = file.path(dest_dir, "processed", paste0(gse_id, "_phenotype_data.csv")),
              row.names = TRUE)
    
    cat("\n样本标题列表:\n")
    for (i in 1:min(ncol(gse), 30)) {
      cat(sprintf("  %2d. %s\n", i, pdata$title[i]))
    }
    if (ncol(gse) > 30) {
      cat(sprintf("  ... 共 %d 个样本\n", ncol(gse)))
    }
    
    return(list(success = TRUE, n_samples = ncol(gse), n_features = nrow(gse)))
    
  }, error = function(e) {
    cat("下载失败:", conditionMessage(e), "\n")
    return(list(success = FALSE, error = conditionMessage(e)))
  })
}

# ============================================================
# 下载人源验证集
# ============================================================
cat("========================================\n")
cat("  人源验证集下载\n")
cat("========================================\n")

human_results <- list()
for (gse_id in names(human_datasets)) {
  human_results[[gse_id]] <- download_gse_generic(gse_id, "02_human_validation", human_datasets)
  Sys.sleep(2)
}

# ============================================================
# 下载单细胞数据
# 注意：单细胞数据可能较大，优先下载series matrix
# 如果series matrix不可用，会提示需要手动下载supplementary files
# ============================================================
cat("\n\n========================================\n")
cat("  单细胞RNA-seq数据下载\n")
cat("========================================\n")
cat("注意：单细胞数据量较大，下载可能需要较长时间\n")
cat("优先下载GEO处理好的series matrix\n\n")

sc_results <- list()
for (gse_id in names(sc_datasets)) {
  sc_results[[gse_id]] <- download_gse_generic(gse_id, "03_scrnaseq", sc_datasets)
  Sys.sleep(3)
}

# ============================================================
# 汇总报告
# ============================================================
cat("\n\n", strrep("=", 60), "\n", sep = "")
cat("第二批下载汇总报告\n")
cat(strrep("=", 60), "\n", sep = "")

all_results <- c(human_results, sc_results)
all_info <- c(human_datasets, sc_datasets)

report <- data.frame(
  Dataset = character(),
  Category = character(),
  Species = character(),
  Model = character(),
  Samples = integer(),
  Features = integer(),
  Status = character(),
  stringsAsFactors = FALSE
)

for (gse_id in names(all_results)) {
  res <- all_results[[gse_id]]
  info <- all_info[[gse_id]]
  category <- ifelse(gse_id %in% names(human_datasets), "人源验证", "单细胞")
  if (res$success) {
    report <- rbind(report, data.frame(
      Dataset = gse_id, Category = category,
      Species = info$species, Model = info$model,
      Samples = res$n_samples, Features = res$n_features,
      Status = "OK", stringsAsFactors = FALSE
    ))
  } else {
    report <- rbind(report, data.frame(
      Dataset = gse_id, Category = category,
      Species = info$species, Model = info$model,
      Samples = NA, Features = NA,
      Status = paste("FAIL:", res$error), stringsAsFactors = FALSE
    ))
  }
}

print(report, row.names = FALSE)
write.csv(report, file = "03_scrnaseq/qc/02_download_report.csv", row.names = FALSE)
cat("\n报告已保存\n")
cat("\n第二批下载完成！\n")
