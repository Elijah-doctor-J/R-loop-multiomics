# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 13_functional_enrichment.R
# 功能富集分析: GO / KEGG / GSEA
# 基于Bulk RNA-seq差异分析结果
# ============================================================


suppressPackageStartupMessages({
  library(clusterProfiler)
  library(org.Rn.eg.db)
  library(org.Mm.eg.db)
  library(org.Hs.eg.db)
  library(tidyverse)
  library(enrichplot)
  library(ggplot2)
})

dir.create(file.path(RESULTS, "03_enrichment"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(RESULTS, "03_enrichment/figures"), recursive = TRUE, showWarnings = FALSE)

# ============================================================
# 1. GSE163614 (大鼠) GO/KEGG富集
# ============================================================
cat("========================================\n")
cat("  1. GSE163614 功能富集分析\n")
cat("========================================\n")

res_163 <- readRDS(file.path(RESULTS, "01_bulk_DEG/GSE163614_res.rds"))

# 转换Gene Symbol -> Entrez ID
gene_map_163 <- bitr(res_163$gene, fromType = "SYMBOL",
                     toType = "ENTREZID", OrgDb = org.Rn.eg.db)
res_163_e <- merge(res_163, gene_map_163, by.x = "gene", by.y = "SYMBOL")
res_163_e <- res_163_e[!duplicated(res_163_e$ENTREZID), ]

# 上调/下调基因
up_163 <- res_163_e$ENTREZID[res_163_e$padj < 0.05 & res_163_e$log2FoldChange > 0]
down_163 <- res_163_e$ENTREZID[res_163_e$padj < 0.05 & res_163_e$log2FoldChange < 0]
cat(sprintf("上调: %d, 下调: %d\n", length(up_163), length(down_163)))

# GO富集 (BP)
go_163_up <- enrichGO(gene = up_163, OrgDb = org.Rn.eg.db,
                      keyType = "ENTREZID", ont = "BP",
                      pAdjustMethod = "BH", pvalueCutoff = 0.05, qvalueCutoff = 0.2)
go_163_down <- enrichGO(gene = down_163, OrgDb = org.Rn.eg.db,
                        keyType = "ENTREZID", ont = "BP",
                        pAdjustMethod = "BH", pvalueCutoff = 0.05, qvalueCutoff = 0.2)

if (!is.null(go_163_up)) {
  cat("\n上调基因GO-BP前10:\n")
  print(head(go_163_up@result[, c("Description", "p.adjust", "Count")], 10))
  write.csv(go_163_up@result, file.path(RESULTS, "03_enrichment/GSE163614_GO_BP_up.csv"), row.names = FALSE)
}
if (!is.null(go_163_down)) {
  cat("\n下调基因GO-BP前10:\n")
  print(head(go_163_down@result[, c("Description", "p.adjust", "Count")], 10))
  write.csv(go_163_down@result, file.path(RESULTS, "03_enrichment/GSE163614_GO_BP_down.csv"), row.names = FALSE)
}

# KEGG富集
kegg_163_up <- tryCatch({
  enrichKEGG(gene = up_163, organism = "rno",
             pvalueCutoff = 0.05, pAdjustMethod = "BH")
}, error = function(e) { cat("KEGG上调分析失败:", conditionMessage(e), "\n"); NULL })

kegg_163_down <- tryCatch({
  enrichKEGG(gene = down_163, organism = "rno",
             pvalueCutoff = 0.05, pAdjustMethod = "BH")
}, error = function(e) { cat("KEGG下调分析失败:", conditionMessage(e), "\n"); NULL })

if (!is.null(kegg_163_up) && nrow(kegg_163_up@result) > 0) {
  write.csv(kegg_163_up@result, file.path(RESULTS, "03_enrichment/GSE163614_KEGG_up.csv"), row.names = FALSE)
}
if (!is.null(kegg_163_down) && nrow(kegg_163_down@result) > 0) {
  write.csv(kegg_163_down@result, file.path(RESULTS, "03_enrichment/GSE163614_KEGG_down.csv"), row.names = FALSE)
}

# GSEA
gene_list_163 <- res_163_e$log2FoldChange
names(gene_list_163) <- res_163_e$ENTREZID
gene_list_163 <- sort(gene_list_163[!is.na(gene_list_163)], decreasing = TRUE)

gsea_go_163 <- tryCatch({
  gseGO(geneList = gene_list_163, OrgDb = org.Rn.eg.db,
        keyType = "ENTREZID", ont = "BP",
        pvalueCutoff = 0.05, verbose = FALSE, eps = 0)
}, error = function(e) { cat("GSEA-GO失败:", conditionMessage(e), "\n"); NULL })

if (!is.null(gsea_go_163) && nrow(gsea_go_163@result) > 0) {
  cat("\nGSEA-GO前10通路:\n")
  print(head(gsea_go_163@result[, c("Description", "NES", "p.adjust")], 10))
  write.csv(gsea_go_163@result, file.path(RESULTS, "03_enrichment/GSE163614_GSEA_GO.csv"), row.names = FALSE)
}

# ============================================================
# 2. GSE137482 (小鼠) GO/KEGG富集
# ============================================================
cat("\n\n========================================\n")
cat("  2. GSE137482 功能富集分析\n")
cat("========================================\n")

res_137 <- readRDS(file.path(RESULTS, "01_bulk_DEG/GSE137482_res.rds"))

gene_map_137 <- bitr(res_137$gene, fromType = "SYMBOL",
                     toType = "ENTREZID", OrgDb = org.Mm.eg.db)
res_137_e <- merge(res_137, gene_map_137, by.x = "gene", by.y = "SYMBOL")
res_137_e <- res_137_e[!duplicated(res_137_e$ENTREZID), ]

up_137 <- res_137_e$ENTREZID[res_137_e$padj < 0.05 & res_137_e$log2FoldChange > 0]
down_137 <- res_137_e$ENTREZID[res_137_e$padj < 0.05 & res_137_e$log2FoldChange < 0]
cat(sprintf("上调: %d, 下调: %d\n", length(up_137), length(down_137)))

go_137_up <- enrichGO(gene = up_137, OrgDb = org.Mm.eg.db,
                      keyType = "ENTREZID", ont = "BP",
                      pAdjustMethod = "BH", pvalueCutoff = 0.05)
go_137_down <- enrichGO(gene = down_137, OrgDb = org.Mm.eg.db,
                        keyType = "ENTREZID", ont = "BP",
                        pAdjustMethod = "BH", pvalueCutoff = 0.05)

if (!is.null(go_137_up) && nrow(go_137_up@result) > 0) {
  write.csv(go_137_up@result, file.path(RESULTS, "03_enrichment/GSE137482_GO_BP_up.csv"), row.names = FALSE)
}
if (!is.null(go_137_down) && nrow(go_137_down@result) > 0) {
  write.csv(go_137_down@result, file.path(RESULTS, "03_enrichment/GSE137482_GO_BP_down.csv"), row.names = FALSE)
}

kegg_137_up <- tryCatch({
  enrichKEGG(gene = up_137, organism = "mmu", pvalueCutoff = 0.05)
}, error = function(e) NULL)
kegg_137_down <- tryCatch({
  enrichKEGG(gene = down_137, organism = "mmu", pvalueCutoff = 0.05)
}, error = function(e) NULL)

if (!is.null(kegg_137_up) && nrow(kegg_137_up@result) > 0) {
  write.csv(kegg_137_up@result, file.path(RESULTS, "03_enrichment/GSE137482_KEGG_up.csv"), row.names = FALSE)
}
if (!is.null(kegg_137_down) && nrow(kegg_137_down@result) > 0) {
  write.csv(kegg_137_down@result, file.path(RESULTS, "03_enrichment/GSE137482_KEGG_down.csv"), row.names = FALSE)
}

# GSEA
gene_list_137 <- res_137_e$log2FoldChange
names(gene_list_137) <- res_137_e$ENTREZID
gene_list_137 <- sort(gene_list_137[!is.na(gene_list_137)], decreasing = TRUE)

gsea_go_137 <- tryCatch({
  gseGO(geneList = gene_list_137, OrgDb = org.Mm.eg.db,
        keyType = "ENTREZID", ont = "BP",
        pvalueCutoff = 0.05, verbose = FALSE, eps = 0)
}, error = function(e) NULL)

if (!is.null(gsea_go_137) && nrow(gsea_go_137@result) > 0) {
  write.csv(gsea_go_137@result, file.path(RESULTS, "03_enrichment/GSE137482_GSEA_GO.csv"), row.names = FALSE)
}

# ============================================================
# 3. R-loop相关通路富集
# ============================================================
cat("\n\n========================================\n")
cat("  3. R-loop/DNA损伤/表观遗传相关通路\n")
cat("========================================\n")

# 定义关注的通路关键词
pathway_keywords <- c(
  "DNA repair", "DNA damage", "chromatin", "epigenetic",
  "histone", "methylation", "acetylation", "R-loop",
  "transcription", "RNA processing", "cell cycle",
  "apoptosis", "neuroinflammation", "immune",
  "oxidative stress", "mitochondria", "autophagy",
  "ischemia", "stroke", "neuro"
)

# 在GSE163614的GSEA结果中搜索相关通路
if (!is.null(gsea_go_163) && nrow(gsea_go_163@result) > 0) {
  cat("\nGSE163614中与R-loop/表观遗传相关的GSEA通路:\n")
  relevant_163 <- gsea_go_163@result[
    grepl(paste(pathway_keywords, collapse = "|"),
          gsea_go_163@result$Description, ignore.case = TRUE),
    c("Description", "NES", "p.adjust", "leading_edge")
  ]
  if (nrow(relevant_163) > 0) {
    print(relevant_163, row.names = FALSE)
    write.csv(relevant_163, file.path(RESULTS, "03_enrichment/GSE163614_relevant_pathways.csv"), row.names = FALSE)
  } else {
    cat("  未找到直接相关通路\n")
  }
}

if (!is.null(gsea_go_137) && nrow(gsea_go_137@result) > 0) {
  cat("\nGSE137482中与R-loop/表观遗传相关的GSEA通路:\n")
  relevant_137 <- gsea_go_137@result[
    grepl(paste(pathway_keywords, collapse = "|"),
          gsea_go_137@result$Description, ignore.case = TRUE),
    c("Description", "NES", "p.adjust", "leading_edge")
  ]
  if (nrow(relevant_137) > 0) {
    print(relevant_137, row.names = FALSE)
    write.csv(relevant_137, file.path(RESULTS, "03_enrichment/GSE137482_relevant_pathways.csv"), row.names = FALSE)
  }
}

# ============================================================
# 4. 可视化
# ============================================================
cat("\n\n========================================\n")
cat("  4. 生成富集分析图表\n")
cat("========================================\n")

# GSE163614 上调GO气泡图
if (!is.null(go_163_up) && nrow(go_163_up@result) > 0) {
  p1 <- dotplot(go_163_up, showCategory = 15, title = "GSE163614 Upregulated GO-BP") +
    theme(axis.text.y = element_text(size = 8))
  ggsave(file.path(RESULTS, "03_enrichment/figures/GSE163614_GO_up_dotplot.png"),
         p1, width = 10, height = 8, dpi = 300)
  cat("GSE163614 GO上调气泡图已保存\n")
}

if (!is.null(go_163_down) && nrow(go_163_down@result) > 0) {
  p2 <- dotplot(go_163_down, showCategory = 15, title = "GSE163614 Downregulated GO-BP") +
    theme(axis.text.y = element_text(size = 8))
  ggsave(file.path(RESULTS, "03_enrichment/figures/GSE163614_GO_down_dotplot.png"),
         p2, width = 10, height = 8, dpi = 300)
  cat("GSE163614 GO下调气泡图已保存\n")
}

# GSEA核心富集图
if (!is.null(gsea_go_163) && nrow(gsea_go_163@result) > 0) {
  top_pathways <- head(gsea_go_163@result$ID, 4)
  for (pid in top_pathways) {
    p <- gseaplot2(gsea_go_163, geneSetID = pid, title = gsea_go_163@result[pid, "Description"])
    fname <- paste0(file.path(RESULTS, "03_enrichment/figures/GSE163614_GSEA_"),
                    gsub("[^A-Za-z0-9]", "_", gsea_go_163@result[pid, "Description"]), ".png")
    ggsave(fname, p, width = 8, height = 6, dpi = 300)
  }
  cat("GSE163614 GSEA图已保存\n")
}

cat("\n\n功能富集分析完成！\n")
