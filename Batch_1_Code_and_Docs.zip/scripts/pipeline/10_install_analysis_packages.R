# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 10_install_analysis_packages.R
# 安装后续分析所需的全部R包
# ============================================================

options(repos = c(CRAN = "https://cloud.r-project.org"))
options(BioC_mirror = "https://mirrors.tuna.tsinghua.edu.cn/bioconductor")
options(timeout = 600)

cat("========================================\n")
cat("  安装分析所需R包\n")
cat("  R版本:", R.version.string, "\n")
cat("========================================\n\n")

# ----------------------------------------------------------
# 1. Bioconductor包管理器
# ----------------------------------------------------------
if (!requireNamespace("BiocManager", quietly = TRUE)) {
  cat("安装BiocManager...\n")
  install.packages("BiocManager", quiet = TRUE)
}
library(BiocManager)

# ----------------------------------------------------------
# 2. CRAN包
# ----------------------------------------------------------
cran_pkgs <- c(
  "Seurat", "WGCNA", "igraph", "ggplot2", "pheatmap",
  "RColorBrewer", "ggrepel", "cowplot", "patchwork",
  "data.table", "Matrix", "future", "harmony",
  "ggpubr", "ggsci", "viridis", "circlize",
  "ComplexHeatmap", "readxl", "openxlsx", "ggvenn",
  "corrplot", "survival", "survminer", "glmnet",
  "caret", "pROC", "e1071", "randomForest",
  "dplyr", "tidyr", "stringr", "purrr", "tibble",
  "forcats", "readr", "magrittr"
)

cat("\n--- 安装CRAN包 ---\n")
for (pkg in cran_pkgs) {
  if (requireNamespace(pkg, quietly = TRUE)) {
    cat(sprintf("  [OK] %s (已安装)\n", pkg))
  } else {
    cat(sprintf("  [安装] %s ... ", pkg))
    tryCatch({
      install.packages(pkg, quiet = TRUE, dependencies = TRUE)
      if (requireNamespace(pkg, quietly = TRUE)) {
        cat("成功\n")
      } else {
        cat("失败\n")
      }
    }, error = function(e) {
      cat("失败:", conditionMessage(e), "\n")
    })
  }
}

# ----------------------------------------------------------
# 3. Bioconductor包
# ----------------------------------------------------------
bioc_pkgs <- c(
  "DESeq2", "edgeR", "limma", "clusterProfiler",
  "org.Hs.eg.db", "org.Mm.eg.db", "org.Rn.eg.db",
  "AnnotationDbi", "biomaRt", "EnhancedVolcano",
  "ComplexHeatmap", "ChIPseeker", "TxDb.Mmusculus.UCSC.mm10.knownGene",
  "TxDb.Rnorvegicus.UCSC.rn6.refGene", "org.Rn.eg.db",
  "GenomicRanges", "GenomicFeatures", "rtracklayer",
  "Rsamtools", "BSgenome.Mmusculus.UCSC.mm10"
)

cat("\n--- 安装Bioconductor包 ---\n")
for (pkg in bioc_pkgs) {
  if (requireNamespace(pkg, quietly = TRUE)) {
    cat(sprintf("  [OK] %s (已安装)\n", pkg))
  } else {
    cat(sprintf("  [安装] %s ... ", pkg))
    tryCatch({
      BiocManager::install(pkg, ask = FALSE, quiet = TRUE, update = FALSE)
      if (requireNamespace(pkg, quietly = TRUE)) {
        cat("成功\n")
      } else {
        cat("失败\n")
      }
    }, error = function(e) {
      cat("失败:", conditionMessage(e), "\n")
    })
  }
}

# ----------------------------------------------------------
# 4. Signac (ATAC-seq分析，从CRAN安装)
# ----------------------------------------------------------
cat("\n--- 安装Signac ---\n")
if (requireNamespace("Signac", quietly = TRUE)) {
  cat("  [OK] Signac (已安装)\n")
} else {
  cat("  [安装] Signac ... ")
  tryCatch({
    install.packages("Signac", quiet = TRUE, dependencies = TRUE)
    if (requireNamespace("Signac", quietly = TRUE)) {
      cat("成功\n")
    } else {
      cat("失败\n")
    }
  }, error = function(e) {
    cat("失败:", conditionMessage(e), "\n")
  })
}

# ----------------------------------------------------------
# 5. 验证安装
# ----------------------------------------------------------
cat("\n\n========================================\n")
cat("  验证安装结果\n")
cat("========================================\n")

all_pkgs <- c(cran_pkgs, bioc_pkgs, "Signac")
installed <- c()
failed <- c()

for (pkg in all_pkgs) {
  if (requireNamespace(pkg, quietly = TRUE)) {
    installed <- c(installed, pkg)
  } else {
    failed <- c(failed, pkg)
  }
}

cat(sprintf("\n成功安装: %d/%d\n", length(installed), length(all_pkgs)))
if (length(failed) > 0) {
  cat("失败的包:\n")
  for (pkg in failed) cat(sprintf("  - %s\n", pkg))
}

# 打印关键包版本
cat("\n关键包版本:\n")
key_pkgs <- c("Seurat", "Signac", "DESeq2", "edgeR", "limma",
             "clusterProfiler", "WGCNA", "igraph", "ggplot2")
for (pkg in key_pkgs) {
  if (requireNamespace(pkg, quietly = TRUE)) {
    v <- as.character(packageVersion(pkg))
    cat(sprintf("  %s: %s\n", pkg, v))
  }
}

cat("\n安装完成！\n")
