# Recompute module-trait statistics from the retained GSE137482 checkpoint.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
arg <- grep("^--file=", commandArgs(FALSE), value=TRUE)
root <- normalizePath(file.path(dirname(sub("^--file=", "", arg[1])), "../.."), winslash="/")
load(file.path(root, "data/checkpoints/wgcna_workspace.RData"))
stopifnot(nrow(datExpr) == 24L, identical(rownames(datExpr), rownames(MEs)))
traits <- data.frame(MCAO=as.integer(grepl("^MCAO", rownames(datExpr))),
                     Age=as.integer(grepl("18M", rownames(datExpr))), row.names=rownames(datExpr))
r <- cor(MEs, traits)
df <- nrow(datExpr) - 2L
p <- 2 * pt(abs(r * sqrt(df / (1 - r^2))), df=df, lower.tail=FALSE)
out <- data.frame(module=rownames(r), cor_MCAO=r[,"MCAO"], p_MCAO=p[,"MCAO"],
                  cor_Age=r[,"Age"], p_Age=p[,"Age"])
target <- file.path(root, "outputs/pipeline/06_wgcna")
dir.create(target, recursive=TRUE, showWarnings=FALSE)
write.csv(out, file.path(target, "module_trait_relationships.csv"), row.names=FALSE)
write.csv(data.frame(sample=rownames(traits), traits), file.path(target, "sample_traits.csv"), row.names=FALSE)
print(out)
