# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 05_download_supplementary.R
# 下载RNA-seq数据集的supplementary files (counts矩阵)
# 处理GSE163614和GSE137482
# ============================================================


suppressPackageStartupMessages({
  library(GEOquery)
  library(Biobase)
  library(tidyverse)
})

# ============================================================
# 检查GSE163614的supplementary files
# ============================================================
cat("========================================\n")
cat("  检查GSE163614 supplementary files\n")
cat("========================================\n")

eset163 <- readRDS("01_bulk_rnaseq/processed/GSE163614_eset.rds")
pdata163 <- pData(eset163)

# 检查supplementary file列
supp_cols <- grep("supplementary", colnames(pdata163), value = TRUE)
cat("Supplementary列:", paste(supp_cols, collapse=", "), "\n")

for (col in supp_cols) {
  cat("\n", col, ":\n", sep="")
  for (i in 1:nrow(pdata163)) {
    val <- pdata163[i, col]
    if (!is.na(val) && val != "") {
      cat(sprintf("  %s: %s\n", pdata163$geo_accession[i], val))
    }
  }
}

# ============================================================
# 检查GSE137482的supplementary files
# ============================================================
cat("\n\n========================================\n")
cat("  检查GSE137482 supplementary files\n")
cat("========================================\n")

eset137 <- readRDS("01_bulk_rnaseq/processed/GSE137482_eset.rds")
pdata137 <- pData(eset137)

supp_cols2 <- grep("supplementary", colnames(pdata137), value = TRUE)
cat("Supplementary列:", paste(supp_cols2, collapse=", "), "\n")

for (col in supp_cols2) {
  cat("\n", col, ":\n", sep="")
  for (i in 1:min(nrow(pdata137), 6)) {  # 只看前6个样本
    val <- pdata137[i, col]
    if (!is.na(val) && val != "") {
      cat(sprintf("  %s: %s\n", pdata137$geo_accession[i], val))
    }
  }
}

# ============================================================
# 用getGEOSuppFiles下载supplementary files
# ============================================================
cat("\n\n========================================\n")
cat("  下载GSE163614 supplementary files\n")
cat("========================================\n")

dir.create("01_bulk_rnaseq/supplementary", showWarnings = FALSE, recursive = TRUE)

tryCatch({
  supp_files <- getGEOSuppFiles("GSE163614", baseDir = "01_bulk_rnaseq/supplementary", fetch_files = TRUE)
  cat("下载的文件:\n")
  print(rownames(supp_files))
}, error = function(e) {
  cat("下载失败:", conditionMessage(e), "\n")
  cat("尝试手动列出supplementary files...\n")
  # 尝试用getGEO并设置GSEMatrix=FALSE获取元数据
  tryCatch({
    gse_meta <- getGEO("GSE163614", GSEMatrix = FALSE, destdir = "01_bulk_rnaseq/raw")
    cat("GSE元数据获取成功\n")
    cat("包含的GSM数量:", length(Meta(gse_meta)$sample_id), "\n")
  }, error = function(e2) {
    cat("元数据获取也失败:", conditionMessage(e2), "\n")
  })
})

cat("\n\n========================================\n")
cat("  下载GSE137482 supplementary files\n")
cat("========================================\n")

tryCatch({
  supp_files2 <- getGEOSuppFiles("GSE137482", baseDir = "01_bulk_rnaseq/supplementary", fetch_files = TRUE)
  cat("下载的文件:\n")
  print(rownames(supp_files2))
}, error = function(e) {
  cat("下载失败:", conditionMessage(e), "\n")
})

cat("\n\n完成！\n")
