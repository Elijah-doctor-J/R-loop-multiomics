# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 16_wgcna_analysis.R
# WGCNA co-expression network - GSE137482 (24 samples)
# Step-by-step to avoid blockwiseModules compatibility issue
# ============================================================


suppressPackageStartupMessages({
  library(WGCNA)
  library(DESeq2)
  library(tidyverse)
  library(org.Mm.eg.db)
  library(clusterProfiler)
  library(dynamicTreeCut)
})

dir.create(file.path(RESULTS, "06_wgcna"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(RESULTS, "06_wgcna/figures"), recursive = TRUE, showWarnings = FALSE)

enableWGCNAThreads()

# Mouse R-loop genes
rloop_genes <- c(
  "Rnaseh1", "Rnaseh2a", "Rnaseh2b", "Rnaseh2c",
  "Top1", "Top1mt", "Setx", "Dhx9", "Ddx1", "Ddx3x", "Ddx5",
  "Ddx19", "Ddx21", "Aqr", "Pif1", "Fancm",
  "Brca1", "Brca2", "Fancd2", "Atr", "Atm", "Parp1",
  "Thoc1", "Thoc2", "Thoc3", "Thoc5", "Thoc6", "Thoc7",
  "Xrn2", "Prmt5", "Bcl7b", "Vdac1"
)

# ============================================================
# 1. Data preparation
# ============================================================
cat("========================================\n")
cat("  WGCNA analysis (GSE137482, 24 samples)\n")
cat("========================================\n")

dds <- readRDS(file.path(RESULTS, "01_bulk_DEG/GSE137482_dds.rds"))
vsd <- vst(dds, blind = FALSE)
expr_vsd <- assay(vsd)
cat("VST matrix:", nrow(expr_vsd), "genes x", ncol(expr_vsd), "samples\n")

# Filter: keep top 5000 by variance
gene_vars <- apply(expr_vsd, 1, var)
top_genes <- names(sort(gene_vars, decreasing = TRUE))[1:5000]
expr_filtered <- expr_vsd[top_genes, ]
cat("After variance filter:", nrow(expr_filtered), "genes\n")

datExpr <- t(expr_filtered)
cd <- as.data.frame(colData(dds))
datTraits <- data.frame(
  MCAO = ifelse(cd$group == "MCAO", 1, 0),
  Age = ifelse(cd$age == "18M", 1, 0),
  row.names = rownames(cd)
)
cat("Samples:", nrow(datExpr), "| Genes:", ncol(datExpr), "\n")

rloop_present <- intersect(rloop_genes, colnames(datExpr))
cat("R-loop genes present:", length(rloop_present), "/", length(rloop_genes), "\n")
cat("  ", paste(rloop_present, collapse = ", "), "\n")

# ============================================================
# 2. Soft threshold
# ============================================================
cat("\n--- Soft threshold ---\n")
powers <- c(1:20)
sft <- pickSoftThreshold(datExpr, powerVector = powers,
                         networkType = "signed", verbose = 5)

png(file.path(RESULTS, "06_wgcna/figures/soft_threshold.png"), width = 1600, height = 800, res = 150)
par(mfrow = c(1, 2))
plot(sft$fitIndices[, 1], -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2],
     xlab = "Soft Threshold", ylab = "SFT R^2", type = "n", main = "Scale independence")
text(sft$fitIndices[, 1], -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2],
     labels = powers, cex = 0.9, col = "red")
abline(h = 0.8, col = "blue")
plot(sft$fitIndices[, 1], sft$fitIndices[, 5],
     xlab = "Soft Threshold", ylab = "Mean Connectivity", type = "n")
text(sft$fitIndices[, 1], sft$fitIndices[, 5], labels = powers, cex = 0.9, col = "red")
dev.off()

softPower <- sft$powerEstimate
if (is.na(softPower)) softPower <- 14
cat("Selected soft threshold:", softPower, "\n")

# ============================================================
# 3. Step-by-step network construction
# ============================================================
cat("\n--- Step-by-step network construction ---\n")

# Adjacency
cat("Calculating adjacency...\n")
adjacency <- adjacency(datExpr, power = softPower, type = "signed")

# TOM
cat("Calculating TOM...\n")
TOM <- TOMsimilarity(adjacency, TOMType = "signed")
dissTOM <- 1 - TOM

# Clustering
cat("Clustering...\n")
geneTree <- hclust(as.dist(dissTOM), method = "average")

# Dynamic tree cut
cat("Cutting dendrogram...\n")
dynamicMods <- cutreeDynamic(dendro = geneTree, distM = dissTOM,
                             deepSplit = 2, pamRespectsDendro = FALSE,
                             minClusterSize = 30)
cat("Dynamic modules:", length(table(dynamicMods)), "\n")
print(table(dynamicMods))

dynamicColors <- labels2colors(dynamicMods)

# Merge similar modules
cat("Merging similar modules...\n")
MEList <- moduleEigengenes(datExpr, colors = dynamicColors)
MEs <- MEList$eigengenes
MEDiss <- 1 - cor(MEs)
METree <- hclust(as.dist(MEDiss), method = "average")
MEDissThres <- 0.25
merge <- mergeCloseModules(datExpr, dynamicColors, cutHeight = MEDissThres, verbose = 3)
moduleColors <- merge$colors
MEs <- merge$newMEs

cat("Final modules:", length(unique(moduleColors)), "\n")
print(table(moduleColors))

# Dendrogram plot
png(file.path(RESULTS, "06_wgcna/figures/module_dendrogram.png"), width = 1600, height = 800, res = 150)
plotDendroAndColors(geneTree, cbind(dynamicColors, moduleColors),
                    c("Dynamic", "Merged"), dendroLabels = FALSE, hang = 0.03,
                    addGuide = TRUE, guideHang = 0.05)
dev.off()

# ============================================================
# 4. Module-trait relationships
# ============================================================
cat("\n--- Module-trait relationships ---\n")

MEs <- orderMEs(MEs)
moduleTraitCor <- cor(MEs, datTraits, use = "p")
moduleTraitPvalue <- corPvalueStudent(moduleTraitCor, nrow(datExpr))

module_trait_df <- data.frame(
  module = rownames(moduleTraitCor),
  cor_MCAO = moduleTraitCor[, 1],
  p_MCAO = moduleTraitPvalue[, 1],
  cor_Age = moduleTraitCor[, 2],
  p_Age = moduleTraitPvalue[, 2]
)
print(module_trait_df)
write.csv(module_trait_df, file.path(RESULTS, "06_wgcna/module_trait_relationships.csv"), row.names = FALSE)

textMatrix <- paste(signif(moduleTraitCor, 2), "\n(",
                    signif(moduleTraitPvalue, 1), ")", sep = "")
dim(textMatrix) <- dim(moduleTraitCor)
png(file.path(RESULTS, "06_wgcna/figures/module_trait_heatmap.png"), width = 1000, height = 1200, res = 150)
par(mar = c(6, 8, 3, 3))
labeledHeatmap(Matrix = moduleTraitCor,
               xLabels = colnames(datTraits),
               yLabels = names(MEs),
               ySymbols = names(MEs),
               colorLabels = FALSE,
               colors = blueWhiteRed(50),
               textMatrix = textMatrix,
               setStdMargins = FALSE, cex.text = 0.8,
               zlim = c(-1, 1), main = "Module-trait relationships")
dev.off()

# ============================================================
# 5. Key module analysis
# ============================================================
cat("\n--- Key module analysis ---\n")

sig_modules <- module_trait_df$module[module_trait_df$p_MCAO < 0.05]
cat("MCAO-significant modules:", paste(sig_modules, collapse = ", "), "\n")

for (mod in sig_modules) {
  mod_color <- gsub("ME", "", mod)
  mod_genes <- colnames(datExpr)[moduleColors == mod_color]
  cat(sprintf("\nModule %s: %d genes, cor_MCAO=%.2f, p=%.2e\n",
              mod_color, length(mod_genes),
              module_trait_df$cor_MCAO[module_trait_df$module == mod],
              module_trait_df$p_MCAO[module_trait_df$module == mod]))

  rloop_in_mod <- intersect(mod_genes, rloop_genes)
  cat(sprintf("  R-loop genes: %d (%s)\n", length(rloop_in_mod),
              paste(rloop_in_mod, collapse = ", ")))

  gene_map <- bitr(mod_genes, fromType = "SYMBOL",
                   toType = "ENTREZID", OrgDb = org.Mm.eg.db)
  if (nrow(gene_map) > 10) {
    ego <- enrichGO(gene = gene_map$ENTREZID, OrgDb = org.Mm.eg.db,
                    keyType = "ENTREZID", ont = "BP",
                    pvalueCutoff = 0.05, qvalueCutoff = 0.2)
    if (!is.null(ego) && nrow(ego@result) > 0) {
      cat("  GO-BP top 5:\n")
      for (j in 1:min(5, nrow(ego@result))) {
        cat(sprintf("    %s (p=%.2e)\n", ego@result$Description[j], ego@result$p.adjust[j]))
      }
      write.csv(ego@result,
                sprintf(file.path(RESULTS, "06_wgcna/module_%s_GO.csv"), mod_color), row.names = FALSE)
    }
  }
}

# ============================================================
# 6. Hub genes
# ============================================================
cat("\n--- Hub gene selection ---\n")

geneModuleMembership <- as.data.frame(cor(datExpr, MEs, use = "p"))
MMPvalue <- as.data.frame(corPvalueStudent(as.matrix(geneModuleMembership), nrow(datExpr)))

all_hubs <- data.frame()
rloop_hubs <- data.frame()

for (mod in sig_modules) {
  mod_color <- gsub("ME", "", mod)
  mod_genes <- colnames(datExpr)[moduleColors == mod_color]
  kME <- geneModuleMembership[mod_genes, mod]
  names(kME) <- mod_genes
  kME_sorted <- sort(abs(kME), decreasing = TRUE)

  top_n <- min(30, length(kME_sorted))
  hub_df <- data.frame(
    gene = names(kME_sorted)[1:top_n],
    kME = kME_sorted[1:top_n],
    module = mod_color,
    stringsAsFactors = FALSE
  )
  all_hubs <- rbind(all_hubs, hub_df)

  cat(sprintf("\nModule %s top 10 hubs:\n", mod_color))
  for (i in 1:min(10, nrow(hub_df))) {
    cat(sprintf("  %s (kME=%.3f)\n", hub_df$gene[i], hub_df$kME[i]))
  }

  rloop_in <- intersect(mod_genes, rloop_genes)
  if (length(rloop_in) > 0) {
    rh <- data.frame(
      gene = rloop_in,
      module = mod_color,
      kME = kME[rloop_in],
      stringsAsFactors = FALSE
    )
    rloop_hubs <- rbind(rloop_hubs, rh)
  }
}

write.csv(all_hubs, file.path(RESULTS, "06_wgcna/hub_genes.csv"), row.names = FALSE)
if (nrow(rloop_hubs) > 0) {
  write.csv(rloop_hubs, file.path(RESULTS, "06_wgcna/rloop_module_membership.csv"), row.names = FALSE)
  cat("\nR-loop genes in significant modules:\n")
  print(rloop_hubs)
}

save(datExpr, moduleColors, MEs, geneModuleMembership,
     file = file.path(RESULTS, "06_wgcna/wgcna_workspace.RData"))

cat("\n\nWGCNA analysis complete!\n")
