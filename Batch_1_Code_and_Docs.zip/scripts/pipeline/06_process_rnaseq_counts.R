# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 06_process_rnaseq_counts.R
# 解压并合并GSE163614和GSE137482的RNA-seq counts数据
# ============================================================


suppressPackageStartupMessages({
  library(Biobase)
  library(tidyverse)
})

# ============================================================
# 处理GSE163614
# ============================================================
cat("========================================\n")
cat("  处理GSE163614 (大鼠MCAO/R RNA-seq)\n")
cat("========================================\n")

gse163_dir <- "01_bulk_rnaseq/supplementary/GSE163614"
dir.create(file.path(gse163_dir, "extracted"), showWarnings = FALSE, recursive = TRUE)

# 解压RAW.tar
tar_file <- file.path(gse163_dir, "GSE163614_RAW.tar")
if (file.exists(tar_file)) {
  cat("解压", tar_file, "...\n")
  untar(tar_file, exdir = file.path(gse163_dir, "extracted"))
  cat("解压完成\n")
}

# 列出解压后的文件
extracted_files <- list.files(file.path(gse163_dir, "extracted"), pattern = "\\.txt\\.gz$", full.names = TRUE)
cat("找到", length(extracted_files), "个counts文件:\n")
for (f in extracted_files) {
  cat("  ", basename(f), "\n")
}

# 读取并合并counts文件
if (length(extracted_files) > 0) {
  count_list <- list()
  for (f in extracted_files) {
    fname <- basename(f)
    # 从文件名提取样本名
    sample_name <- gsub("\\.txt\\.gz$", "", fname)
    cat("读取", sample_name, "... ")
    
    # 读取文件
    df <- read.delim(gzfile(f), header = TRUE, sep = "\t", row.names = NULL,
                      stringsAsFactors = FALSE, check.names = FALSE)
    cat(dim(df)[1], "genes x", dim(df)[2], "cols\n")
    
    # 打印列名
    if (length(count_list) == 0) {
      cat("  列名:", paste(colnames(df), collapse=", "), "\n")
    }
    
    # 假设第一列是基因名，第二列是counts
    # 需要根据实际列名调整
    count_col <- if ("count" %in% colnames(df)) "count" else colnames(df)[2]
    gene_col <- colnames(df)[1]
    
    counts <- df[[count_col]]
    genes <- df[[gene_col]]
    # 清理基因名：去除NA、空字符串、重复（保留第一个）
    valid_idx <- !is.na(genes) & genes != "" & !duplicated(genes)
    counts <- counts[valid_idx]
    genes <- genes[valid_idx]
    names(counts) <- genes
    count_list[[sample_name]] <- counts
  }
  
  # 合并成矩阵
  all_genes <- unique(unlist(lapply(count_list, names)))
  all_genes <- all_genes[!is.na(all_genes) & all_genes != ""]
  count_matrix <- matrix(NA, nrow = length(all_genes), ncol = length(count_list),
                          dimnames = list(all_genes, names(count_list)))
  for (sname in names(count_list)) {
    common_genes <- intersect(names(count_list[[sname]]), rownames(count_matrix))
    count_matrix[common_genes, sname] <- count_list[[sname]][common_genes]
  }
  
  cat("\n合并后的count矩阵:", nrow(count_matrix), "genes x", ncol(count_matrix), "samples\n")
  cat("样本名:", paste(colnames(count_matrix), collapse=", "), "\n")
  cat("前5行前3列:\n")
  print(head(count_matrix[, 1:min(3, ncol(count_matrix))], 5))
  
  # 保存
  saveRDS(count_matrix, file = "01_bulk_rnaseq/processed/GSE163614_counts_matrix.rds")
  write.csv(count_matrix, file = "01_bulk_rnaseq/processed/GSE163614_counts_matrix.csv")
  cat("已保存count矩阵\n")
  
  # 也尝试读取xlsx文件（如果有）
  xlsx_file <- file.path(gse163_dir, "GSE163614_mRNA_Expression_Profiling.xlsx")
  if (file.exists(xlsx_file)) {
    cat("\n发现xlsx表达矩阵文件，尝试读取...\n")
    tryCatch({
      if (requireNamespace("readxl", quietly = TRUE)) {
        expr_xlsx <- readxl::read_excel(xlsx_file)
        cat("xlsx维度:", nrow(expr_xlsx), "x", ncol(expr_xlsx), "\n")
        cat("列名:", paste(colnames(expr_xlsx)[1:min(6, ncol(expr_xlsx))], collapse=", "), "\n")
        saveRDS(expr_xlsx, file = "01_bulk_rnaseq/processed/GSE163614_expr_xlsx.rds")
      } else {
        cat("readxl包未安装，跳过xlsx读取\n")
      }
    }, error = function(e) {
      cat("xlsx读取失败:", conditionMessage(e), "\n")
    })
  }
}

# ============================================================
# 处理GSE137482
# ============================================================
cat("\n\n========================================\n")
cat("  处理GSE137482 (小鼠MCAO RNA-seq)\n")
cat("========================================\n")

gse137_dir <- "01_bulk_rnaseq/supplementary/GSE137482"
dir.create(file.path(gse137_dir, "extracted"), showWarnings = FALSE, recursive = TRUE)

tar_file2 <- file.path(gse137_dir, "GSE137482_RAW.tar")
if (file.exists(tar_file2)) {
  cat("解压", tar_file2, "...\n")
  untar(tar_file2, exdir = file.path(gse137_dir, "extracted"))
  cat("解压完成\n")
}

# 列出解压后的文件（只看count.txt.gz，不看normalized）
extracted_files2 <- list.files(file.path(gse137_dir, "extracted"), 
                                 pattern = "count\\.txt\\.gz$", full.names = TRUE)
# 排除normalized count文件
extracted_files2 <- extracted_files2[!grepl("normalized", extracted_files2)]

cat("找到", length(extracted_files2), "个counts文件:\n")
for (f in extracted_files2) {
  cat("  ", basename(f), "\n")
}

if (length(extracted_files2) > 0) {
  count_list2 <- list()
  for (f in extracted_files2) {
    fname <- basename(f)
    sample_name <- gsub("\\.count\\.txt\\.gz$", "", fname)
    cat("读取", sample_name, "... ")
    
    df <- read.delim(gzfile(f), header = TRUE, sep = "\t", row.names = NULL,
                      stringsAsFactors = FALSE, check.names = FALSE)
    cat(dim(df)[1], "genes x", dim(df)[2], "cols\n")
    
    if (length(count_list2) == 0) {
      cat("  列名:", paste(colnames(df), collapse=", "), "\n")
    }
    
    count_col <- if ("count" %in% colnames(df)) "count" else colnames(df)[2]
    gene_col <- colnames(df)[1]
    
    counts <- df[[count_col]]
    genes <- df[[gene_col]]
    # 清理基因名
    valid_idx <- !is.na(genes) & genes != "" & !duplicated(genes)
    counts <- counts[valid_idx]
    genes <- genes[valid_idx]
    names(counts) <- genes
    count_list2[[sample_name]] <- counts
  }
  
  all_genes2 <- unique(unlist(lapply(count_list2, names)))
  all_genes2 <- all_genes2[!is.na(all_genes2) & all_genes2 != ""]
  count_matrix2 <- matrix(NA, nrow = length(all_genes2), ncol = length(count_list2),
                           dimnames = list(all_genes2, names(count_list2)))
  for (sname in names(count_list2)) {
    common_genes <- intersect(names(count_list2[[sname]]), rownames(count_matrix2))
    count_matrix2[common_genes, sname] <- count_list2[[sname]][common_genes]
  }
  
  cat("\n合并后的count矩阵:", nrow(count_matrix2), "genes x", ncol(count_matrix2), "samples\n")
  cat("样本名:", paste(colnames(count_matrix2), collapse=", "), "\n")
  cat("前5行前3列:\n")
  print(head(count_matrix2[, 1:min(3, ncol(count_matrix2))], 5))
  
  saveRDS(count_matrix2, file = "01_bulk_rnaseq/processed/GSE137482_counts_matrix.rds")
  write.csv(count_matrix2, file = "01_bulk_rnaseq/processed/GSE137482_counts_matrix.csv")
  cat("已保存count矩阵\n")
}

cat("\n\nRNA-seq counts处理完成！\n")
