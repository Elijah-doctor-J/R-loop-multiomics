# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 13b_enrichment_supplement.R
# 补充GSE61616(大鼠) + GSE22255/GSE16561(人)的GO/GSEA富集分析
# KEGG因网络超时跳过，用GO即可
# ============================================================


suppressPackageStartupMessages({
  library(clusterProfiler)
  library(org.Rn.eg.db)
  library(org.Hs.eg.db)
  library(tidyverse)
  library(enrichplot)
  library(ggplot2)
})

dir.create(file.path(RESULTS, "03_enrichment/figures"), recursive = TRUE, showWarnings = FALSE)

# 关注的通路关键词
pathway_keywords <- c(
  "DNA repair", "DNA damage", "chromatin", "epigenetic",
  "histone", "methylation", "acetylation",
  "transcription", "RNA processing", "cell cycle",
  "apoptosis", "neuroinflammation", "immune",
  "oxidative stress", "mitochondria", "autophagy",
  "ischemia", "stroke", "neuro", "R-loop"
)

# ============================================================
# 1. GSE61616 (大鼠, limma)
# ============================================================
cat("========================================\n")
cat("  1. GSE61616 GO/GSEA enrichment\n")
cat("========================================\n")

res_616 <- readRDS(file.path(RESULTS, "01_bulk_DEG/GSE61616_res.rds"))
cat("Genes:", nrow(res_616), "\n")
cat("Columns:", paste(colnames(res_616), collapse=", "), "\n")

# 转换Gene Symbol -> Entrez ID
gene_map_616 <- bitr(res_616$gene, fromType = "SYMBOL",
                     toType = "ENTREZID", OrgDb = org.Rn.eg.db)
res_616_e <- merge(res_616, gene_map_616, by.x = "gene", by.y = "SYMBOL")
res_616_e <- res_616_e[!duplicated(res_616_e$ENTREZID), ]

up_616 <- res_616_e$ENTREZID[res_616_e$adj.P.Val < 0.05 & res_616_e$logFC > 0]
down_616 <- res_616_e$ENTREZID[res_616_e$adj.P.Val < 0.05 & res_616_e$logFC < 0]
cat(sprintf("Up: %d, Down: %d\n", length(up_616), length(down_616)))

go_616_up <- enrichGO(gene = up_616, OrgDb = org.Rn.eg.db,
                      keyType = "ENTREZID", ont = "BP",
                      pAdjustMethod = "BH", pvalueCutoff = 0.05, qvalueCutoff = 0.2)
go_616_down <- enrichGO(gene = down_616, OrgDb = org.Rn.eg.db,
                        keyType = "ENTREZID", ont = "BP",
                        pAdjustMethod = "BH", pvalueCutoff = 0.05, qvalueCutoff = 0.2)

if (!is.null(go_616_up) && nrow(go_616_up@result) > 0) {
  cat("\nUp GO-BP top 10:\n")
  print(head(go_616_up@result[, c("Description", "p.adjust", "Count")], 10))
  write.csv(go_616_up@result, file.path(RESULTS, "03_enrichment/GSE61616_GO_BP_up.csv"), row.names = FALSE)
}
if (!is.null(go_616_down) && nrow(go_616_down@result) > 0) {
  cat("\nDown GO-BP top 10:\n")
  print(head(go_616_down@result[, c("Description", "p.adjust", "Count")], 10))
  write.csv(go_616_down@result, file.path(RESULTS, "03_enrichment/GSE61616_GO_BP_down.csv"), row.names = FALSE)
}

# GSEA
gene_list_616 <- res_616_e$logFC
names(gene_list_616) <- res_616_e$ENTREZID
gene_list_616 <- sort(gene_list_616[!is.na(gene_list_616)], decreasing = TRUE)

gsea_go_616 <- tryCatch({
  gseGO(geneList = gene_list_616, OrgDb = org.Rn.eg.db,
        keyType = "ENTREZID", ont = "BP",
        pvalueCutoff = 0.05, verbose = FALSE, eps = 0, nPermSimple = 10000)
}, error = function(e) { cat("GSEA failed:", conditionMessage(e), "\n"); NULL })

if (!is.null(gsea_go_616) && nrow(gsea_go_616@result) > 0) {
  cat("\nGSEA-GO top 10:\n")
  print(head(gsea_go_616@result[, c("Description", "NES", "p.adjust")], 10))
  write.csv(gsea_go_616@result, file.path(RESULTS, "03_enrichment/GSE61616_GSEA_GO.csv"), row.names = FALSE)

  # Relevant pathways
  relevant_616 <- gsea_go_616@result[
    grepl(paste(pathway_keywords, collapse = "|"),
          gsea_go_616@result$Description, ignore.case = TRUE),
    c("Description", "NES", "p.adjust", "leading_edge")
  ]
  if (nrow(relevant_616) > 0) {
    write.csv(relevant_616, file.path(RESULTS, "03_enrichment/GSE61616_relevant_pathways.csv"), row.names = FALSE)
  }
}

# Plots
if (!is.null(go_616_up) && nrow(go_616_up@result) > 0) {
  p <- dotplot(go_616_up, showCategory = 15, title = "GSE61616 Upregulated GO-BP") +
    theme(axis.text.y = element_text(size = 8))
  ggsave(file.path(RESULTS, "03_enrichment/figures/GSE61616_GO_up_dotplot.png"), p, width = 10, height = 8, dpi = 300)
}
if (!is.null(go_616_down) && nrow(go_616_down@result) > 0) {
  p <- dotplot(go_616_down, showCategory = 15, title = "GSE61616 Downregulated GO-BP") +
    theme(axis.text.y = element_text(size = 8))
  ggsave(file.path(RESULTS, "03_enrichment/figures/GSE61616_GO_down_dotplot.png"), p, width = 10, height = 8, dpi = 300)
}

# ============================================================
# 2. GSE22255 (人, PBMC)
# ============================================================
cat("\n\n========================================\n")
cat("  2. GSE22255 (human PBMC) GO/GSEA\n")
cat("========================================\n")

res_222 <- readRDS(file.path(RESULTS, "02_human_validation/GSE22255_res.rds"))
cat("Genes:", nrow(res_222), "\n")

gene_map_222 <- bitr(res_222$gene, fromType = "SYMBOL",
                     toType = "ENTREZID", OrgDb = org.Hs.eg.db)
res_222_e <- merge(res_222, gene_map_222, by.x = "gene", by.y = "SYMBOL")
res_222_e <- res_222_e[!duplicated(res_222_e$ENTREZID), ]

up_222 <- res_222_e$ENTREZID[res_222_e$adj.P.Val < 0.05 & res_222_e$logFC > 0]
down_222 <- res_222_e$ENTREZID[res_222_e$adj.P.Val < 0.05 & res_222_e$logFC < 0]
cat(sprintf("Up: %d, Down: %d\n", length(up_222), length(down_222)))

if (length(up_222) > 5) {
  go_222_up <- enrichGO(gene = up_222, OrgDb = org.Hs.eg.db,
                        keyType = "ENTREZID", ont = "BP",
                        pAdjustMethod = "BH", pvalueCutoff = 0.05)
  if (!is.null(go_222_up) && nrow(go_222_up@result) > 0) {
    write.csv(go_222_up@result, file.path(RESULTS, "03_enrichment/GSE22255_GO_BP_up.csv"), row.names = FALSE)
  }
}
if (length(down_222) > 5) {
  go_222_down <- enrichGO(gene = down_222, OrgDb = org.Hs.eg.db,
                          keyType = "ENTREZID", ont = "BP",
                          pAdjustMethod = "BH", pvalueCutoff = 0.05)
  if (!is.null(go_222_down) && nrow(go_222_down@result) > 0) {
    write.csv(go_222_down@result, file.path(RESULTS, "03_enrichment/GSE22255_GO_BP_down.csv"), row.names = FALSE)
  }
}

# GSEA
gene_list_222 <- res_222_e$logFC
names(gene_list_222) <- res_222_e$ENTREZID
gene_list_222 <- sort(gene_list_222[!is.na(gene_list_222)], decreasing = TRUE)

gsea_go_222 <- tryCatch({
  gseGO(geneList = gene_list_222, OrgDb = org.Hs.eg.db,
        keyType = "ENTREZID", ont = "BP",
        pvalueCutoff = 0.05, verbose = FALSE, eps = 0, nPermSimple = 10000)
}, error = function(e) { cat("GSEA failed:", conditionMessage(e), "\n"); NULL })

if (!is.null(gsea_go_222) && nrow(gsea_go_222@result) > 0) {
  cat("\nGSEA-GO top 10:\n")
  print(head(gsea_go_222@result[, c("Description", "NES", "p.adjust")], 10))
  write.csv(gsea_go_222@result, file.path(RESULTS, "03_enrichment/GSE22255_GSEA_GO.csv"), row.names = FALSE)

  relevant_222 <- gsea_go_222@result[
    grepl(paste(pathway_keywords, collapse = "|"),
          gsea_go_222@result$Description, ignore.case = TRUE),
    c("Description", "NES", "p.adjust", "leading_edge")
  ]
  if (nrow(relevant_222) > 0) {
    write.csv(relevant_222, file.path(RESULTS, "03_enrichment/GSE22255_relevant_pathways.csv"), row.names = FALSE)
  }
}

# ============================================================
# 3. GSE16561 (人, whole blood)
# ============================================================
cat("\n\n========================================\n")
cat("  3. GSE16561 (human blood) GO/GSEA\n")
cat("========================================\n")

res_165 <- readRDS(file.path(RESULTS, "02_human_validation/GSE16561_res.rds"))
cat("Genes:", nrow(res_165), "\n")

gene_map_165 <- bitr(res_165$gene, fromType = "SYMBOL",
                     toType = "ENTREZID", OrgDb = org.Hs.eg.db)
res_165_e <- merge(res_165, gene_map_165, by.x = "gene", by.y = "SYMBOL")
res_165_e <- res_165_e[!duplicated(res_165_e$ENTREZID), ]

up_165 <- res_165_e$ENTREZID[res_165_e$adj.P.Val < 0.05 & res_165_e$logFC > 0]
down_165 <- res_165_e$ENTREZID[res_165_e$adj.P.Val < 0.05 & res_165_e$logFC < 0]
cat(sprintf("Up: %d, Down: %d\n", length(up_165), length(down_165)))

if (length(up_165) > 5) {
  go_165_up <- enrichGO(gene = up_165, OrgDb = org.Hs.eg.db,
                        keyType = "ENTREZID", ont = "BP",
                        pAdjustMethod = "BH", pvalueCutoff = 0.05)
  if (!is.null(go_165_up) && nrow(go_165_up@result) > 0) {
    cat("\nUp GO-BP top 10:\n")
    print(head(go_165_up@result[, c("Description", "p.adjust", "Count")], 10))
    write.csv(go_165_up@result, file.path(RESULTS, "03_enrichment/GSE16561_GO_BP_up.csv"), row.names = FALSE)
  }
}
if (length(down_165) > 5) {
  go_165_down <- enrichGO(gene = down_165, OrgDb = org.Hs.eg.db,
                          keyType = "ENTREZID", ont = "BP",
                          pAdjustMethod = "BH", pvalueCutoff = 0.05)
  if (!is.null(go_165_down) && nrow(go_165_down@result) > 0) {
    cat("\nDown GO-BP top 10:\n")
    print(head(go_165_down@result[, c("Description", "p.adjust", "Count")], 10))
    write.csv(go_165_down@result, file.path(RESULTS, "03_enrichment/GSE16561_GO_BP_down.csv"), row.names = FALSE)
  }
}

# GSEA
gene_list_165 <- res_165_e$logFC
names(gene_list_165) <- res_165_e$ENTREZID
gene_list_165 <- sort(gene_list_165[!is.na(gene_list_165)], decreasing = TRUE)

gsea_go_165 <- tryCatch({
  gseGO(geneList = gene_list_165, OrgDb = org.Hs.eg.db,
        keyType = "ENTREZID", ont = "BP",
        pvalueCutoff = 0.05, verbose = FALSE, eps = 0, nPermSimple = 10000)
}, error = function(e) { cat("GSEA failed:", conditionMessage(e), "\n"); NULL })

if (!is.null(gsea_go_165) && nrow(gsea_go_165@result) > 0) {
  cat("\nGSEA-GO top 10:\n")
  print(head(gsea_go_165@result[, c("Description", "NES", "p.adjust")], 10))
  write.csv(gsea_go_165@result, file.path(RESULTS, "03_enrichment/GSE16561_GSEA_GO.csv"), row.names = FALSE)

  relevant_165 <- gsea_go_165@result[
    grepl(paste(pathway_keywords, collapse = "|"),
          gsea_go_165@result$Description, ignore.case = TRUE),
    c("Description", "NES", "p.adjust", "leading_edge")
  ]
  if (nrow(relevant_165) > 0) {
    write.csv(relevant_165, file.path(RESULTS, "03_enrichment/GSE16561_relevant_pathways.csv"), row.names = FALSE)
  }
}

# Plots
if (exists("go_165_up") && !is.null(go_165_up) && nrow(go_165_up@result) > 0) {
  p <- dotplot(go_165_up, showCategory = 15, title = "GSE16561 Upregulated GO-BP") +
    theme(axis.text.y = element_text(size = 8))
  ggsave(file.path(RESULTS, "03_enrichment/figures/GSE16561_GO_up_dotplot.png"), p, width = 10, height = 8, dpi = 300)
}
if (exists("go_165_down") && !is.null(go_165_down) && nrow(go_165_down@result) > 0) {
  p <- dotplot(go_165_down, showCategory = 15, title = "GSE16561 Downregulated GO-BP") +
    theme(axis.text.y = element_text(size = 8))
  ggsave(file.path(RESULTS, "03_enrichment/figures/GSE16561_GO_down_dotplot.png"), p, width = 10, height = 8, dpi = 300)
}

cat("\n\nSupplement enrichment analysis complete!\n")
