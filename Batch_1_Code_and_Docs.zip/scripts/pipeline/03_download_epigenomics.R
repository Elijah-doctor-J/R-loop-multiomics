# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 03_download_epigenomics.R
# 下载第三批：表观遗传数据
# ATAC-seq: Figshare (SRP548281/CNP0005552的processed data)
# H3K27ac HiChIP: GSE319240
# 辅助: GSE175578 (小胶质细胞表观基因组)
# ============================================================


suppressPackageStartupMessages({
  library(GEOquery)
  library(Biobase)
  library(tidyverse)
})

# 创建子目录
dir.create("04_atacseq", showWarnings = FALSE, recursive = TRUE)
dir.create("04_atacseq/raw", showWarnings = FALSE, recursive = TRUE)
dir.create("04_atacseq/processed", showWarnings = FALSE, recursive = TRUE)
dir.create("04_atacseq/qc", showWarnings = FALSE, recursive = TRUE)

dir.create("05_hichip", showWarnings = FALSE, recursive = TRUE)
dir.create("05_hichip/raw", showWarnings = FALSE, recursive = TRUE)
dir.create("05_hichip/processed", showWarnings = FALSE, recursive = TRUE)
dir.create("05_hichip/qc", showWarnings = FALSE, recursive = TRUE)

dir.create("06_auxiliary", showWarnings = FALSE, recursive = TRUE)
dir.create("06_auxiliary/raw", showWarnings = FALSE, recursive = TRUE)
dir.create("06_auxiliary/processed", showWarnings = FALSE, recursive = TRUE)

# ============================================================
# 1. ATAC-seq 数据 (Figshare)
# 数据来源: Monitoring of single-nucleus chromatin landscape of 
# ischemic stroke in mouse cerebral cortex across time
# Sci Data, 2025. DOI: 10.1038/s41597-025-04367-4
# Figshare: 10.6084/m9.figshare.25558785.v4
# SRA: SRP548281
# ============================================================
cat("========================================\n")
cat("  ATAC-seq 数据下载 (Figshare)\n")
cat("========================================\n")
cat("数据集: MCAO/R小鼠大脑皮层snATAC-seq时间序列\n")
cat("时间点: Sham, 0h, 6h, 12h, 24h, 7d, 14d\n")
cat("数据量: 99,271个细胞核, 9种细胞类型\n")
cat("Figshare DOI: 10.6084/m9.figshare.25558785.v4\n")
cat("包含: gene score matrix, cell-type peak matrices, metadata, R代码\n\n")

# Figshare文件列表（需要从Figshare API获取实际下载链接）
# 先尝试用Figshare API获取文件列表
figshare_article_id <- "25558785"
figshare_api_url <- paste0("https://api.figshare.com/v2/articles/", figshare_article_id)

cat("正在从Figshare API获取文件列表...\n")
tryCatch({
  response <- jsonlite::fromJSON(figshare_api_url)
  cat("文章标题:", response$title, "\n")
  cat("文件数量:", nrow(response$files), "\n\n")
  
  # 打印文件列表
  cat("文件列表:\n")
  for (i in 1:nrow(response$files)) {
    f <- response$files[i, ]
    size_mb <- round(f$size / 1024 / 1024, 2)
    cat(sprintf("  %2d. %s (%.1f MB)\n", i, f$name, size_mb))
  }
  
  # 下载所有文件
  cat("\n开始下载...\n")
  for (i in 1:nrow(response$files)) {
    f <- response$files[i, ]
    dest_file <- file.path("04_atacseq", "raw", f$name)
    
    if (file.exists(dest_file)) {
      cat(sprintf("  [跳过] %s (已存在)\n", f$name))
      next
    }
    
    cat(sprintf("  [下载] %s ... ", f$name))
    tryCatch({
      download.file(f$download_url, destfile = dest_file, mode = "wb", quiet = TRUE)
      actual_size <- file.info(dest_file)$size
      cat(sprintf("完成 (%.1f MB)\n", actual_size / 1024 / 1024))
    }, error = function(e) {
      cat("失败:", conditionMessage(e), "\n")
    })
  }
  
}, error = function(e) {
  cat("Figshare API访问失败:", conditionMessage(e), "\n")
  cat("请手动从以下地址下载:\n")
  cat("  https://figshare.com/articles/dataset/ATAC_data_and_code_of_mononuclear_chromatin_structure_in_mice_with_ischemic_stroke/25558785\n")
  cat("  或搜索Figshare: 25558785\n")
})

# ============================================================
# 2. H3K27ac HiChIP 数据 (GSE319240)
# ============================================================
cat("\n\n========================================\n")
cat("  H3K27ac HiChIP 数据下载 (GSE319240)\n")
cat("========================================\n")
cat("数据集: 缺血性卒中后小鼠小胶质细胞H3K27ac HiChIP\n")
cat("样本: FACS分选CD45intCD11bint小胶质细胞, sham + 缺血后6天\n")
cat("用途: 增强子活性 + 增强子-启动子染色质环\n\n")

tryCatch({
  gse <- getGEO(
    GEO = "GSE319240",
    destdir = "05_hichip/raw",
    GSEMatrix = TRUE,
    AnnotGPL = TRUE
  )
  
  if (is.list(gse)) gse <- gse[[1]]
  
  cat("下载成功！\n")
  cat("样本数:", ncol(gse), "\n")
  cat("平台:", annotation(gse), "\n")
  
  saveRDS(gse, file = "05_hichip/processed/GSE319240_eset.rds")
  
  pdata <- pData(gse)
  write.csv(pdata, file = "05_hichip/processed/GSE319240_phenotype_data.csv", row.names = TRUE)
  
  cat("\n样本信息:\n")
  for (i in 1:ncol(gse)) {
    cat(sprintf("  %2d. %s\n", i, pdata$title[i]))
  }
  
  # 检查supplementary files（HiChIP的peaks和loops通常在supplementary files里）
  cat("\n注意: HiChIP的peaks和loops数据可能在GEO supplementary files中\n")
  cat("需要检查GSE319240页面的supplementary files并手动下载\n")
  cat("GEO链接: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE319240\n")
  
  hichip_status <- "OK (series matrix downloaded, supplementary files may need manual download)"
  
}, error = function(e) {
  cat("下载失败:", conditionMessage(e), "\n")
  hichip_status <<- paste("FAIL:", conditionMessage(e))
})

# ============================================================
# 3. 辅助数据 GSE175578 (小胶质细胞表观基因组)
# ============================================================
cat("\n\n========================================\n")
cat("  辅助数据下载 (GSE175578)\n")
cat("========================================\n")
cat("数据集: 小胶质细胞表观基因组 (LPS和衰老模型)\n")
cat("包含: H3K4me3, H3K27ac, H3K4me1, H3K27me3 ChIP-seq + RNA-seq\n")
cat("用途: 小胶质细胞表观基因组基准参考\n\n")

tryCatch({
  gse <- getGEO(
    GEO = "GSE175578",
    destdir = "06_auxiliary/raw",
    GSEMatrix = TRUE,
    AnnotGPL = TRUE
  )
  
  if (is.list(gse)) gse <- gse[[1]]
  
  cat("下载成功！\n")
  cat("样本数:", ncol(gse), "\n")
  cat("平台:", annotation(gse), "\n")
  
  saveRDS(gse, file = "06_auxiliary/processed/GSE175578_eset.rds")
  
  pdata <- pData(gse)
  write.csv(pdata, file = "06_auxiliary/processed/GSE175578_phenotype_data.csv", row.names = TRUE)
  
  cat("\n样本信息 (前20个):\n")
  for (i in 1:min(ncol(gse), 20)) {
    cat(sprintf("  %2d. %s\n", i, pdata$title[i]))
  }
  if (ncol(gse) > 20) cat(sprintf("  ... 共 %d 个样本\n", ncol(gse)))
  
  aux_status <- "OK"
  
}, error = function(e) {
  cat("下载失败:", conditionMessage(e), "\n")
  aux_status <<- paste("FAIL:", conditionMessage(e))
})

# ============================================================
# 汇总报告
# ============================================================
cat("\n\n", strrep("=", 60), "\n", sep = "")
cat("第三批下载汇总报告\n")
cat(strrep("=", 60), "\n", sep = "")

report <- data.frame(
  Dataset = c("snATAC-seq (Figshare 25558785)", "GSE319240 (H3K27ac HiChIP)", "GSE175578 (辅助)"),
  Type = c("snATAC-seq", "HiChIP", "ChIP-seq+RNA-seq"),
  Species = c("Mus musculus", "Mus musculus", "Mus musculus"),
  Status = c("见上方下载详情", hichip_status, aux_status),
  stringsAsFactors = FALSE
)

print(report, row.names = FALSE)
write.csv(report, file = "05_hichip/qc/03_download_report.csv", row.names = FALSE)

cat("\n第三批下载完成！\n")
cat("\n注意事项:\n")
cat("1. ATAC-seq的原始fastq在SRA (SRP548281)，但我们用Figshare上处理好的矩阵即可\n")
cat("2. HiChIP的peaks和loops文件可能需要从GEO supplementary files手动下载\n")
cat("3. 如果Figshare下载失败，请手动访问 https://figshare.com/articles/dataset/25558785\n")
