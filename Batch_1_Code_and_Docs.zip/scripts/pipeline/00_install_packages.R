# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 00_install_packages.R
# 安装所有需要的R包
# ============================================================

# 设置CRAN镜像（清华）
options(repos = c(CRAN = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/"))

# 安装BiocManager
if (!requireNamespace("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager")
}

# 设置Bioconductor镜像（清华）
options(BioC_mirror = "https://mirrors.tuna.tsinghua.edu.cn/bioconductor")

# Bioconductor包
bioc_pkgs <- c(
  "GEOquery",      # GEO数据下载
  "Biobase",       # ExpressionSet处理
  "limma",         # 差异分析+微阵列标准化
  "org.Hs.eg.db",  # 人类注释
  "org.Mm.eg.db",  # 小鼠注释
  "org.Rn.eg.db"   # 大鼠注释
)

# CRAN包
cran_pkgs <- c(
  "tidyverse",     # 数据处理（dplyr, ggplot2, readr等）
  "jsonlite"       # JSON处理（已有）
)

# 安装Bioconductor包
cat("=== 安装Bioconductor包 ===\n")
for (pkg in bioc_pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    cat("安装:", pkg, "\n")
    BiocManager::install(pkg, ask = FALSE, update = FALSE)
  } else {
    cat("已安装:", pkg, "\n")
  }
}

# 安装CRAN包
cat("\n=== 安装CRAN包 ===\n")
for (pkg in cran_pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    cat("安装:", pkg, "\n")
    install.packages(pkg)
  } else {
    cat("已安装:", pkg, "\n")
  }
}

# 验证安装
cat("\n=== 验证安装 ===\n")
all_pkgs <- c(bioc_pkgs, cran_pkgs)
for (pkg in all_pkgs) {
  status <- requireNamespace(pkg, quietly = TRUE)
  cat(sprintf("%-15s: %s\n", pkg, ifelse(status, "OK", "FAIL")))
}

cat("\n安装完成！\n")
