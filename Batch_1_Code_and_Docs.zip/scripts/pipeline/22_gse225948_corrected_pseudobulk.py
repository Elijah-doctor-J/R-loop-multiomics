"""GSE225948 final normalized per-cell and pooled-sample-library expression contrasts.

Default: recompute from the bundled compact log1p(counts/library-size*10000)
matrix. Rebuild that input from the complete released gene matrices with:
  python scripts/pipeline/22_gse225948_corrected_pseudobulk.py --from-raw --raw-dir DIR
DIR contains the counts and metadata CSV.gz files for GSM7060815--GSM7060826
from https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE225948 .

Full-matrix library sizes are checked against released nCount_RNA. Cell IDs are
matched exactly before annotations are attached. Ddx19 is unavailable because
only Ddx19a/Ddx19b are present; those paralogs are not combined. Each GSM is a
pooled sample library, not an individual mouse. The four libraries per condition
are the analysis units: log-expression is averaged within each library x parent
cell type, with at least 10 recovered cells required. Two-sided
Mann--Whitney p-values enumerate all group-label permutations (including ties),
and BH controls 31 genes per cell type and contrast. Welch tests are a sensitivity
analysis. Per-cell p-values are exploratory, unadjusted, and do not establish
independent animal-level replication. Effect columns are mean log-expression differences,
not log2 fold changes. D14 means Day14 minus Day2 throughout.

Outputs go under outputs/pipeline/10_gse225948, leaving supplied data unchanged.
The legacy "animal" filename and summary key refer to pooled sample libraries.
"""
from argparse import ArgumentParser
from itertools import combinations
from pathlib import Path
import json
import math
import os
import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu, rankdata, ttest_ind

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'data/main_tables/10_scrna_gse225948'
DEFAULT_OUT = ROOT / 'outputs/pipeline/10_gse225948'
INPUT_NAME = 'GSE225948_normalized_31genes_percell.csv.gz'
STD32 = ['Rnaseh1','Rnaseh2a','Rnaseh2b','Rnaseh2c','Top1','Top1mt','Setx','Dhx9',
         'Ddx1','Ddx3x','Ddx5','Ddx19','Ddx21','Aqr','Pif1','Fancm','Brca1','Brca2',
         'Fancd2','Atr','Atm','Parp1','Thoc1','Thoc2','Thoc3','Thoc5','Thoc6','Thoc7',
         'Xrn2','Prmt5','Bcl7b','Vdac1']
GENES = [g for g in STD32 if g != 'Ddx19']
GSMS = [f'GSM70608{i}' for i in range(15,27)]
GROUP = {**dict.fromkeys(GSMS[:4],'Sham'), **dict.fromkeys(GSMS[4:8],'D02'),
         **dict.fromkeys(GSMS[8:],'D14')}


def bh(values):
    """BH with a 31-gene family; untestable entries remain missing."""
    p = np.asarray(values, float)
    finite = np.isfinite(p)
    out = np.full(len(p), np.nan)
    q = p[finite]
    order = np.argsort(q)
    ranked = q[order] * len(p) / np.arange(1,len(q)+1)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    res = np.empty(len(q)); res[order] = np.clip(ranked,0,1)
    out[finite] = res
    return out


def exact_mw(a,b):
    """Exact two-sided rank-sum permutation p; valid with tied expression."""
    a=np.asarray(a,float); b=np.asarray(b,float)
    if len(a)<2 or len(b)<2:
        return np.nan
    ranks=rankdata(np.r_[a,b],method='average')
    n=len(a); centre=n*(len(ranks)+1)/2
    observed=abs(ranks[:n].sum()-centre)
    extreme=sum(abs(ranks[list(idx)].sum()-centre)>=observed-1e-12
                for idx in combinations(range(len(ranks)),n))
    return extreme/math.comb(len(ranks),n)


def from_raw(folder):
    folder=Path(folder)
    frames=[]; records=[]
    for gsm in GSMS:
        counts=list(folder.glob(f'{gsm}_*counts.csv.gz'))
        metas=list(folder.glob(f'{gsm}_*metadata.csv.gz'))
        if len(counts)!=1 or len(metas)!=1:
            raise ValueError(f'Expected one counts/metadata pair for {gsm}')
        md=pd.read_csv(metas[0],index_col=0)
        header=pd.read_csv(counts[0],nrows=0,index_col=0)
        ids=header.columns
        if not md.index.is_unique or not ids.is_unique or set(md.index)!=set(ids):
            raise ValueError(f'{gsm}: cell IDs are duplicated or do not match')
        md=md.loc[ids]
        lib=np.zeros(len(ids),float); selected={}
        # Sum over every released gene, not just the curated panel.
        for chunk in pd.read_csv(counts[0],index_col=0,chunksize=256):
            values=chunk.to_numpy(float)
            if not np.isfinite(values).all() or (values<0).any():
                raise ValueError(f'{gsm}: invalid count values')
            lib += values.sum(axis=0)
            for gene in chunk.index.intersection(GENES):
                if gene in selected:
                    raise ValueError(f'{gsm}: repeated gene {gene}')
                selected[gene]=chunk.loc[gene].to_numpy(float)
        if set(selected)!=set(GENES) or (lib<=0).any():
            raise ValueError(f'{gsm}: missing curated gene or empty cell')
        if not np.allclose(lib,md.nCount_RNA.to_numpy(float),rtol=1e-7,atol=1e-8):
            raise ValueError(f'{gsm}: full count sums differ from nCount_RNA')
        frame=pd.DataFrame({g:np.log1p(selected[g]/lib*10000.) for g in GENES})
        frame.insert(0,'library_size',lib)
        frame.insert(0,'grp',GROUP[gsm])
        frame.insert(0,'gsm',gsm)
        frame.insert(0,'parent',md.parent.to_numpy())
        frame.insert(0,'cell_id',[f'{gsm}_{x}' for x in ids])
        frames.append(frame)
        records.append({'sample':gsm,'n_cells':len(frame),'cell_ids_matched':True,
                        'library_sum_matches_nCount_RNA':True})
        print(f'{gsm}: {len(frame)} cells, full-matrix normalization verified',flush=True)
    return pd.concat(frames,ignore_index=True),records


def analyze(cell):
    if not cell.cell_id.is_unique or set(cell.gsm.unique())!=set(GSMS):
        raise ValueError('Cell IDs or the 12-sample cohort are invalid')
    if not cell.grp.eq(cell.gsm.map(GROUP)).all():
        raise ValueError('Sample/group mapping differs from released study design')
    keys=['parent','gsm','grp']
    animal=cell.groupby(keys,sort=True)[GENES].mean().reset_index()
    sizes=cell.groupby(keys,sort=True).size().rename('n_cells').reset_index()
    animal=animal.merge(sizes,on=keys,validate='one_to_one')
    animal.insert(4,'eligible_ge10_cells',animal.n_cells>=10)
    pseudo=[]; percell=[]
    for ct in sorted(cell.parent.unique()):
        dc=cell[cell.parent==ct]
        da=animal[(animal.parent==ct)&animal.eligible_ge10_cells]
        for gene in GENES:
            sh=da.loc[da.grp=='Sham',gene].to_numpy()
            d2=da.loc[da.grp=='D02',gene].to_numpy()
            d14=da.loc[da.grp=='D14',gene].to_numpy()
            pseudo.append(dict(celltype=ct,gene=gene,nCtrl_D2=len(sh),nCase_D2=len(d2),
                nCase_D14=len(d14),logFC_D2=d2.mean()-sh.mean() if len(sh) and len(d2) else np.nan,
                logFC_D14=d14.mean()-d2.mean() if len(d2) and len(d14) else np.nan,
                pval_MW_D2=exact_mw(d2,sh),pval_MW_D14=exact_mw(d14,d2),
                pval_Welch_D2=ttest_ind(d2,sh,equal_var=False).pvalue if min(len(d2),len(sh))>=2 else np.nan,
                pval_Welch_D14=ttest_ind(d14,d2,equal_var=False).pvalue if min(len(d14),len(d2))>=2 else np.nan))
            a=dc.loc[dc.grp=='Sham',gene].to_numpy()
            b=dc.loc[dc.grp=='D02',gene].to_numpy()
            c=dc.loc[dc.grp=='D14',gene].to_numpy()
            percell.append(dict(celltype=ct,gene=gene,n_ShamD2=len(a),n_StrokeD2=len(b),
                n_StrokeD14=len(c),logFC_D2=b.mean()-a.mean(),logFC_D14=c.mean()-b.mean(),
                pval_D2=mannwhitneyu(b,a,alternative='two-sided').pvalue,
                pval_D14=mannwhitneyu(c,b,alternative='two-sided').pvalue))
    pseudo=pd.DataFrame(pseudo); percell=pd.DataFrame(percell)
    for test in ['MW','Welch']:
        for contrast in ['D2','D14']:
            pcol=f'pval_{test}_{contrast}'; qcol=f'padj_{test}_{contrast}'
            pseudo[qcol]=pseudo.groupby('celltype')[pcol].transform(bh)
    pseudo['note']='pooled sample-library mean log-expression; >=10 cells; exact MW; Welch sensitivity'
    percell['note']='per-cell exploratory; cells are not independent replicates; no BH applied'
    for frame in [pseudo,percell]:
        absent=pd.DataFrame({'celltype':sorted(cell.parent.unique()),'gene':'Ddx19',
            'note':'unavailable: no exact Ddx19 row; Ddx19a/Ddx19b one-to-many, not summed'})
        frame_na=pd.concat([frame,absent],ignore_index=True).sort_values(['celltype','gene'])
        if frame is pseudo: pseudo=frame_na
        else: percell=frame_na
    return animal,pseudo,percell


def main():
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--from-raw',action='store_true')
    ap.add_argument('--raw-dir',default=os.environ.get('GSE225948_RAW_DIR'))
    ap.add_argument('--input',type=Path,default=SOURCE/INPUT_NAME)
    ap.add_argument('--output-dir',type=Path,default=DEFAULT_OUT)
    args=ap.parse_args(); args.output_dir.mkdir(parents=True,exist_ok=True)
    records=[]
    if args.from_raw:
        if not args.raw_dir: ap.error('--raw-dir or GSE225948_RAW_DIR is required with --from-raw')
        cell,records=from_raw(args.raw_dir)
        cell.to_csv(args.output_dir/INPUT_NAME,index=False,compression={'method':'gzip','mtime':0})
    else:
        cell=pd.read_csv(args.input)
    animal,pseudo,percell=analyze(cell)
    animal.to_csv(args.output_dir/'GSE225948_animal_celltype_mean_logexpression.csv',index=False)
    pseudo.to_csv(args.output_dir/'GSE225948_pseudobulk_DE_corrected_by_celltype.csv',index=False)
    percell.to_csv(args.output_dir/'GSE225948_percell_exploratory_corrected_by_celltype.csv',index=False)
    report={'cells':len(cell),'samples':cell.gsm.nunique(),'cell_types':cell.parent.nunique(),
        'animal_celltype_rows':len(animal),'excluded_rows_lt10cells':int((~animal.eligible_ge10_cells).sum()),
        'min_MW_adjusted_p_D2':float(pseudo.padj_MW_D2.min()),
        'min_MW_adjusted_p_D14':float(pseudo.padj_MW_D14.min()),
        'MW_FDR_hits_D2':int((pseudo.padj_MW_D2<.05).sum()),
        'MW_FDR_hits_D14':int((pseudo.padj_MW_D14<.05).sum()),
        'Welch_FDR_hits_D2':int((pseudo.padj_Welch_D2<.05).sum()),
        'source_checks':records}
    (args.output_dir/'GSE225948_recomputation_summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
