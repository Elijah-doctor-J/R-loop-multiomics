# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 17_ppi_network.R
# PPI protein-protein interaction network analysis
# 1. R-loop gene PPI network (STRING)
# 2. DEG PPI network
# 3. Hub gene selection
# ============================================================


suppressPackageStartupMessages({
  library(tidyverse)
  library(igraph)
  library(clusterProfiler)
  library(org.Rn.eg.db)
  library(org.Mm.eg.db)
  library(org.Hs.eg.db)
})

dir.create(file.path(RESULTS, "07_ppi"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(RESULTS, "07_ppi/figures"), recursive = TRUE, showWarnings = FALSE)

# Human R-loop genes (uppercase for STRING human)
rloop_genes_human <- c(
  "RNASEH1", "RNASEH2A", "RNASEH2B", "RNASEH2C",
  "TOP1", "TOP1MT", "SETX", "DHX9", "DDX1", "DDX3X", "DDX5",
  "DDX19", "DDX21", "AQR", "PIF1", "FANCM",
  "BRCA1", "BRCA2", "FANCD2", "ATR", "ATM", "PARP1",
  "THOC1", "THOC2", "THOC3", "THOC5", "THOC6", "THOC7",
  "XRN2", "PRMT5", "BCL7B", "VDAC1"
)

# ============================================================
# 1. Get PPI from STRING
# ============================================================
cat("========================================\n")
cat("  PPI Network Analysis\n")
cat("========================================\n")

get_string_ppi <- function(genes, species = 9606, score_threshold = 400) {
  cat(sprintf("Fetching PPI from STRING (taxid=%d, %d genes)...\n", species, length(genes)))

  genes_str <- paste(genes, collapse = "%0d")
  url <- sprintf(
    "https://string-db.org/api/tsv/network?identifiers=%s&species=%d&required_score=%d",
    genes_str, species, score_threshold
  )

  tryCatch({
    ppi_data <- read.delim(url, stringsAsFactors = FALSE)
    cat(sprintf("  Got %d interactions\n", nrow(ppi_data)))
    return(ppi_data)
  }, error = function(e) {
    cat("  STRING API failed:", conditionMessage(e), "\n")
    return(NULL)
  })
}

# Try human PPI (gene names are conserved)
ppi_data <- get_string_ppi(rloop_genes_human, species = 9606, score_threshold = 400)

# ============================================================
# 2. Build igraph network
# ============================================================
if (!is.null(ppi_data) && nrow(ppi_data) > 0) {

  # Extract edges
  edges <- ppi_data[, c("preferredName_A", "preferredName_B", "score")]
  colnames(edges) <- c("from", "to", "weight")

  # Build graph (remove duplicates first)
  edges <- edges[!duplicated(t(apply(edges[, 1:2], 1, sort))), ]
  edges <- edges[edges$from != edges$to, ]
  g <- graph_from_data_frame(edges, directed = FALSE)

  cat(sprintf("\nNetwork: %d nodes, %d edges\n", vcount(g), ecount(g)))

  # ============================================================
  # 3. Network topology
  # ============================================================
  V(g)$degree <- degree(g)
  V(g)$betweenness <- betweenness(g, normalized = TRUE)
  V(g)$closeness <- closeness(g, normalized = TRUE)
  V(g)$eigenvector <- eigen_centrality(g)$vector

  # Hub scores (multiple methods)
  hub_df <- data.frame(
    gene = names(V(g)),
    degree = V(g)$degree,
    betweenness = V(g)$betweenness,
    closeness = V(g)$closeness,
    eigenvector = V(g)$eigenvector,
    stringsAsFactors = FALSE
  )
  hub_df$degree_rank <- rank(-hub_df$degree, ties.method = "min")
  hub_df$betweenness_rank <- rank(-hub_df$betweenness, ties.method = "min")
  hub_df$eigenvector_rank <- rank(-hub_df$eigenvector, ties.method = "min")
  hub_df$mean_rank <- rowMeans(hub_df[, c("degree_rank", "betweenness_rank", "eigenvector_rank")])
  hub_df <- hub_df[order(hub_df$mean_rank), ]

  cat("\nTop 15 hub genes (by mean rank):\n")
  print(head(hub_df[, c("gene", "degree", "betweenness", "eigenvector", "mean_rank")], 15))

  write.csv(hub_df, file.path(RESULTS, "07_ppi/rloop_ppi_hub_genes.csv"), row.names = FALSE)

  # R-loop genes in network
  rloop_in_net <- intersect(rloop_genes_human, names(V(g)))
  cat(sprintf("\nR-loop genes in network: %d / %d\n", length(rloop_in_net), length(rloop_genes_human)))

  rloop_hub <- hub_df[hub_df$gene %in% rloop_genes_human, ]
  cat("\nR-loop gene network metrics:\n")
  print(rloop_hub[, c("gene", "degree", "betweenness", "eigenvector", "mean_rank")])
  write.csv(rloop_hub, file.path(RESULTS, "07_ppi/rloop_genes_network_metrics.csv"), row.names = FALSE)

  # ============================================================
  # 4. DEG PPI network (GSE163614)
  # ============================================================
  cat("\n\n--- DEG PPI network (GSE163614) ---\n")

  res_163 <- readRDS(file.path(RESULTS, "01_bulk_DEG/GSE163614_res.rds"))
  deg_163 <- res_163[res_163$padj < 0.05 & abs(res_163$log2FoldChange) > 0.585, ]
  deg_genes_rat <- deg_163$gene
  cat(sprintf("DEGs: %d (up: %d, down: %d)\n", nrow(deg_163),
              sum(deg_163$log2FoldChange > 0), sum(deg_163$log2FoldChange < 0)))

  # Convert rat gene symbols to human (for STRING)
  # Use biomaRt or just use rat taxid
  # Try rat directly
  ppi_deg <- get_string_ppi(deg_genes_rat, species = 10116, score_threshold = 700)

  if (is.null(ppi_deg) || nrow(ppi_deg) == 0) {
    cat("Rat STRING failed, trying human orthologs...\n")
    # Convert rat to human via orthology
    # Simple approach: capitalize first letter (most rat/human genes share symbols)
    deg_genes_human <- toupper(deg_genes_rat)
    ppi_deg <- get_string_ppi(deg_genes_human, species = 9606, score_threshold = 700)
  }

  if (!is.null(ppi_deg) && nrow(ppi_deg) > 0) {
    edges_deg <- ppi_deg[, c("preferredName_A", "preferredName_B", "score")]
    colnames(edges_deg) <- c("from", "to", "weight")

    edges_deg <- edges_deg[!duplicated(t(apply(edges_deg[, 1:2], 1, sort))), ]
    edges_deg <- edges_deg[edges_deg$from != edges_deg$to, ]
    g_deg <- graph_from_data_frame(edges_deg, directed = FALSE)

    cat(sprintf("DEG network: %d nodes, %d edges\n", vcount(g_deg), ecount(g_deg)))

    # Hub genes in DEG network
    V(g_deg)$degree <- degree(g_deg)
    V(g_deg)$betweenness <- betweenness(g_deg, normalized = TRUE)

    deg_hub <- data.frame(
      gene = names(V(g_deg)),
      degree = V(g_deg)$degree,
      betweenness = V(g_deg)$betweenness,
      stringsAsFactors = FALSE
    )
    deg_hub <- deg_hub[order(-deg_hub$degree), ]

    cat("\nTop 20 DEG hub genes:\n")
    print(head(deg_hub, 20))
    write.csv(deg_hub, file.path(RESULTS, "07_ppi/deg_ppi_hub_genes.csv"), row.names = FALSE)

    # Check overlap with R-loop genes
    rloop_in_deg <- intersect(toupper(deg_hub$gene), rloop_genes_human)
    cat("\nR-loop genes in DEG network:", paste(rloop_in_deg, collapse = ", "), "\n")

    # Save network
    saveRDS(g_deg, file.path(RESULTS, "07_ppi/deg_ppi_network.rds"))
  }

  # Save R-loop network
  saveRDS(g, file.path(RESULTS, "07_ppi/rloop_ppi_network.rds"))
  saveRDS(hub_df, file.path(RESULTS, "07_ppi/hub_df.rds"))

} else {
  stop("STRING API did not return the requested network. No synthetic or hand-assigned replacement is permitted. Use the archived processed PPI edge/vertex tables for figure reproduction, or retry the source request.")
}

# ============================================================
# 5. Cross-dataset hub gene integration
# ============================================================
cat("\n\n--- Cross-dataset hub gene integration ---\n")

# Load DEG results from all datasets
res_163 <- readRDS(file.path(RESULTS, "01_bulk_DEG/GSE163614_res.rds"))
res_137 <- readRDS(file.path(RESULTS, "01_bulk_DEG/GSE137482_res.rds"))
res_616 <- readRDS(file.path(RESULTS, "01_bulk_DEG/GSE61616_res.rds"))
res_222 <- readRDS(file.path(RESULTS, "02_human_validation/GSE22255_res.rds"))
res_165 <- readRDS(file.path(RESULTS, "02_human_validation/GSE16561_res.rds"))

# R-loop genes cross-dataset summary
rloop_summary <- read.csv(file.path(RESULTS, "01_bulk_DEG/rloop_genes_cross_dataset.csv"),
                          stringsAsFactors = FALSE)
rloop_human <- read.csv(file.path(RESULTS, "02_human_validation/rloop_genes_human.csv"),
                        stringsAsFactors = FALSE)

# Merge all
colnames(rloop_human)[colnames(rloop_human) == "gene"] <- "gene_human"
all_rloop <- merge(rloop_summary, rloop_human, by = "gene_human", all = TRUE)

# Score: number of datasets with significant change (padj < 0.05)
all_rloop$sig_count <- rowSums(cbind(
  all_rloop$GSE163614_padj < 0.05,
  all_rloop$GSE137482_padj < 0.05,
  all_rloop$GSE61616_padj < 0.05,
  all_rloop$GSE22255_padj < 0.05,
  all_rloop$GSE16561_padj < 0.05
), na.rm = TRUE)

# Direction consistency
all_rloop$direction_up <- rowSums(cbind(
  all_rloop$GSE163614_log2FC > 0,
  all_rloop$GSE137482_log2FC > 0,
  all_rloop$GSE61616_log2FC > 0,
  all_rloop$GSE22255_logFC > 0,
  all_rloop$GSE16561_logFC > 0
), na.rm = TRUE)
all_rloop$direction_down <- rowSums(cbind(
  all_rloop$GSE163614_log2FC < 0,
  all_rloop$GSE137482_log2FC < 0,
  all_rloop$GSE61616_log2FC < 0,
  all_rloop$GSE22255_logFC < 0,
  all_rloop$GSE16561_logFC < 0
), na.rm = TRUE)
all_rloop$direction_consistent <- pmax(all_rloop$direction_up, all_rloop$direction_down)

cat("\nR-loop genes ranked by significance count:\n")
ranked <- all_rloop[order(-all_rloop$sig_count, -all_rloop$direction_consistent), ]
print(ranked[, c("gene_human", "sig_count", "direction_consistent",
                 "GSE163614_log2FC", "GSE137482_log2FC", "GSE61616_log2FC",
                 "GSE22255_logFC", "GSE16561_logFC")])

write.csv(all_rloop, file.path(RESULTS, "07_ppi/rloop_genes_cross_dataset_integrated.csv"), row.names = FALSE)

cat("\n\nPPI network analysis complete!\n")
