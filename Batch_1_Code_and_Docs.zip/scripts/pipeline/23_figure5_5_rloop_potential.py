"""Rebuild the 26-gene complete-case computational susceptibility proxy.

This uncalibrated heuristic is not a measurement of R-loops. GC fractions and
lengths are author-assigned approximations. Missing bulk/ATAC estimates remain
missing and are excluded rather than assigned zero. Intrinsic and RNaseH terms
are identical in the two conditions and cancel from the change contrast.
The ATAC feature is a log2 ratio of pooled gene-activity totals (+1), not a
replicate-aware differential-accessibility estimate. Pool size, measurement
depth and cell composition can affect this feature. Min-max scaling supplies
only a cross-gene ranking and does not correct those sources of confounding.
This heuristic has no fitted calibration or inferential p-value.
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data/main_tables"
OUT = ROOT / "outputs/pipeline/12_rloop_proxy"


def minmax(values):
    span = values.max() - values.min()
    if not np.isfinite(span) or span <= 0:
        raise ValueError("Min-max normalization requires nonconstant finite values")
    return (values - values.min()) / span


def build_proxy():
    d = pd.read_csv(DATA / "12_rloop_formation_proxy/rloop_proxy_intrinsic_parameters.csv")
    assert len(d) == 32 and d.gene.is_unique
    bulk = pd.read_csv(DATA / "01_bulk_transcriptomics/GSE163614_rloop_genes.csv")
    assert bulk.gene.is_unique
    d["bulk_log2FC"] = d.gene.map(bulk.set_index("gene").log2FoldChange)
    activity = pd.read_csv(DATA / "05_snatac_accessibility/rloop_activity_by_timepoint.csv")
    assert not activity.duplicated(["gene", "timepoint"]).any()
    totals = activity.pivot(index="gene", columns="timepoint", values="activity")
    # Pseudocount is one count at the pooled-total scale.
    # Retain the supplied pooled-total feature. This is distinct from the
    # log-normalized per-nucleus comparison used in Figure 7.
    atac = np.log2((totals["M24h"] + 1) / (totals["Sham1d"] + 1))
    d["atac_log2FC"] = d.gene.map(atac)
    complete = np.isfinite(d[["gc_content", "gene_length_kb", "bulk_log2FC", "atac_log2FC"]]).all(axis=1)
    excluded = d.loc[~complete, "gene"].tolist()
    d = d.loc[complete].copy()
    assert len(d) == 26
    d["gc_norm"] = minmax(d.gc_content)
    d["length_norm"] = minmax(d.gene_length_kb)
    d["intrinsic"] = .5 * d.gc_norm + .5 * d.length_norm
    d["tx_norm"] = minmax(d.bulk_log2FC)
    d["atac_norm"] = minmax(d.atac_log2FC)
    rnaseh_bulk = bulk.set_index("gene").loc["Rnaseh1", "log2FoldChange"]
    d["rnaseh1_effect"] = np.clip(1 - rnaseh_bulk / 3, 0, 1)
    d["potential_sham"] = .25 * d.intrinsic + .30 * .5 + .25 * .5 + .20 * d.rnaseh1_effect
    d["potential_mcao"] = .25 * d.intrinsic + .30 * d.tx_norm + .25 * d.atac_norm + .20 * d.rnaseh1_effect
    d["potential_change"] = d.potential_mcao - d.potential_sham
    d = d.sort_values("potential_change", ascending=False, kind="stable").reset_index(drop=True)
    d["rank"] = np.arange(1, len(d) + 1)
    return d, excluded


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    d, excluded = build_proxy()
    d.to_csv(OUT / "rloop_formation_potential_complete_cases.csv", index=False)
    print(f"Complete-case proxy: {len(d)} genes; missing input(s): {', '.join(excluded)}")
    print(f"Positive change: {(d.potential_change > 0).sum()} genes")
    print(d[["gene", "potential_change", "rank"]].head(6).to_string(index=False))


if __name__ == "__main__":
    main()
