# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 15_atacseq_analysis.R
# snATAC-seq analysis using GeneScoreMatrix (gene activity)
# MCAO/R mouse cortex, 7 timepoints, 99271 nuclei
# ============================================================


suppressPackageStartupMessages({
  library(Seurat)
  library(tidyverse)
  library(Matrix)
})

options(Seurat.object.assay.version = "v3")

dir.create(file.path(RESULTS, "05_atacseq"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(RESULTS, "05_atacseq/figures"), recursive = TRUE, showWarnings = FALSE)

rloop_genes <- c(
  "Rnaseh1", "Rnaseh2a", "Rnaseh2b", "Rnaseh2c",
  "Top1", "Top1mt", "Setx", "Dhx9", "Ddx1", "Ddx3x", "Ddx5",
  "Ddx19", "Ddx21", "Aqr", "Pif1", "Fancm",
  "Brca1", "Brca2", "Fancd2", "Atr", "Atm", "Parp1",
  "Thoc1", "Thoc2", "Thoc3", "Thoc5", "Thoc6", "Thoc7",
  "Xrn2", "Prmt5", "Bcl7b", "Vdac1"
)

# ============================================================
# 1. Load data
# ============================================================
cat("========================================\n")
cat("  snATAC-seq analysis\n")
cat("========================================\n")

# Load metadata
cat("Loading metadata...\n")
meta <- read.csv("04_atacseq/raw/filter_atac_metadata.csv",
                 stringsAsFactors = FALSE, row.names = 1)
cat("Metadata:", nrow(meta), "nuclei\n")
cat("Timepoints:", paste(unique(meta$time), collapse = ", "), "\n")
cat("Cell types:", paste(unique(meta$predictedGroup), collapse = ", "), "\n")

# Load GeneScoreMatrix
cat("Loading GeneScoreMatrix...\n")
gsm <- readRDS("04_atacseq/raw/GeneScoreMatrix.rds")
cat("GeneScoreMatrix:", nrow(gsm), "genes x", ncol(gsm), "cells\n")

# Ensure cell names match
common_cells <- intersect(colnames(gsm), rownames(meta))
cat("Common cells:", length(common_cells), "\n")
gsm <- gsm[, common_cells]
meta <- meta[common_cells, ]

# ============================================================
# 2. Create Seurat object
# ============================================================
cat("\n--- Creating Seurat object ---\n")
gsm <- as(gsm, "dgCMatrix")
atac_obj <- CreateSeuratObject(counts = gsm, meta.data = meta,
                               assay = "ATAC", min.cells = 5)
cat("Cells:", ncol(atac_obj), "| Genes:", nrow(atac_obj), "\n")

# Normalize gene activity
atac_obj <- NormalizeData(atac_obj, normalization.method = "LogNormalize",
                          scale.factor = 10000, verbose = FALSE)
atac_obj <- FindVariableFeatures(atac_obj, nfeatures = 3000, verbose = FALSE)
atac_obj <- ScaleData(atac_obj, verbose = FALSE)
atac_obj <- RunPCA(atac_obj, verbose = FALSE)

# Use pre-computed cell type annotations
atac_obj$cell_type <- atac_obj$predictedGroup
atac_obj$timepoint <- atac_obj$time

cat("\nCell type distribution:\n")
print(table(atac_obj$cell_type))
cat("\nTimepoint distribution:\n")
print(table(atac_obj$timepoint))

# ============================================================
# 3. R-loop gene activity analysis
# ============================================================
cat("\n--- R-loop gene activity ---\n")

rloop_present <- intersect(rloop_genes, rownames(atac_obj))
cat("R-loop genes present:", length(rloop_present), "/", length(rloop_genes), "\n")
cat("  ", paste(rloop_present, collapse = ", "), "\n")

# Gene activity by cell type
rloop_activity_ct <- data.frame()
for (g in rloop_present) {
  expr_by_ct <- AggregateExpression(atac_obj, features = g, group.by = "cell_type")$ATAC
  rloop_activity_ct <- rbind(rloop_activity_ct, data.frame(
    gene = g,
    cell_type = colnames(expr_by_ct),
    activity = as.numeric(expr_by_ct[1, ]),
    stringsAsFactors = FALSE
  ))
}
write.csv(rloop_activity_ct, file.path(RESULTS, "05_atacseq/rloop_activity_by_celltype.csv"), row.names = FALSE)

# Gene activity by timepoint
rloop_activity_tp <- data.frame()
for (g in rloop_present) {
  expr_by_tp <- AggregateExpression(atac_obj, features = g, group.by = "timepoint")$ATAC
  rloop_activity_tp <- rbind(rloop_activity_tp, data.frame(
    gene = g,
    timepoint = colnames(expr_by_tp),
    activity = as.numeric(expr_by_tp[1, ]),
    stringsAsFactors = FALSE
  ))
}
write.csv(rloop_activity_tp, file.path(RESULTS, "05_atacseq/rloop_activity_by_timepoint.csv"), row.names = FALSE)

# ============================================================
# 4. Differential accessibility: MCAO vs Sham
# ============================================================
cat("\n--- Differential accessibility (MCAO vs Sham) ---\n")

# Compare each MCAO timepoint vs Sham
mcao_times <- c("M0h", "M6h", "M12h", "M24h", "M7d", "M14d")
sham_cells <- colnames(atac_obj)[atac_obj$timepoint == "Sham1d"]

rloop_de <- data.frame()

for (tp in mcao_times) {
  mcao_cells <- colnames(atac_obj)[atac_obj$timepoint == tp]
  if (length(mcao_cells) < 20 || length(sham_cells) < 20) next

  cat(sprintf("  %s vs Sham: %d vs %d cells\n", tp, length(mcao_cells), length(sham_cells)))

  for (g in rloop_present) {
    expr_mcao <- GetAssayData(atac_obj, layer = "data")[g, mcao_cells]
    expr_sham <- GetAssayData(atac_obj, layer = "data")[g, sham_cells]
    wilcox_p <- tryCatch(wilcox.test(expr_mcao, expr_sham)$p.value, error = function(e) NA)
    log2fc <- log2(mean(expm1(expr_mcao)) + 1) - log2(mean(expm1(expr_sham)) + 1)

    rloop_de <- rbind(rloop_de, data.frame(
      gene = g, comparison = paste0(tp, "_vs_Sham"),
      timepoint = tp,
      MCAO_mean = mean(expr_mcao), Sham_mean = mean(expr_sham),
      log2FC = log2fc, p_value = wilcox_p,
      stringsAsFactors = FALSE
    ))
  }
}

if (nrow(rloop_de) > 0) {
  rloop_de$p_adj <- p.adjust(rloop_de$p_value, method = "BH")
  rloop_de <- rloop_de[order(rloop_de$p_adj), ]
  write.csv(rloop_de, file.path(RESULTS, "05_atacseq/rloop_differential_accessibility.csv"), row.names = FALSE)

  cat("\nSignificant R-loop accessibility changes (p_adj<0.05):\n")
  sig <- rloop_de[rloop_de$p_adj < 0.05, ]
  if (nrow(sig) > 0) {
    print(sig[, c("gene", "comparison", "log2FC", "p_adj")])
  } else {
    cat("  None at p_adj<0.05\n")
    cat("  Top 15 by p-value:\n")
    print(head(rloop_de[, c("gene", "comparison", "log2FC", "p_adj")], 15))
  }
}

# ============================================================
# 5. Cell-type specific differential accessibility
# ============================================================
cat("\n--- Cell-type specific accessibility (M24h vs Sham) ---\n")

mcao_24h <- colnames(atac_obj)[atac_obj$timepoint == "M24h"]
rloop_de_ct <- data.frame()

for (ct in unique(atac_obj$cell_type)) {
  ct_mcao <- intersect(mcao_24h, colnames(atac_obj)[atac_obj$cell_type == ct])
  ct_sham <- intersect(sham_cells, colnames(atac_obj)[atac_obj$cell_type == ct])
  if (length(ct_mcao) < 10 || length(ct_sham) < 10) next

  for (g in rloop_present) {
    expr_mcao <- GetAssayData(atac_obj, layer = "data")[g, ct_mcao]
    expr_sham <- GetAssayData(atac_obj, layer = "data")[g, ct_sham]
    wilcox_p <- tryCatch(wilcox.test(expr_mcao, expr_sham)$p.value, error = function(e) NA)
    log2fc <- log2(mean(expm1(expr_mcao)) + 1) - log2(mean(expm1(expr_sham)) + 1)

    rloop_de_ct <- rbind(rloop_de_ct, data.frame(
      gene = g, cell_type = ct,
      log2FC = log2fc, p_value = wilcox_p,
      stringsAsFactors = FALSE
    ))
  }
}

if (nrow(rloop_de_ct) > 0) {
  rloop_de_ct$p_adj <- p.adjust(rloop_de_ct$p_value, method = "BH")
  rloop_de_ct <- rloop_de_ct[order(rloop_de_ct$p_adj), ]
  write.csv(rloop_de_ct, file.path(RESULTS, "05_atacseq/rloop_DE_by_celltype_M24h.csv"), row.names = FALSE)

  cat("\nCell-type specific changes (M24h vs Sham, top 15):\n")
  print(head(rloop_de_ct[, c("gene", "cell_type", "log2FC", "p_adj")], 15))
}

# ============================================================
# 6. Save plots
# ============================================================
cat("\n--- Saving plots ---\n")

# R-loop gene activity heatmap by timepoint
if (length(rloop_present) > 0) {
  p1 <- DotPlot(atac_obj, features = rloop_present, group.by = "timepoint") +
    RotatedAxis() + theme(axis.text.x = element_text(angle = 45, hjust = 1))
  ggsave(file.path(RESULTS, "05_atacseq/figures/rloop_activity_timepoint.png"), p1, width = 14, height = 8, dpi = 300)

  p2 <- DotPlot(atac_obj, features = rloop_present, group.by = "cell_type") +
    RotatedAxis() + theme(axis.text.x = element_text(angle = 45, hjust = 1))
  ggsave(file.path(RESULTS, "05_atacseq/figures/rloop_activity_celltype.png"), p2, width = 14, height = 8, dpi = 300)
}

# Save object
saveRDS(atac_obj, file.path(RESULTS, "05_atacseq/atac_seurat.rds"))

cat("\nsnATAC-seq analysis complete!\n")
cat("Total nuclei:", ncol(atac_obj), "\n")
cat("Cell types:", paste(unique(atac_obj$cell_type), collapse = ", "), "\n")
