"""Final HiChIP loop summary and mm10 TSS-window annotation.

Inputs are processed interaction BED files from GEO GSE319240. Loop changes are
descriptive contact-count ratios, without biological-replicate significance tests.
Gene TSS coordinates are the supplied mm10 annotation table; regeneration of that
coordinate table from an archived genome annotation was not available.
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
INPUT = ROOT / 'data/external/05_hichip/supplementary/GSE319240/extracted'
SNAP = ROOT / 'data/main_tables/09_hichip_contacts'
OUT = ROOT / 'outputs/pipeline/09_hichip'
OUT.mkdir(parents=True, exist_ok=True)
WIN = 50_000

def loop_id(x):
    c1,s1,e1,c2,s2,e2=x['chr1'],x['s1'],x['e1'],x['chr2'],x['s2'],x['e2']
    if c1==c2 and s1>s2:
        s1,e1,s2,e2=s2,e2,s1,e1
    return f'{c1}:{s1}-{e1}|{s2}-{e2}' if c1==c2 else f'{c1}:{s1}-{e1}|{c2}:{s2}-{e2}'

def load(label, name):
    df=pd.read_csv(INPUT/name,sep='\t')
    df['intra']=df.chr1==df.chr2
    df['loop_length']=np.where(df.intra,abs(df.s2-df.s1),np.nan)
    df['both_peaks']=(df.isPeak1==1)&(df.isPeak2==1)
    df['loop_id']=df.apply(loop_id,axis=1)
    return df

sham=load('Sham','GSM9514203_HiCHIP_Sham_H3K27ac_interactions.bed')
day6=load('Day6','GSM9514204_HiCHIP_Day6_H3K27ac_interactions.bed')
stats=[]
for label,df in [('Sham',sham),('Day6',day6)]:
    stats.append(dict(Sample=label,Total_loops=len(df),Intra_chromosomal=int(df.intra.sum()),
                      Inter_chromosomal=int((~df.intra).sum()),Mean_contact_count=df.cc.mean(),
                      Median_contact_count=df.cc.median(),Mean_loop_length_kb=df.loc[df.intra,'loop_length'].mean()/1000))
pd.DataFrame(stats).to_csv(OUT/'hichip_basic_stats.csv',index=False)

def high_conf(df):
    r=df[df.both_peaks&(df.cc>=5)].copy()
    assert r.loop_id.is_unique,'Duplicated loop IDs require explicit reconciliation.'
    return r.set_index('loop_id').cc

diff=pd.DataFrame({'Sham_cc':high_conf(sham),'Day6_cc':high_conf(day6)}).dropna()
diff.index.name='loop_id'
diff['log2FC']=np.log2(diff.Day6_cc/diff.Sham_cc)
diff['Day6_up']=diff.log2FC>1
diff['Day6_down']=diff.log2FC<-1
diff.to_csv(OUT/'differential_loops.csv')

coords=pd.read_csv(SNAP/'mm10_rloop_gene_coords.csv')
sham_ids=set(sham.loop_id);day6_ids=set(day6.loop_id)
rows=[]
for _,g in coords.iterrows():
    if pd.isna(g.tss): continue
    def near(df):
        same=df[df.chr1==g['chr']]
        lo,hi=g.tss-WIN,g.tss+WIN
        return same[((same.s1<=hi)&(same.e1>=lo))|((same.s2<=hi)&(same.e2>=lo))]
    ns,nd=near(sham),near(day6)
    lids=set(ns.loop_id)|set(nd.loop_id)
    common=lids&sham_ids&day6_ids
    matched=diff.loc[sorted(common&set(diff.index))]
    rows.append(dict(gene=g.gene,n_sham=len(ns),n_day6=len(nd),common=len(common),
                     up=int(matched.Day6_up.sum()),down=int(matched.Day6_down.sum()),
                     stable=int((~matched.Day6_up&~matched.Day6_down).sum()),
                     sham_specific=len(lids&sham_ids-day6_ids),day6_specific=len(lids&day6_ids-sham_ids)))
ann=pd.DataFrame(rows).sort_values(['up','down','n_day6'],ascending=False)
ann.to_csv(OUT/'hichip_rloop_gene_loop_annotation.csv',index=False)
print(f'{len(sham)} Sham loops; {len(day6)} Day6 loops; {len(diff)} common high-confidence loops')
print(ann.to_string(index=False))
