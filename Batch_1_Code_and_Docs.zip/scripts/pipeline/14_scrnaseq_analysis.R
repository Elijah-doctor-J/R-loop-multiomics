# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 14_scrnaseq_analysis.R
# Single-cell RNA-seq analysis (Seurat)
# GSE174574: mouse MCAO acute phase, 3 Sham + 3 MCAO, 10X
# ============================================================


suppressPackageStartupMessages({
  library(Seurat)
  library(tidyverse)
  library(patchwork)
  library(Matrix)
  library(harmony)
})

dir.create(file.path(RESULTS, "04_scrnaseq"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(RESULTS, "04_scrnaseq/figures"), recursive = TRUE, showWarnings = FALSE)

# Mouse R-loop genes
rloop_genes <- c(
  "Rnaseh1", "Rnaseh2a", "Rnaseh2b", "Rnaseh2c",
  "Top1", "Top1mt", "Setx", "Dhx9", "Ddx1", "Ddx3x", "Ddx5",
  "Ddx19", "Ddx21", "Aqr", "Pif1", "Fancm",
  "Brca1", "Brca2", "Fancd2", "Atr", "Atm", "Parp1",
  "Thoc1", "Thoc2", "Thoc3", "Thoc5", "Thoc6", "Thoc7",
  "Xrn2", "Prmt5", "Bcl7b", "Vdac1"
)

# ============================================================
# 1. Read 10X data
# ============================================================
cat("========================================\n")
cat("  GSE174574 scRNA-seq analysis\n")
cat("========================================\n")

extract_dir <- "03_scrnaseq/supplementary/GSE174574/extracted"
sample_names <- c("sham1", "sham2", "sham3", "MCAO1", "MCAO2", "MCAO3")
sample_groups <- c(rep("Sham", 3), rep("MCAO", 3))

seurat_list <- list()

for (i in seq_along(sample_names)) {
  sname <- sample_names[i]
  group <- sample_groups[i]
  cat(sprintf("\nProcessing %s (%s)...\n", sname, group))

  barcode_file <- list.files(extract_dir, pattern = paste0(sname, ".*barcodes"), full.names = TRUE)
  features_file <- list.files(extract_dir, pattern = paste0(sname, ".*genes"), full.names = TRUE)
  matrix_file <- list.files(extract_dir, pattern = paste0(sname, ".*matrix"), full.names = TRUE)

  if (length(barcode_file) == 0 || length(features_file) == 0 || length(matrix_file) == 0) {
    cat("  Incomplete files, skipping\n")
    next
  }

  counts <- ReadMtx(mtx = matrix_file,
                    features = features_file,
                    cells = barcode_file,
                    feature.column = 2)

  obj <- CreateSeuratObject(counts = counts, project = sname,
                            min.cells = 3, min.features = 200)
  obj$group <- group
  obj$sample <- sname

  # QC
  obj[["percent.mt"]] <- PercentageFeatureSet(obj, pattern = "^mt-")
  obj <- subset(obj, subset = nFeature_RNA > 200 & nFeature_RNA < 6000 &
                 nCount_RNA > 500 & percent.mt < 20)

  cat(sprintf("  Cells after QC: %d\n", ncol(obj)))
  seurat_list[[sname]] <- obj
}

# ============================================================
# 2. Integration
# ============================================================
cat("\n--- Integration ---\n")

# Normalize each sample
for (i in seq_along(seurat_list)) {
  seurat_list[[i]] <- SCTransform(seurat_list[[i]], verbose = FALSE)
}

# Select integration features
features <- SelectIntegrationFeatures(object.list = seurat_list, nfeatures = 3000)

# Find integration anchors
anchors <- FindIntegrationAnchors(object.list = seurat_list,
                                  normalization.method = "SCT",
                                  anchor.features = features,
                                  verbose = FALSE)

# Integrate
combined <- IntegrateData(anchors, normalization.method = "SCT", verbose = FALSE)
cat("Integrated:", ncol(combined), "cells\n")

# ============================================================
# 3. Dimensionality reduction and clustering
# ============================================================
cat("\n--- Dimensionality reduction ---\n")

combined <- RunPCA(combined, verbose = FALSE)
combined <- RunHarmony(combined, group.by.vars = "sample", verbose = FALSE)
combined <- RunUMAP(combined, reduction = "harmony", dims = 1:30, verbose = FALSE)
combined <- FindNeighbors(combined, reduction = "harmony", dims = 1:30, verbose = FALSE)
combined <- FindClusters(combined, resolution = 0.8, verbose = FALSE)

cat("Clusters:", length(levels(Idents(combined))), "\n")
print(table(Idents(combined), combined$group))

# ============================================================
# 4. Cell type annotation
# ============================================================
cat("\n--- Cell type annotation ---\n")

# Canonical markers for mouse brain cell types
markers <- FindAllMarkers(combined, only.pos = TRUE, min.pct = 0.25,
                          logfc.threshold = 0.5, verbose = FALSE)
write.csv(markers, file.path(RESULTS, "04_scrnaseq/GSE174574_cluster_markers.csv"), row.names = FALSE)

# Known cell type markers
cell_type_markers <- list(
  Neurons = c("Snap25", "Syp", "Rbfox3", "Map2"),
  Astrocytes = c("Gfap", "Aqp4", "Slc1a3", "Aldh1l1"),
  Microglia = c("Cx3cr1", "P2ry12", "Tmem119", "Iba1"),
  Oligodendrocytes = c("Mbp", "Plp1", "Mog", "Olig1"),
  OPCs = c("Pdgfra", "Cspg4", "Olig2"),
  Endothelial = c("Cldn5", "Pecam1", "Flt1", "Kdr"),
  Pericytes = c("Pdgfrb", "Rgs5", "Kcnj8"),
  Ependymal = c("Ttr", "Foxj1"),
  Neutrophils = c("S100a8", "S100a9", "Mmp9"),
  T_cells = c("Cd3d", "Cd3e", "Cd8a"),
  B_cells = c("Cd79a", "Ms4a1", "Cd79b"),
  Macrophages = c("Mrc1", "Cd163", "Mgl2")
)

# Score each cell type
for (ct in names(cell_type_markers)) {
  genes_present <- intersect(cell_type_markers[[ct]], rownames(combined))
  if (length(genes_present) >= 2) {
    combined <- AddModuleScore(combined, features = list(genes_present),
                               name = paste0("score_", ct))
  }
}

# Assign cell type based on highest score
score_cols <- grep("^score_", colnames(combined@meta.data), value = TRUE)
if (length(score_cols) > 0) {
  score_mat <- combined@meta.data[, score_cols, drop = FALSE]
  colnames(score_mat) <- gsub("score_", "", colnames(score_mat))
  colnames(score_mat) <- gsub("1$", "", colnames(score_mat))
  combined$cell_type <- colnames(score_mat)[apply(score_mat, 1, which.max)]
} else {
  combined$cell_type <- as.character(Idents(combined))
}

cat("\nCell type distribution:\n")
print(table(combined$cell_type, combined$group))

# ============================================================
# 5. R-loop gene expression analysis
# ============================================================
cat("\n--- R-loop gene expression ---\n")

rloop_present <- intersect(rloop_genes, rownames(combined))
cat("R-loop genes present:", length(rloop_present), "/", length(rloop_genes), "\n")
cat("  ", paste(rloop_present, collapse = ", "), "\n")

# R-loop genes by cell type
rloop_expr <- data.frame()
for (g in rloop_present) {
  expr_by_ct <- AggregateExpression(combined, features = g, group.by = "cell_type")$SCT
  expr_by_group <- AggregateExpression(combined, features = g, group.by = c("cell_type", "group"))$SCT
  rloop_expr <- rbind(rloop_expr, data.frame(
    gene = g,
    cell_type = colnames(expr_by_ct),
    expression = as.numeric(expr_by_ct[1, ]),
    stringsAsFactors = FALSE
  ))
}
write.csv(rloop_expr, file.path(RESULTS, "04_scrnaseq/GSE174574_rloop_expression_by_celltype.csv"), row.names = FALSE)

# R-loop genes by group (MCAO vs Sham) in each cell type
rloop_de <- data.frame()
Idents(combined) <- "cell_type"
for (ct in unique(combined$cell_type)) {
  cells_mcao <- colnames(combined)[combined$cell_type == ct & combined$group == "MCAO"]
  cells_sham <- colnames(combined)[combined$cell_type == ct & combined$group == "Sham"]

  if (length(cells_mcao) < 10 || length(cells_sham) < 10) next

  for (g in rloop_present) {
    expr_mcao <- GetAssayData(combined, layer = "data")[g, cells_mcao]
    expr_sham <- GetAssayData(combined, layer = "data")[g, cells_sham]
    wilcox_p <- tryCatch(wilcox.test(expr_mcao, expr_sham)$p.value, error = function(e) NA)
    log2fc <- log2(mean(expm1(expr_mcao)) + 1) - log2(mean(expm1(expr_sham)) + 1)

    rloop_de <- rbind(rloop_de, data.frame(
      gene = g,
      cell_type = ct,
      MCAO_mean = mean(expr_mcao),
      Sham_mean = mean(expr_sham),
      log2FC = log2fc,
      p_value = wilcox_p,
      stringsAsFactors = FALSE
    ))
  }
}

if (nrow(rloop_de) > 0) {
  rloop_de$p_adj <- p.adjust(rloop_de$p_value, method = "BH")
  rloop_de <- rloop_de[order(rloop_de$p_adj), ]
  write.csv(rloop_de, file.path(RESULTS, "04_scrnaseq/GSE174574_rloop_DE_by_celltype.csv"), row.names = FALSE)

  cat("\nSignificant R-loop gene changes (p_adj < 0.05):\n")
  sig <- rloop_de[rloop_de$p_adj < 0.05, ]
  if (nrow(sig) > 0) {
    print(sig[, c("gene", "cell_type", "log2FC", "p_adj")])
  } else {
    cat("  None at p_adj < 0.05\n")
    cat("  Top 10 by p-value:\n")
    print(head(rloop_de[, c("gene", "cell_type", "log2FC", "p_adj")], 10))
  }
}

# ============================================================
# 6. Save results
# ============================================================
cat("\n--- Saving ---\n")

# UMAP plot
p1 <- DimPlot(combined, group.by = "cell_type", label = TRUE, repel = TRUE) +
  ggtitle("Cell types") + theme(legend.position = "none")
p2 <- DimPlot(combined, group.by = "group") + ggtitle("Group")
ggsave(file.path(RESULTS, "04_scrnaseq/figures/GSE174574_umap.png"), p1 + p2, width = 14, height = 6, dpi = 300)

# R-loop gene dot plot
if (length(rloop_present) > 0) {
  p3 <- DotPlot(combined, features = rloop_present, group.by = "cell_type") +
    RotatedAxis() + theme(axis.text.x = element_text(angle = 45, hjust = 1))
  ggsave(file.path(RESULTS, "04_scrnaseq/figures/GSE174574_rloop_dotplot.png"), p3, width = 14, height = 8, dpi = 300)
}

# Save Seurat object
saveRDS(combined, file.path(RESULTS, "04_scrnaseq/GSE174574_seurat.rds"))

cat("\n\nscRNA-seq analysis complete!\n")
cat("Total cells:", ncol(combined), "\n")
cat("Cell types:", paste(unique(combined$cell_type), collapse = ", "), "\n")
