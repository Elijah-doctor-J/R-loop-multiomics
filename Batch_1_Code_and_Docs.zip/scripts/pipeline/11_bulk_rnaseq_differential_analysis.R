# R <4.2 on Windows needs a native Chinese code page for non-ASCII paths.
if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
# Portable project layout. Run with Rscript /path/to/this_script.R.
.file_arg <- grep("^--file=", commandArgs(trailingOnly=FALSE), value=TRUE)
if (!length(.file_arg)) stop("Run this script with Rscript so its project root can be located.")
PROJECT_ROOT <- normalizePath(file.path(dirname(sub("^--file=", "", .file_arg[1])), "../.."), winslash="/", mustWork=TRUE)
EXTERNAL <- file.path(PROJECT_ROOT, "data", "external")
RESULTS <- file.path(PROJECT_ROOT, "outputs", "pipeline")
dir.create(EXTERNAL, recursive=TRUE, showWarnings=FALSE)
dir.create(RESULTS, recursive=TRUE, showWarnings=FALSE)
setwd(EXTERNAL)

# ============================================================
# 11_bulk_rnaseq_differential_analysis.R
# Bulk RNA-seq 差异表达分析
# 数据集: GSE163614 (大鼠MCAO/R RNA-seq, 发现集)
#         GSE137482 (小鼠MCAO RNA-seq, 验证集)
#         GSE61616  (大鼠MCAO微阵列, 验证集)
# ============================================================


suppressPackageStartupMessages({
  library(DESeq2)
  library(edgeR)
  library(limma)
  library(Biobase)
  library(tidyverse)
  library(pheatmap)
  library(EnhancedVolcano)
  library(org.Rn.eg.db)
  library(org.Mm.eg.db)
  library(clusterProfiler)
})

dir.create(file.path(RESULTS, "01_bulk_DEG"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(RESULTS, "01_bulk_DEG/figures"), recursive = TRUE, showWarnings = FALSE)

# ============================================================
# R-loop调控基因集（约30个核心基因）
# ============================================================
rloop_genes_human <- c(
  # 核酸酶
  "RNASEH1", "RNASEH2A", "RNASEH2B", "RNASEH2C",
  # 拓扑异构酶
  "TOP1", "TOP1MT",
  # 解旋酶
  "SETX", "DHX9", "DDX1", "DDX3X", "DDX5", "DDX19", "DDX21",
  "AQR", "PIF1", "FANCM",
  # DNA修复
  "BRCA1", "BRCA2", "FANCD2", "ATR", "ATM", "PARP1",
  # RNA加工
  "THOC1", "THOC2", "THOC3", "THOC5", "THOC6", "THOC7",
  "XRN2", "PRMT5",
  # 核心关注分子
  "BCL7B", "VDAC1"
)

# 大鼠/小鼠基因符号（首字母大写，其余小写）
rloop_genes_rat <- paste0(toupper(substr(rloop_genes_human, 1, 1)),
                          tolower(substr(rloop_genes_human, 2, nchar(rloop_genes_human))))
# 小鼠基因符号（同大鼠格式）
rloop_genes_mouse <- rloop_genes_rat

cat("R-loop调控基因集:", length(rloop_genes_human), "个基因\n\n")

# ============================================================
# 1. GSE163614: 大鼠MCAO/R RNA-seq (DESeq2)
# ============================================================
cat("========================================\n")
cat("  1. GSE163614 差异分析 (DESeq2)\n")
cat("========================================\n")

# 读取count矩阵
counts_163 <- readRDS("01_bulk_rnaseq/processed/GSE163614_counts_matrix.rds")
cat("Count矩阵:", nrow(counts_163), "genes x", ncol(counts_163), "samples\n")

# 构建样本信息
sample_info_163 <- data.frame(
  sample = colnames(counts_163),
  group = ifelse(grepl("MCAO", colnames(counts_163)), "MCAO", "Sham"),
  row.names = colnames(counts_163)
)
sample_info_163$group <- factor(sample_info_163$group, levels = c("Sham", "MCAO"))
print(sample_info_163)

# 基因ID转换：Ensembl ID -> Gene Symbol
# 大鼠Ensembl ID: ENSRNOG...
gene_ids_163 <- rownames(counts_163)
gene_map_163 <- bitr(gene_ids_163,
                     fromType = "ENSEMBL",
                     toType = c("SYMBOL", "ENTREZID"),
                     OrgDb = org.Rn.eg.db)
cat("基因ID转换:", nrow(gene_map_163), "/", length(gene_ids_163), "个基因有注释\n")

# 去除重复的Ensembl ID（保留第一个匹配的Symbol）
gene_map_163 <- gene_map_163[!duplicated(gene_map_163$ENSEMBL), ]
rownames(gene_map_163) <- gene_map_163$ENSEMBL

# 只保留有注释的基因
common_genes <- intersect(rownames(counts_163), gene_map_163$ENSEMBL)
counts_163_annot <- counts_163[common_genes, ]
gene_symbols_163 <- gene_map_163[common_genes, "SYMBOL"]
# 去除Symbol重复（同一Symbol可能对应多个Ensembl ID，取表达量最高的）
counts_163_df <- as.data.frame(counts_163_annot)
counts_163_df$symbol <- gene_symbols_163
counts_163_df <- counts_163_df[!is.na(counts_163_df$symbol) & counts_163_df$symbol != "", ]
# 按symbol分组，取每行总和最大的
counts_163_df$row_sum <- rowSums(counts_163_df[, 1:6])
counts_163_df <- counts_163_df[order(-counts_163_df$row_sum), ]
counts_163_df <- counts_163_df[!duplicated(counts_163_df$symbol), ]
rownames(counts_163_df) <- counts_163_df$symbol
counts_163_final <- as.matrix(counts_163_df[, 1:6])
mode(counts_163_final) <- "integer"
cat("注释后矩阵:", nrow(counts_163_final), "genes x", ncol(counts_163_final), "samples\n")

# DESeq2分析
dds_163 <- DESeqDataSetFromMatrix(
  countData = counts_163_final,
  colData = sample_info_163,
  design = ~ group
)

# 过滤低表达基因（至少在3个样本中count > 10）
dds_163 <- dds_163[rowSums(counts(dds_163) >= 10) >= 3, ]
cat("过滤后:", nrow(dds_163), "genes\n")

dds_163 <- DESeq(dds_163)
res_163 <- results(dds_163, contrast = c("group", "MCAO", "Sham"),
                   alpha = 0.05, lfcThreshold = log2(1.5),
                   independentFiltering = TRUE)
res_163_df <- as.data.frame(res_163)
res_163_df$gene <- rownames(res_163_df)
res_163_df <- res_163_df[order(res_163_df$padj), ]

# 差异基因统计
deg_163_up <- sum(res_163_df$padj < 0.05 & res_163_df$log2FoldChange > 0, na.rm = TRUE)
deg_163_down <- sum(res_163_df$padj < 0.05 & res_163_df$log2FoldChange < 0, na.rm = TRUE)
cat(sprintf("\nGSE163614差异基因: %d上调, %d下调 (|log2FC|>0.585, padj<0.05)\n",
            deg_163_up, deg_163_down))

# R-loop基因在GSE163614中的表达变化
rloop_in_163 <- res_163_df[res_163_df$gene %in% rloop_genes_rat, ]
cat("\nR-loop基因在GSE163614中的变化:\n")
print(rloop_in_163[, c("gene", "log2FoldChange", "padj")])

# 保存结果
write.csv(res_163_df, file.path(RESULTS, "01_bulk_DEG/GSE163614_DESeq2_results.csv"), row.names = FALSE)
write.csv(rloop_in_163, file.path(RESULTS, "01_bulk_DEG/GSE163614_rloop_genes.csv"), row.names = FALSE)
saveRDS(dds_163, file.path(RESULTS, "01_bulk_DEG/GSE163614_dds.rds"))
saveRDS(res_163_df, file.path(RESULTS, "01_bulk_DEG/GSE163614_res.rds"))

# 火山图
png(file.path(RESULTS, "01_bulk_DEG/figures/GSE163614_volcano.png"), width = 2400, height = 2000, res = 300)
EnhancedVolcano(res_163_df,
                lab = res_163_df$gene,
                x = "log2FoldChange", y = "padj",
                selectLab = c(head(res_163_df$gene[res_163_df$padj < 0.05], 10),
                             intersect(rloop_genes_rat, res_163_df$gene)),
                pCutoff = 0.05, FCcutoff = log2(1.5),
                title = "GSE163614: MCAO/R vs Sham (Rat)",
                subtitle = NULL,
                labSize = 3, pointSize = 1.5,
                colAlpha = 0.6,
                legendPosition = "right")
dev.off()
cat("火山图已保存\n")

# ============================================================
# 2. GSE137482: 小鼠MCAO RNA-seq (DESeq2)
# ============================================================
cat("\n\n========================================\n")
cat("  2. GSE137482 差异分析 (DESeq2)\n")
cat("========================================\n")

# 读取count矩阵
counts_137 <- readRDS("01_bulk_rnaseq/processed/GSE137482_counts_matrix.rds")
cat("Count矩阵:", nrow(counts_137), "genes x", ncol(counts_137), "samples\n")

# Ctrl denotes age-matched intact controls in the permanent-MCAO source study.
# 构建样本信息
colnames(counts_137) <- gsub("GSM\\d+_", "", colnames(counts_137))
sample_info_137 <- data.frame(
  sample = colnames(counts_137),
  age = factor(ifelse(grepl("3M", colnames(counts_137)), "3M", "18M")),
  group = factor(ifelse(grepl("MCAO", colnames(counts_137)), "MCAO", "Ctrl"),
                 levels = c("Ctrl", "MCAO")),
  row.names = colnames(counts_137)
)
print(sample_info_137)

# 基因ID转换：小鼠Ensembl ID（带版本号）-> Gene Symbol
gene_ids_137_raw <- rownames(counts_137)
gene_ids_137 <- sub("\\..*", "", gene_ids_137_raw)  # 去除版本号
gene_map_137 <- bitr(gene_ids_137,
                     fromType = "ENSEMBL",
                     toType = c("SYMBOL", "ENTREZID"),
                     OrgDb = org.Mm.eg.db)
cat("基因ID转换:", nrow(gene_map_137), "/", length(gene_ids_137), "个基因有注释\n")

gene_map_137 <- gene_map_137[!duplicated(gene_map_137$ENSEMBL), ]
rownames(gene_map_137) <- gene_map_137$ENSEMBL

common_genes_137 <- intersect(gene_ids_137, gene_map_137$ENSEMBL)
counts_137_annot <- counts_137[match(common_genes_137, gene_ids_137), ]
gene_symbols_137 <- gene_map_137[common_genes_137, "SYMBOL"]

counts_137_df <- as.data.frame(counts_137_annot)
counts_137_df$symbol <- gene_symbols_137
counts_137_df <- counts_137_df[!is.na(counts_137_df$symbol) & counts_137_df$symbol != "", ]
counts_137_df$row_sum <- rowSums(counts_137_df[, 1:24])
counts_137_df <- counts_137_df[order(-counts_137_df$row_sum), ]
counts_137_df <- counts_137_df[!duplicated(counts_137_df$symbol), ]
rownames(counts_137_df) <- counts_137_df$symbol
counts_137_final <- as.matrix(counts_137_df[, 1:24])
mode(counts_137_final) <- "integer"
cat("注释后矩阵:", nrow(counts_137_final), "genes x", ncol(counts_137_final), "samples\n")

# DESeq2分析（双因素设计：age + group）
dds_137 <- DESeqDataSetFromMatrix(
  countData = counts_137_final,
  colData = sample_info_137,
  design = ~ age + group
)
dds_137 <- dds_137[rowSums(counts(dds_137) >= 10) >= 6, ]
cat("过滤后:", nrow(dds_137), "genes\n")

dds_137 <- DESeq(dds_137)
res_137 <- results(dds_137, contrast = c("group", "MCAO", "Ctrl"),
                   alpha = 0.05, lfcThreshold = log2(1.5))
res_137_df <- as.data.frame(res_137)
res_137_df$gene <- rownames(res_137_df)
res_137_df <- res_137_df[order(res_137_df$padj), ]

deg_137_up <- sum(res_137_df$padj < 0.05 & res_137_df$log2FoldChange > 0, na.rm = TRUE)
deg_137_down <- sum(res_137_df$padj < 0.05 & res_137_df$log2FoldChange < 0, na.rm = TRUE)
cat(sprintf("\nGSE137482差异基因: %d上调, %d下调\n", deg_137_up, deg_137_down))

# R-loop基因
rloop_in_137 <- res_137_df[res_137_df$gene %in% rloop_genes_mouse, ]
cat("\nR-loop基因在GSE137482中的变化:\n")
print(rloop_in_137[, c("gene", "log2FoldChange", "padj")])

write.csv(res_137_df, file.path(RESULTS, "01_bulk_DEG/GSE137482_DESeq2_results.csv"), row.names = FALSE)
write.csv(rloop_in_137, file.path(RESULTS, "01_bulk_DEG/GSE137482_rloop_genes.csv"), row.names = FALSE)
saveRDS(dds_137, file.path(RESULTS, "01_bulk_DEG/GSE137482_dds.rds"))
saveRDS(res_137_df, file.path(RESULTS, "01_bulk_DEG/GSE137482_res.rds"))

# 火山图
png(file.path(RESULTS, "01_bulk_DEG/figures/GSE137482_volcano.png"), width = 2400, height = 2000, res = 300)
EnhancedVolcano(res_137_df,
                lab = res_137_df$gene,
                x = "log2FoldChange", y = "padj",
                selectLab = c(head(res_137_df$gene[res_137_df$padj < 0.05], 10),
                             intersect(rloop_genes_mouse, res_137_df$gene)),
                pCutoff = 0.05, FCcutoff = log2(1.5),
                title = "GSE137482: permanent MCAO vs intact control (Mouse)",
                subtitle = NULL,
                labSize = 3, pointSize = 1.5, colAlpha = 0.6)
dev.off()
cat("火山图已保存\n")

# ============================================================
# 3. GSE61616: 大鼠MCAO微阵列 (limma)
# ============================================================
cat("\n\n========================================\n")
cat("  3. GSE61616 差异分析 (limma)\n")
cat("========================================\n")

eset_616 <- readRDS("01_bulk_rnaseq/processed/GSE61616_eset.rds")
expr_616 <- exprs(eset_616)
pdata_616 <- pData(eset_616)
cat("表达矩阵:", nrow(expr_616), "probes x", ncol(expr_616), "samples\n")

# 样本分组
pdata_616$group <- ifelse(grepl("Sham", pdata_616$title), "Sham",
                   ifelse(grepl("Model", pdata_616$title), "Model", "XST"))
cat("分组:\n")
print(table(pdata_616$group))

# 只取Sham和Model
keep_samples <- pdata_616$group %in% c("Sham", "Model")
expr_616_sub <- expr_616[, keep_samples]
group_616 <- factor(pdata_616$group[keep_samples], levels = c("Sham", "Model"))

# 探针ID转换：Affymetrix Rat 230 2.0 -> Gene Symbol
# GPL1355注释
gpl_616 <- read.delim(gzfile("01_bulk_rnaseq/raw/GPL1355.annot.gz"),
                      skip = 27, stringsAsFactors = FALSE,
                      check.names = FALSE, quote = "", sep = "\t")
# 找到ID和Symbol列
id_col <- grep("^ID$", colnames(gpl_616), value = TRUE)
symbol_col <- grep("Gene [Ss]ymbol", colnames(gpl_616), value = TRUE)
if (length(symbol_col) == 0) symbol_col <- grep("[Ss]ymbol", colnames(gpl_616), value = TRUE)[1]
cat("注释列:", id_col, "/", symbol_col, "\n")

probe_map_616 <- gpl_616[, c(id_col[1], symbol_col[1])]
colnames(probe_map_616) <- c("probe_id", "symbol")
# 处理多对一：一个探针对应多个symbol（取第一个）
probe_map_616$symbol <- sapply(strsplit(as.character(probe_map_616$symbol), " /// "),
                                function(x) x[1])
probe_map_616 <- probe_map_616[probe_map_616$symbol != "" & !is.na(probe_map_616$symbol), ]
probe_map_616 <- probe_map_616[!duplicated(probe_map_616$probe_id), ]

# 注释表达矩阵
common_probes <- intersect(rownames(expr_616_sub), probe_map_616$probe_id)
expr_616_annot <- expr_616_sub[common_probes, ]
symbols_616 <- probe_map_616$symbol[match(common_probes, probe_map_616$probe_id)]

# 多探针取均值
expr_616_df <- as.data.frame(expr_616_annot)
expr_616_df$symbol <- symbols_616
expr_616_collapsed <- expr_616_df %>%
  group_by(symbol) %>%
  summarise(across(everything(), mean)) %>%
  column_to_rownames("symbol")
cat("注释后矩阵:", nrow(expr_616_collapsed), "genes x", ncol(expr_616_collapsed), "samples\n")

# limma差异分析
design_616 <- model.matrix(~ group_616)
fit_616 <- lmFit(as.matrix(expr_616_collapsed), design_616)
fit_616 <- eBayes(fit_616)
res_616 <- topTable(fit_616, coef = 2, number = Inf, adjust.method = "BH")
res_616$gene <- rownames(res_616)

deg_616_up <- sum(res_616$adj.P.Val < 0.05 & res_616$logFC > log2(1.5), na.rm = TRUE)
deg_616_down <- sum(res_616$adj.P.Val < 0.05 & res_616$logFC < -log2(1.5), na.rm = TRUE)
cat(sprintf("\nGSE61616差异基因: %d上调, %d下调\n", deg_616_up, deg_616_down))

# R-loop基因
rloop_in_616 <- res_616[res_616$gene %in% rloop_genes_rat, ]
cat("\nR-loop基因在GSE61616中的变化:\n")
print(rloop_in_616[, c("gene", "logFC", "adj.P.Val")])

write.csv(res_616, file.path(RESULTS, "01_bulk_DEG/GSE61616_limma_results.csv"), row.names = FALSE)
write.csv(rloop_in_616, file.path(RESULTS, "01_bulk_DEG/GSE61616_rloop_genes.csv"), row.names = FALSE)
saveRDS(res_616, file.path(RESULTS, "01_bulk_DEG/GSE61616_res.rds"))

# ============================================================
# 4. 跨数据集R-loop基因一致性分析
# ============================================================
cat("\n\n========================================\n")
cat("  4. 跨数据集R-loop基因一致性\n")
cat("========================================\n")

# 合并三个数据集的R-loop基因结果
# 注意：大鼠/小鼠基因名首字母大写（Rnaseh1），人类全大写（RNASEH1）
# 这里用大鼠/小鼠格式匹配
rloop_summary <- data.frame(
  gene = rloop_genes_rat,
  gene_human = rloop_genes_human,
  GSE163614_log2FC = NA, GSE163614_padj = NA,
  GSE137482_log2FC = NA, GSE137482_padj = NA,
  GSE61616_log2FC = NA, GSE61616_padj = NA
)

for (i in 1:nrow(rloop_summary)) {
  g <- rloop_summary$gene[i]
  if (g %in% res_163_df$gene) {
    rloop_summary[i, c("GSE163614_log2FC", "GSE163614_padj")] <-
      res_163_df[res_163_df$gene == g, c("log2FoldChange", "padj")]
  }
  if (g %in% res_137_df$gene) {
    rloop_summary[i, c("GSE137482_log2FC", "GSE137482_padj")] <-
      res_137_df[res_137_df$gene == g, c("log2FoldChange", "padj")]
  }
  if (g %in% res_616$gene) {
    rloop_summary[i, c("GSE61616_log2FC", "GSE61616_padj")] <-
      res_616[res_616$gene == g, c("logFC", "adj.P.Val")]
  }
}

# 方向一致性
rloop_summary$direction_consistent <- apply(rloop_summary[, c("GSE163614_log2FC", "GSE137482_log2FC", "GSE61616_log2FC")], 1, function(x) {
  x <- x[!is.na(x)]
  if (length(x) < 2) return(NA)
  all(x > 0) || all(x < 0)
})

cat("\nR-loop基因跨数据集汇总:\n")
print(rloop_summary, row.names = FALSE)

write.csv(rloop_summary, file.path(RESULTS, "01_bulk_DEG/rloop_genes_cross_dataset.csv"), row.names = FALSE)

# 核心分子（大鼠/小鼠格式）
cat("\n\n核心分子表达变化:\n")
core_genes <- c("Rnaseh1", "Bcl7b", "Vdac1")
for (g in core_genes) {
  cat(sprintf("\n%s:\n", g))
  if (g %in% res_163_df$gene) {
    r <- res_163_df[res_163_df$gene == g, ]
    cat(sprintf("  GSE163614(大鼠): log2FC=%.3f, padj=%.4f %s\n",
                r$log2FoldChange, r$padj,
                ifelse(r$padj < 0.05, "*", "")))
  }
  if (g %in% res_137_df$gene) {
    r <- res_137_df[res_137_df$gene == g, ]
    cat(sprintf("  GSE137482(小鼠): log2FC=%.3f, padj=%.4f %s\n",
                r$log2FoldChange, r$padj,
                ifelse(r$padj < 0.05, "*", "")))
  }
  if (g %in% res_616$gene) {
    r <- res_616[res_616$gene == g, ]
    cat(sprintf("  GSE61616(大鼠):  log2FC=%.3f, padj=%.4f %s\n",
                r$logFC, r$adj.P.Val,
                ifelse(r$adj.P.Val < 0.05, "*", "")))
  }
}

cat("\n\nBulk RNA-seq差异分析完成！\n")
cat("结果保存在 results/01_bulk_DEG/\n")
