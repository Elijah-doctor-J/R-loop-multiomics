# Export final per-cell-mean ATAC activity and Figure 7 embedding/composition.
# Input checkpoint is large and must be regenerated/downloaded separately.
args_all <- commandArgs(trailingOnly=FALSE)
script <- sub('^--file=', '', args_all[grep('^--file=',args_all)][1])
root <- normalizePath(file.path(dirname(script),'../..'),mustWork=TRUE)
out <- file.path(root,'outputs/source_exports/atac')
dir.create(out,recursive=TRUE,showWarnings=FALSE)
input <- file.path(root,'data/external/checkpoints/atac_seurat.rds')
if (!file.exists(input)) stop('Missing data/external/checkpoints/atac_seurat.rds; see README')
suppressPackageStartupMessages({library(Seurat);library(Matrix)})
atac <- readRDS(input)
tp <- atac$timepoint; ct <- atac$cell_type
counts <- GetAssayData(atac,layer='counts'); dat <- GetAssayData(atac,layer='data')
genes <- c('Rnaseh1','Rnaseh2a','Rnaseh2b','Rnaseh2c','Setx','Top1','Top1mt','Pif1',
 'Ddx1','Ddx3x','Ddx5','Ddx21','Dhx9','Aqr','Atm','Atr','Brca1','Brca2','Parp1','Fancd2','Fancm',
 'Thoc1','Thoc2','Thoc3','Thoc5','Thoc6','Thoc7','Xrn2','Prmt5','Bcl7b','Vdac1')
genes <- intersect(genes,rownames(counts))
tps <- c('Sham1d','M0h','M6h','M12h','M24h','M7d','M14d')
cts <- c('Ex_Neurons','In_Neurons','Astrocytes','Olig.','Microglia','OPC','Endothelial','Fibroblast')
export_means <- function(labels, values, key, filename) {
 rows <- list()
 for(g in genes) {
  rc <- as.numeric(counts[g,]); rd <- as.numeric(dat[g,])
  for(label in labels) {
   idx <- which(values==label)
   row <- data.frame(gene=g,label=label,n=length(idx),mean_counts=mean(rc[idx]),mean_logdata=mean(rd[idx]),median_counts=median(rc[idx]))
   names(row)[2] <- key; rows[[length(rows)+1]] <- row
  }
 }
 write.csv(do.call(rbind,rows),file.path(out,filename),row.names=FALSE)
}
export_means(tps,tp,'timepoint','rloop_mean_activity_by_timepoint.csv')
export_means(cts,ct,'cell_type','rloop_mean_activity_by_celltype.csv')
comp <- as.data.frame(table(ct,tp)); names(comp) <- c('cell_type','timepoint','n')
write.csv(comp,file.path(out,'atac_composition.csv'),row.names=FALSE)
# The final historical export recomputed UMAP from PCA with these settings.
# This is not a promise of bitwise matching coordinates across Seurat/uwot versions.
set.seed(42)
atac <- RunUMAP(atac,reduction='pca',dims=1:30,verbose=FALSE)
um <- as.data.frame(Embeddings(atac,'umap')); names(um) <- c('umap_1','umap_2')
um$cell_type <- ct; um$timepoint <- tp; um$sample <- atac$Sample
write.csv(um,file.path(out,'atac_umap_coords.csv'))
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
cat('Exported ATAC sources to',out,'\n')
