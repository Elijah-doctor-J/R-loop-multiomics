"""Recompute GSE174574 per-cell exploratory rank-sum DE from supplied log-expression.

These are cell-level, exploratory comparisons. The legacy log2FC/logFC fields
store differences in mean supplied expression, not Seurat avg_log2FC estimates.
GSE225948 is handled separately by pipeline/22_gse225948_corrected_pseudobulk.py.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu

ROOT = Path(__file__).resolve().parents[2]
TABLES = ROOT / 'data/main_tables'
OUT = ROOT / 'outputs/source_exports'
OUT.mkdir(parents=True, exist_ok=True)

def bh_correct(p):
    p = np.asarray(p, dtype=float)
    order = np.argsort(p)
    ranked = p[order] * len(p) / np.arange(1, len(p)+1)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    out = np.empty(len(p)); out[order] = np.clip(ranked, 0, 1)
    return out

def compare(actual, expected, keys, cols):
    if actual.duplicated(keys).any() or expected.duplicated(keys).any():
        raise ValueError(f'Duplicate result keys: {keys}')
    merged = actual.merge(expected, on=keys, how='outer', suffixes=('_new','_stored'), indicator=True)
    if not merged['_merge'].eq('both').all():
        raise ValueError('Recomputed/stored result keys differ')
    report = {}
    for c in cols:
        a = merged[c+'_new'].to_numpy(dtype=float)
        b = merged[c+'_stored'].to_numpy(dtype=float)
        finite = np.isfinite(a) & np.isfinite(b)
        report[c] = {
            'equal_with_rtol_1e-7_atol_1e-12':bool(np.allclose(a,b,rtol=1e-7,atol=1e-12,equal_nan=True)),
            'max_absolute_difference':float(np.max(np.abs(a[finite]-b[finite]))) if finite.any() else None,
            'missingness_agrees':bool(np.array_equal(np.isnan(a),np.isnan(b))),
        }
    return {'rows':len(merged),'columns':report}

def gse174574():
    expr = pd.read_csv(ROOT/'data/figure_source/gse174574/gse174574_31genes_expression.csv.gz')
    folder = TABLES/'04_scrna_gse174574'
    umap = pd.read_csv(folder/'figure5_source/umap_coords.csv.gz').rename(columns={'Unnamed: 0':'cell_id'})
    if umap['cell_id'].duplicated().any() or expr['cell_id'].duplicated().any():
        raise ValueError('Duplicated GSE174574 cell IDs')
    expr['cell_type_correct'] = expr['cell_id'].map(umap.set_index('cell_id')['cell_type'])
    if expr['cell_type_correct'].isna().any():
        raise ValueError('GSE174574 cell annotations missing after exact ID mapping')
    genes=[c for c in expr if c not in ['cell_id','cell_type','group','cell_type_correct']]
    if len(genes)!=31: raise ValueError(f'Expected 31 genes, found {len(genes)}')
    rows=[]
    for ct in sorted(expr['cell_type_correct'].unique()):
        sub=expr[expr['cell_type_correct']==ct]
        mcao=sub[sub['group']=='MCAO']; sham=sub[sub['group']=='Sham']
        if not len(mcao) or not len(sham): raise ValueError(f'Missing group for {ct}')
        for g in genes:
            a=mcao[g].to_numpy(); b=sham[g].to_numpy()
            rows.append(dict(gene=g,cell_type=ct,MCAO_mean=float(a.mean()),Sham_mean=float(b.mean()),
                log2FC=float(a.mean()-b.mean()),p_value=float(mannwhitneyu(a,b,alternative='two-sided').pvalue),
                n_MCAO=len(a),n_Sham=len(b)))
    res=pd.DataFrame(rows)
    valid=res['p_value'].notna(); res['p_adj']=np.nan
    res.loc[valid,'p_adj']=bh_correct(res.loc[valid,'p_value'])
    res.to_csv(OUT/'GSE174574_rloop_DE_by_celltype.csv',index=False)
    stored=pd.read_csv(folder/'GSE174574_rloop_DE_by_celltype.csv')
    return compare(res,stored,['gene','cell_type'],['MCAO_mean','Sham_mean','log2FC','p_value','n_MCAO','n_Sham','p_adj'])

if __name__=='__main__':
    report={'GSE174574':gse174574()}
    (OUT/'singlecell_de_comparison.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    if not all(x['equal_with_rtol_1e-7_atol_1e-12'] for r in report.values() for x in r['columns'].values()):
        raise SystemExit('Differences detected; stored tables were not modified.')
