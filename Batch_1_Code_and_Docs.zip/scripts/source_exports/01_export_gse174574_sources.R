# Export sources underlying Figure 5 and final GSE174574 per-cell DE.
# Requires the Seurat checkpoint produced by the scRNA workflow. Raw checkpoint
# construction is external to this exporter; package versions affect embeddings.
args_all <- commandArgs(trailingOnly=FALSE)
script <- sub('^--file=', '', args_all[grep('^--file=',args_all)][1])
root <- normalizePath(file.path(dirname(script),'../..'), mustWork=TRUE)
out <- file.path(root,'outputs/source_exports/gse174574')
dir.create(out, recursive=TRUE, showWarnings=FALSE)
input <- file.path(root,'data/external/checkpoints/GSE174574_seurat.rds')
if (!file.exists(input)) stop('Missing data/external/checkpoints/GSE174574_seurat.rds; see README')
suppressPackageStartupMessages({library(Seurat); library(Matrix)})
obj <- readRDS(input)
md <- obj@meta.data
required <- c('cell_type','group','sample')
if (!all(required %in% names(md))) stop('Checkpoint lacks required cell_type/group/sample metadata')
um <- Embeddings(obj,'umap')
coord <- data.frame(umap_1=um[,1],umap_2=um[,2],cell_type=md$cell_type,group=md$group,sample=md$sample)
write.csv(coord,file.path(out,'umap_coords.csv'))
comp <- as.data.frame(table(cell_type=md$cell_type,group=md$group)); names(comp)[3] <- 'n'
write.csv(comp,file.path(out,'composition.csv'),row.names=FALSE)
rloop <- c('Aqr','Atm','Atr','Bcl7b','Brca1','Brca2','Ddx1','Ddx21','Ddx3x','Ddx5',
 'Dhx9','Fancd2','Fancm','Parp1','Pif1','Prmt5','Rnaseh1','Rnaseh2a','Rnaseh2b',
 'Rnaseh2c','Setx','Thoc1','Thoc2','Thoc3','Thoc5','Thoc6','Thoc7','Top1','Top1mt','Vdac1','Xrn2')
genes <- intersect(rloop,rownames(obj))
if (length(genes)!=31) stop('Expected all 31 genes; this checkpoint differs from the final source')
X <- as.matrix(GetAssayData(obj,assay='RNA',layer='data')[genes,,drop=FALSE])
if (!identical(colnames(X),rownames(md))) stop('Expression/metadata cell order differs')
expr <- data.frame(cell_id=rownames(md),t(X),cell_type=md$cell_type,group=md$group,check.names=FALSE)
write.csv(expr,file.path(out,'gse174574_31genes_expression.csv'),row.names=FALSE)
score <- Matrix::colMeans(X)
ps <- data.frame(score=as.numeric(score),cell_type=md$cell_type,group=md$group,sample=md$sample)
write.csv(ps,file.path(out,'module_score_per_cell.csv'))
rows <- list()
for(g in genes) for(ct in levels(factor(md$cell_type))) {
 idx <- which(md$cell_type==ct); v <- X[g,idx]
 rows[[length(rows)+1]] <- data.frame(gene=g,cell_type=ct,avg=mean(v),pct=mean(v>0)*100,n=length(idx))
}
write.csv(do.call(rbind,rows),file.path(out,'dotplot_source.csv'),row.names=FALSE)
set.seed(42)
obj <- AddModuleScore(obj,features=list(Rloop=genes),name='RloopMS',seed=42)
ms <- data.frame(ms=as.numeric(obj@meta.data$RloopMS1),cell_type=md$cell_type,group=md$group,sample=md$sample)
write.csv(ms,file.path(out,'module_score_addmodule.csv'))
markers <- intersect(c('Ddx21','Ddx5','Rnaseh1','Bcl7b','Setx','Top1','Ddx1'),rownames(obj))
MX <- as.matrix(GetAssayData(obj,assay='RNA',layer='data')[markers,,drop=FALSE])
marker <- data.frame(umap_1=um[,1],umap_2=um[,2],cell_type=md$cell_type,group=md$group,as.data.frame(t(MX)))
write.csv(marker,file.path(out,'marker_expression.csv'))
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
cat('Exported GSE174574 sources to',out,'\n')
