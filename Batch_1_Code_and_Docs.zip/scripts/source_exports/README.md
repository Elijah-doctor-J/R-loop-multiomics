# Final source exports and single-cell differential results

This directory consolidates the scientific export/correction steps that were
performed after the initial analysis. It contains one version of each operation,
with project-relative paths. It does not edit manuscript files, replace stored
tables, create backups or silently update the evidence snapshots.

| Script | Required input | Generated output | Figure/table use |
|---|---|---|---|
| `01_export_gse174574_sources.R` | `data/external/checkpoints/GSE174574_seurat.rds` with RNA data layer, UMAP and `cell_type/group/sample` metadata | `outputs/source_exports/gse174574/`: UMAP, composition, 31-gene expression, mean expression score, AddModuleScore, dot-plot and selected marker sources; sessionInfo | Figure 5A–G; final GSE174574 DE in S3 |
| `02_export_atac_sources.R` | `data/external/checkpoints/atac_seurat.rds` with data/counts, PCA, `timepoint/cell_type/Sample` metadata | `outputs/source_exports/atac/`: per-cell-mean gene activity by timepoint/cell type, composition and PCA-based UMAP; sessionInfo | Figure 7A–D; final per-cell-mean activity inputs |
| `03_recompute_singlecell_de.py` | Bundled GSE174574 31-gene expression and Figure 5 UMAP cell annotations | `outputs/source_exports/`: GSE174574 DE CSV and comparison report | Figure 5; GSE174574 sheet of S3; DE evidence used downstream |

## Run the verified processed-data step

From the repository root:

```sh
python scripts/source_exports/03_recompute_singlecell_de.py
```

The script checks exact cell-ID mapping and result-key coverage, computes
Mann–Whitney rank-sum tests, writes new outputs separately, and compares every
numeric column against the supplied final tables. It fails visibly if result
keys or numeric values differ. It does not overwrite `data/`.

## Meaning of the legacy columns

- GSE174574: `log2FC` is the difference in mean stored log-normalized expression
  (MCAO minus Sham). Its name is retained for compatibility with the final files;
  it is not a base-2 fold change. `p_value` is the two-sided per-cell rank-sum
  p-value. `p_adj` is Benjamini–Hochberg correction across the 335 nonmissing
  p-values among 341 gene/cell-type comparisons.
- GSE225948 is analyzed separately by `scripts/pipeline/22_gse225948_corrected_pseudobulk.py`. It uses the corrected log1p(count / full-matrix library size × 10,000) layer, then pooled-sample-library × cell-type means and exact Mann–Whitney U tests with BH correction. The separate per-cell result is exploratory only. Neither legacy `logFC` nor `log2FC` column names make a difference in mean log-expression a base-2 fold change.
- Cells are the units in the GSE174574 rank-sum tests. Sample-level GSE225948 means, composition, and other revision analyses must be interpreted at their stated replicate level.

## Checkpoint exports and limits

The R exporters require a Seurat version supporting the `layer=` API. Large
GSE174574 and ATAC checkpoints (approximately 684 MB and 4.8 GB) are not included.
Both exporters stop with a specific missing-input message when required.

Existing checkpoint cell annotations and embeddings are required, and the
original historical package versions were not fully recorded. The ATAC UMAP
export uses PCA dimensions 1:30 and seed 42, matching the final export settings;
identical coordinates across package versions are not guaranteed. Bundled
coordinate/summary CSVs permit panel regeneration without the checkpoints.
