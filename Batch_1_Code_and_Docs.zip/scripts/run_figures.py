"""Regenerate current manuscript panels from the bundled processed tables.

Run: python scripts/run_figures.py
Optional: python scripts/run_figures.py --figures 1 2 3 4 5 7 8 9
Figure 6 and revision/supplementary panels use scripts/revision_R4 (see its README).
"""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = {1: 'figure1_workflow.py', 2:'figure2_panels.py',
           3:'figure3_panels.py',4:'figure4_panels.py',5:'figure5_panels.py',
           7:'figure7_panels.py',8:'figure8_panels.py',9:'figure9_panels.py'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--figures',nargs='+',type=int,choices=sorted(SCRIPTS),default=sorted(SCRIPTS))
    args=parser.parse_args()
    for n in args.figures:
        print(f'Rendering Figure {n}',flush=True)
        subprocess.run([sys.executable,str(ROOT/'scripts/figure_panels'/SCRIPTS[n])],check=True,cwd=ROOT)

if __name__=='__main__':
    main()
