# -*- coding: utf-8 -*-
"""
Supplementary Figure 2: standalone volcano plots for ALL FIVE bulk cohorts,
matching the main Figure 2B style exactly (same palette, thresholds, R-loop
hollow circles, significant-R-loop labels). Adds GSE22255, omitted from the
main figure because it has no DEGs after BH correction (shown honestly here).
Outputs PNG 600dpi / PDF / SVG per cohort.
"""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt

BASE = Path(ROOT / 'data/main_tables')
OUT = ROOT / 'outputs/figures/Supplementary_Figure_S1'
OUT.mkdir(parents=True, exist_ok=True)

C_UP = '#e0524d'
C_DOWN = '#48639a'
C_NS = '#cfd3d8'
C_RLOOP_EDGE = '#1a1a1a'

mpl.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 10,
    'axes.labelsize': 11, 'axes.titlesize': 12,
    'xtick.labelsize': 10, 'ytick.labelsize': 10,
    'svg.fonttype': 'none', 'pdf.fonttype': 42,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.linewidth': 0.9, 'xtick.major.width': 0.9, 'ytick.major.width': 0.9,
    'legend.frameon': False, 'figure.facecolor': 'white',
})

DATASETS = [
    ('GSE163614', 'Rat MCAO brain (RNA-seq, n=3/group)',
     '01_bulk_transcriptomics/GSE163614_DESeq2_results.csv.gz',
     'log2FoldChange', 'padj', 'animal'),
    ('GSE137482', 'Mouse MCAO brain (RNA-seq, age-adjusted)',
     '01_bulk_transcriptomics/GSE137482_DESeq2_results.csv.gz',
     'log2FoldChange', 'padj', 'animal'),
    ('GSE61616', 'Rat MCAO brain (microarray)',
     '01_bulk_transcriptomics/GSE61616_limma_results.csv.gz',
     'logFC', 'adj.P.Val', 'animal'),
    ('GSE22255', 'Human ischemic-stroke blood (microarray, 20 vs 20)',
     '02_human_validation/GSE22255_limma_results.csv.gz',
     'logFC', 'adj.P.Val', 'human'),
    ('GSE16561', 'Human ischemic-stroke blood (microarray, 39 vs 24)',
     '02_human_validation/GSE16561_limma_results.csv.gz',
     'logFC', 'adj.P.Val', 'human'),
]

# label offsets reused from main Figure 2B (only significant R-loop genes labelled)
LABEL_OFFSET = {
    'GSE163614': {'Ddx21': (5, 5)},
    'GSE137482': {'Pif1': (-44, 7), 'Brca1': (5, 5)},
    'GSE61616': {'Fancd2': (5, 5), 'Parp1': (-48, 2), 'Brca2': (18, 16),
                 'Rnaseh2b': (7, -16), 'Xrn2': (-36, 7), 'Ddx3x': (7, -14),
                 'Bcl7b': (-44, 0), 'Ddx1': (-40, -16), 'Thoc5': (7, 7)},
    'GSE16561': {'THOC3': (-7, 7), 'RNASEH1': (5, 5), 'ATM': (-34, -2),
                 'THOC1': (-36, -14), 'BCL7B': (5, -14), 'TOP1': (5, 2),
                 'DDX3X': (5, 5)},
    'GSE22255': {},
}


def load_deg(rel, lfc_col, p_col):
    df = pd.read_csv(BASE / rel).rename(columns={lfc_col: 'log2FC', p_col: 'padj'})
    df = df[['gene', 'log2FC', 'padj']].dropna(subset=['log2FC', 'padj']).copy()
    df['padj'] = df['padj'].clip(lower=1e-50)
    df['neglog10p'] = -np.log10(df['padj'])
    return df


def rloop_sets():
    cross = pd.read_csv(BASE / '01_bulk_transcriptomics/rloop_genes_cross_dataset.csv')
    return set(cross['gene'].dropna()), set(cross['gene_human'].dropna())


def make_volcano(gid, subtitle, rel, lfc_col, p_col, kind, mouse_set, human_set):
    df = load_deg(rel, lfc_col, p_col)
    rset = human_set if kind == 'human' else mouse_set

    sig_up = (df['padj'] < 0.05) & (df['log2FC'] > 0)
    sig_down = (df['padj'] < 0.05) & (df['log2FC'] < 0)
    is_rloop = df['gene'].isin(rset)
    n_up, n_down = int(sig_up.sum()), int(sig_down.sum())

    ycap = min(df['neglog10p'].quantile(0.999) * 1.15, 60)
    df['y_disp'] = df['neglog10p'].clip(upper=ycap)

    fig, ax = plt.subplots(figsize=(5.4, 4.8))
    ns = ~sig_up & ~sig_down
    ax.scatter(df.loc[ns, 'log2FC'], df.loc[ns, 'y_disp'], s=4, c=C_NS,
               alpha=0.55, linewidths=0, rasterized=True, label='Not significant')
    ax.scatter(df.loc[sig_down, 'log2FC'], df.loc[sig_down, 'y_disp'], s=6,
               c=C_DOWN, alpha=0.65, linewidths=0, rasterized=True, label='Downregulated')
    ax.scatter(df.loc[sig_up, 'log2FC'], df.loc[sig_up, 'y_disp'], s=6,
               c=C_UP, alpha=0.65, linewidths=0, rasterized=True, label='Upregulated')

    rl = df[is_rloop]
    ax.scatter(rl['log2FC'], rl['y_disp'], s=70, facecolors='none',
               edgecolors=C_RLOOP_EDGE, linewidths=1.2, zorder=5,
               label='R-loop-associated gene')

    rl_sig = rl[rl['padj'] < 0.05]
    for _, gr in rl_sig.iterrows():
        g = gr['gene']; dx, dy = LABEL_OFFSET.get(gid, {}).get(g, (5, 5))
        ax.annotate(g, (gr['log2FC'], gr['y_disp']), fontsize=8, fontweight='bold',
                    xytext=(dx, dy), textcoords='offset points', color='#111', zorder=6,
                    bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none', alpha=0.8))

    ax.axhline(-np.log10(0.05), color='#666', linestyle='--', linewidth=0.9, zorder=4)
    ax.set_title(f'{gid}  {subtitle}', fontsize=10.5, fontweight='bold', loc='left')
    ax.set_xlabel('log$_2$ fold change (MCAO / Stroke vs control)')
    ax.set_ylabel('−log$_{10}$(adj. p)')
    ax.set_ylim(0, ycap * 1.06)
    base_x = np.nanpercentile(df['log2FC'].abs(), 99.5) * 1.1
    lab_x = rl_sig['log2FC'].abs().max() if len(rl_sig) else 0
    xlim = max(base_x, lab_x * 1.3, 0.3)
    ax.set_xlim(-xlim, xlim)
    ax.grid(linewidth=0.4, color='#eef0f2', zorder=0)
    ax.legend(loc='upper center', ncol=2, fontsize=8, bbox_to_anchor=(0.5, -0.16),
              columnspacing=1.3, handletextpad=0.4)

    # DEG count / no-DEG note
    if n_up + n_down == 0:
        ax.text(0.5, 0.92, 'No genes reached adj. p < 0.05 after BH correction',
                transform=ax.transAxes, ha='center', va='top', fontsize=9,
                color='#a33', style='italic',
                bbox=dict(boxstyle='round,pad=0.3', fc='#fbf2f2', ec='#d9b3b3'))
        ax.text(0.02, 0.97, f'n = {len(df):,} tested genes', transform=ax.transAxes,
                ha='left', va='top', fontsize=8.5, color='#555')
    else:
        ax.text(0.99, 0.985, f'{n_up} up · {n_down} down (adj. p<0.05)',
                transform=ax.transAxes, ha='right', va='top', fontsize=8.5, color='#333')
        ax.text(0.02, 0.985, f'n = {len(df):,} tested genes', transform=ax.transAxes,
                ha='left', va='top', fontsize=8.5, color='#555')

    fig.tight_layout()
    for ext, kw in [('png', {'dpi': 600}), ('pdf', {}), ('svg', {})]:
        fig.savefig(OUT / f'SuppFig1_{gid}_volcano.{ext}',
                    bbox_inches='tight', facecolor='white', **kw)
    plt.close(fig)
    print(f'{gid}: {len(df)} tested, {n_up} up, {n_down} down, '
          f'{len(rl)} R-loop shown, {len(rl_sig)} R-loop sig')


if __name__ == '__main__':
    ms, hs = rloop_sets()
    print('mouse rloop:', len(ms), 'human rloop:', len(hs))
    for args in DATASETS:
        make_volcano(*args, ms, hs)
    print('Done ->', OUT)
