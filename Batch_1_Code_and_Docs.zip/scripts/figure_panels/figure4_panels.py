# -*- coding: utf-8 -*-
"""
Figure 4 panels — Network analysis prioritizes candidate hub genes.
All panels are driven strictly by the result CSVs. No mock data.
A  WGCNA diagnostics (native soft-threshold + dendrogram PNGs; cannot be rebuilt from CSV)
B  module-trait relationship heatmap            <- module_trait_relationships.csv
C  key-module GO enrichment                     <- module_{blue,brown,cyan,midnightblue}_GO.csv
D  R-loop gene module membership (kME)          <- rloop_module_membership.csv
E  PPI centrality landscape (3 metrics)         <- rloop_genes_network_metrics.csv
F  composite centrality ranking                 <- rloop_genes_network_metrics.csv
G  LODO significance-direction matrix           <- rloop_genes_cross_dataset_integrated.csv
"""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
import sys, os
import textwrap
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, ListedColormap, Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Patch
from matplotlib.image import imread
from matplotlib import patheffects

mpl.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'svg.fonttype': 'none', 'pdf.fonttype': 42, 'font.size': 7,
    'axes.spines.right': False, 'axes.spines.top': False,
    'axes.linewidth': 0.8, 'legend.frameon': False,
    'xtick.major.width': 0.8, 'ytick.major.width': 0.8, 'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5,
})

RES = ROOT / 'data/main_tables'
WGCNA = os.path.join(RES, r'06_wgcna_network')
PPI = os.path.join(RES, r'07_ppi_network')
OUT = ROOT / 'outputs/figures/Figure4'
os.makedirs(OUT, exist_ok=True)

# ---- shared palette ----
C_UP, C_DOWN, C_GOLD = '#e0524d', '#48639a', '#d4a017'
MOD_COLOR = {'blue': '#3b6fb6', 'midnightblue': '#4a5a8a', 'brown': '#a0673f',
             'cyan': '#4fb0b0', 'grey': '#b5b5b5'}
MOD_LABEL = {'blue': 'Blue', 'midnightblue': 'Midnightblue', 'brown': 'Brown',
             'cyan': 'Cyan', 'grey': 'Grey'}
# Table 1 functional modules (human uppercase symbols)
MODULE_OF = {}
for g in ['RNASEH1','RNASEH2A','RNASEH2B','RNASEH2C','SETX','TOP1','TOP1MT','PIF1']: MODULE_OF[g]=1
for g in ['DDX1','DDX3X','DDX5','DDX19','DDX21','DHX9','AQR']: MODULE_OF[g]=2
for g in ['ATM','ATR','BRCA1','BRCA2','PARP1','FANCD2','FANCM']: MODULE_OF[g]=3
for g in ['THOC1','THOC2','THOC3','THOC5','THOC6','THOC7','XRN2','PRMT5']: MODULE_OF[g]=4
MODULE_OF['BCL7B']=5; MODULE_OF['VDAC1']=6
FUNC_COLORS = {1:'#c0504d',2:'#e0a030',3:'#7a8fb0',4:'#5a8a6a',5:'#8e7ab5',6:'#6fb3b8'}
FUNC_NAMES = {1:'R-loop/hybrid resolution',2:'RNA helicases & RNP',3:'DNA-damage response',
              4:'RNA processing/export',5:'Chromatin',6:'Mitochondrial'}


def read_csv(path, *args, **kwargs):
    path = Path(path)
    if not path.exists() and path.with_name(path.name + '.gz').exists():
        path = path.with_name(path.name + '.gz')
    return pd.read_csv(path, *args, **kwargs)

def save(fig, name):
    for ext in ('png','pdf','svg'):
        fig.savefig(os.path.join(OUT, f'{name}.{ext}'), dpi=600, bbox_inches='tight')
    plt.close(fig)
    print('saved', name)

# ============================================================ A
def panel_a():
    sft = read_csv(os.path.join(WGCNA, 'soft_threshold_table.csv'))
    dend = imread(ROOT / 'data/figure_source/wgcna/module_dendrogram.png')
    POW = 17
    fig = plt.figure(figsize=(7.2, 5.0))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.05, 1.15], hspace=0.42, wspace=0.28)
    axL = fig.add_subplot(gs[0, 0]); axR = fig.add_subplot(gs[0, 1]); axD = fig.add_subplot(gs[1, :])
    lc = '#9db4d0'
    # left: scale-free fit
    axL.plot(sft['Power'], sft['SFT.R.sq'], '-', color=lc, lw=1.1, zorder=2)
    axL.scatter(sft['Power'], sft['SFT.R.sq'], s=16, color=lc, zorder=3)
    sel = sft['Power'] == POW
    axL.scatter(sft.loc[sel, 'Power'], sft.loc[sel, 'SFT.R.sq'], s=58, color=C_UP,
                ec='white', lw=0.8, zorder=5)
    axL.axhline(0.8, color='#999', ls='--', lw=0.8, zorder=1)
    axL.text(1.2, 0.82, 'R² = 0.8', fontsize=5.8, color='#777')
    axL.annotate(f'selected β = {POW}', (POW, sft.loc[sel,'SFT.R.sq'].iloc[0]),
                 xytext=(10.0, 0.95), fontsize=6.3, color=C_UP, fontweight='bold',
                 arrowprops=dict(arrowstyle='->', color=C_UP, lw=0.8))
    axL.set_xlabel('Soft-threshold power (β)', fontsize=7)
    axL.set_ylabel('Scale-free topology fit (R²)', fontsize=7)
    axL.set_ylim(-0.15, 1.02); axL.set_xticks([1,5,10,15,20])
    axL.set_title('Scale independence', fontsize=7.5, fontweight='bold', loc='center', pad=4)
    # right: mean connectivity
    axR.plot(sft['Power'], sft['mean.k.'], '-', color=lc, lw=1.1, zorder=2)
    axR.scatter(sft['Power'], sft['mean.k.'], s=16, color=lc, zorder=3)
    axR.scatter(sft.loc[sel,'Power'], sft.loc[sel,'mean.k.'], s=58, color=C_UP,
                ec='white', lw=0.8, zorder=5)
    axR.set_xlabel('Soft-threshold power (β)', fontsize=7)
    axR.set_ylabel('Mean connectivity', fontsize=7)
    axR.set_xticks([1,5,10,15,20])
    axR.set_title('Mean connectivity', fontsize=7.5, fontweight='bold', loc='center', pad=4)
    # bottom: native dendrogram (cannot be rebuilt from CSV)
    axD.imshow(dend); axD.axis('off')
    axD.set_title('Gene cluster dendrogram and merged co-expression modules',
                  fontsize=7.5, fontweight='bold', loc='left', pad=3)
    save(fig, 'Figure4A_wgcna_diagnostics')

# ============================================================ B
def panel_b():
    df = read_csv(os.path.join(WGCNA, 'module_trait_relationships.csv'))
    df['m'] = df['module'].str.replace('ME','', regex=False)
    df = df.sort_values('cor_MCAO', ascending=False).reset_index(drop=True)  # blue top
    traits = [('cor_MCAO','p_MCAO','MCAO'), ('cor_Age','p_Age','Age')]
    mods = df['m'].tolist()
    cmap = LinearSegmentedColormap.from_list('rb', ['#2f6fc0','#f4f6f8','#e0524d'])
    fig, ax = plt.subplots(figsize=(3.7, 3.3))
    nrow, ncol = len(mods), 2
    for i, m in enumerate(mods):
        row = df[df['m']==m].iloc[0]
        for j,(cc,pp,lab) in enumerate(traits):
            r, pv = row[cc], row[pp]
            ax.add_patch(plt.Rectangle((j, nrow-1-i), 1, 1, color=cmap((r+1)/2),
                                       ec='white', lw=1.2))
            pstr = f'{pv:.1e}' if pv < 1e-3 else f'{pv:.3f}'.rstrip('0').rstrip('.')
            ax.text(j+0.5, nrow-1-i+0.5, f'{r:.2f}\n({pstr})',
                    ha='center', va='center', fontsize=6.3,
                    color='white' if abs(r)>0.7 else '#222222')
    # module color strip
    for i, m in enumerate(mods):
        ax.add_patch(plt.Rectangle((-0.32, nrow-1-i), 0.26, 1, color=MOD_COLOR[m],
                                   ec='white', lw=1, clip_on=False))
    ax.set_xlim(-0.32, ncol); ax.set_ylim(0, nrow)
    ax.set_xticks([0.5,1.5]); ax.set_xticklabels(['MCAO','Age'])
    ax.set_yticks([nrow-1-i+0.5 for i in range(nrow)])
    ax.set_yticklabels([MOD_LABEL[m] for m in mods])
    ax.tick_params(length=0)
    for s in ax.spines.values(): s.set_visible(False)
    sm = ScalarMappable(Normalize(-1,1), cmap); sm.set_array([])
    cb = fig.colorbar(sm, ax=ax, fraction=0.06, pad=0.04, ticks=[-1,-0.5,0,0.5,1])
    cb.set_label('Correlation', fontsize=6.5); cb.ax.tick_params(labelsize=6)
    ax.set_title('Module–trait relationships', fontsize=8, fontweight='bold', loc='left', pad=6)
    fig.tight_layout(rect=[0.04, 0.04, 0.96, 0.96])
    save(fig, 'Figure4B_module_trait_heatmap')

# ============================================================ C
def _short(t, n=27):
    # wrap long GO terms at word boundaries (never truncate a word)
    return '\n'.join(textwrap.wrap(t, width=n, break_long_words=False, break_on_hyphens=False))

def panel_c():
    order = [('blue','Blue (+MCAO)'), ('midnightblue','Midnightblue (−MCAO)'),
             ('brown','Brown (−MCAO)'), ('cyan','Cyan (+MCAO)')]
    mtr = read_csv(os.path.join(WGCNA,'module_trait_relationships.csv'))
    mtr['m']=mtr['module'].str.replace('ME','',regex=False)
    corr = dict(zip(mtr['m'], mtr['cor_MCAO']))
    fig, axes = plt.subplots(2,2, figsize=(7.6,5.4))
    for ax,(mod,title) in zip(axes.ravel(), order):
        g = read_csv(os.path.join(WGCNA, 'module_GO_enrichment.csv.gz'))
        g = g[g['module'] == mod].head(6).iloc[::-1]
        y = np.arange(len(g)); ne = -np.log10(g['p.adjust'].clip(lower=1e-300))
        ax.barh(y, ne, color=MOD_COLOR[mod], height=0.66, alpha=0.92)
        for yi,(v,c) in enumerate(zip(ne, g['Count'])):
            ax.text(v+max(ne)*0.012, yi, f' n={c}', va='center', fontsize=5.8, color='#444')
        ax.set_yticks(y)
        ax.set_yticklabels([_short(t) for t in g['Description']], fontsize=6, va='center')
        ax.set_xlabel('−log10(adjusted p)', fontsize=6.3)
        ax.set_title(f'{title}  r = {corr[mod]:.2f}', fontsize=7, fontweight='bold', loc='left')
        ax.set_xlim(0, max(ne)*1.18)
    fig.tight_layout(h_pad=1.6, w_pad=3.0)
    save(fig, 'Figure4D_module_GO')

# ============================================================ D
def panel_d():
    df = read_csv(os.path.join(WGCNA,'rloop_module_membership.csv'))
    df = df.sort_values('kME').reset_index(drop=True)
    fig, ax = plt.subplots(figsize=(3.6,3.2))
    y = np.arange(len(df))
    ax.hlines(y, 0, df['kME'], color='#d9d9d9', lw=1.0, zorder=1)
    for i,r in df.iterrows():
        ax.scatter(r['kME'], i, s=46, color=MOD_COLOR[r['module']], zorder=3,
                   ec='white', lw=0.6)
        ax.text(r['kME']+0.02, i, f'{r["kME"]:.2f}', va='center', fontsize=6)
    ax.axvline(0.7, color='#888', ls='--', lw=0.8, zorder=2)
    ax.text(0.705, len(df)-0.4, 'kME = 0.7', fontsize=5.8, color='#666')
    ax.set_yticks(y); ax.set_yticklabels(list(df['gene']), fontsize=6.5)
    # italic gene symbols
    for t in ax.get_yticklabels():
        t.set_fontstyle('italic')
    ax.set_xlim(0,1.08); ax.set_ylim(-0.6,len(df)-0.2)
    ax.set_xlabel('Module membership (kME)', fontsize=7)
    handles=[Patch(fc=MOD_COLOR[m], ec='white', label=MOD_LABEL[m]+' module') for m in ['blue','brown']]
    ax.legend(handles=handles, loc='lower right', fontsize=6)
    ax.set_title('R-loop genes in MCAO-associated modules', fontsize=8, fontweight='bold', loc='left')
    fig.tight_layout()
    save(fig, 'Figure4C_rloop_kME')

# ============================================================ E
def _fr_layout(nodes, edges_w, radius, seed=11, iters=1100,
               kscale=42.0, coll=5.5, attr_w=(0.16, 0.26)):
    """Vectorized Fruchterman-Reingold with collision avoidance + final relaxation."""
    n = len(nodes); idx = {g: i for i, g in enumerate(nodes)}
    rng = np.random.default_rng(seed)
    pos = rng.normal(0, 0.3, (n, 2))
    W = np.zeros((n, n))
    for a, b, w in edges_w:
        i, j = idx[a], idx[b]; W[i, j] = w; W[j, i] = w
    adj = W > 0
    k = np.sqrt(kscale / n)
    R = radius[:, None] + radius[None, :] + 0.08
    temp = 0.5

    def step(pos, gravity_on, t, grav_scale=1.0):
        diff = pos[:, None, :] - pos[None, :, :]
        dist = np.linalg.norm(diff, axis=2) + 1e-9
        np.fill_diagonal(dist, 1.0)
        unit = diff / dist[:, :, None]
        rep = k * k / dist
        gap = np.clip(R - dist, 0, None)
        force = rep + coll * gap
        disp = (unit * force[:, :, None]).sum(1)
        if gravity_on:
            for i in range(n):
                for j in np.where(adj[i])[0]:
                    d = pos[i] - pos[j]; dd = np.linalg.norm(d) + 1e-9
                    f = dd * dd / k * (attr_w[0] + attr_w[1] * W[i, j]) * grav_scale
                    disp[i] -= d / dd * f
        dn = np.linalg.norm(disp, axis=1, keepdims=True) + 1e-9
        return pos + disp / dn * np.minimum(dn, t)

    for it in range(iters):
        pos = step(pos, True, temp)
        pos -= pos.mean(0)
        temp = max(temp * 0.995, 0.02)
    # final gentle relaxation that KEEPS weak gravity (preserves core-periphery) while removing overlap
    for _ in range(400):
        pos = step(pos, True, 0.03, grav_scale=0.5)
        pos -= pos.mean(0)
    return pos, idx

def _worst_gap(pos, radius):
    """smallest signed clearance between any two nodes (higher = better layout)."""
    d = np.linalg.norm(pos[:, None, :] - pos[None, :, :], axis=2)
    R = radius[:, None] + radius[None, :]
    np.fill_diagonal(d, np.inf)
    return np.min(d - R)

def _place_label(pos, i, radius, names, n_ang=24):
    """Pick an outward label angle whose text segment clears all other nodes."""
    n = len(pos)
    base = np.arctan2(pos[i, 1], pos[i, 0])
    seg = 0.055 * len(names[i])          # approx text half-length in data units
    best = None
    for k in range(n_ang):
        ang = base + 2*np.pi*k/n_ang
        u = np.array([np.cos(ang), np.sin(ang)])
        anchor = pos[i] + u*(radius[i]+0.13)
        pts = [anchor, anchor + u*seg]
        cmin = min(min(np.linalg.norm(p-pos[j])-radius[j]
                       for j in range(n) if j != i) for p in pts)
        score = cmin - 0.30*abs(((ang-base+np.pi) % (2*np.pi))-np.pi)
        if best is None or score > best[0]:
            best = (score, ang, u)
    return best[1], best[2]

def _layout_score(pos, radius, names, sizes, fs_ext=5.3):
    """worst node gap, penalised by external labels that would collide with other nodes."""
    n = len(names)
    gap = _worst_gap(pos, radius)
    collisions = 0
    for i, g in enumerate(names):
        diam = 2*np.sqrt(sizes[i]/np.pi)
        if len(g)*fs_ext*0.62 < diam*0.86:      # internal label, no external anchor
            continue
        ang, u = _place_label(pos, i, radius, names)
        anchor = pos[i] + u*(radius[i]+0.13)
        seg = 0.055*len(g)
        for p in [anchor, anchor+u*seg]:
            for j in range(n):
                if j == i:
                    continue
                if np.linalg.norm(p-pos[j]) < radius[j]+0.02:
                    collisions += 1
    return gap - 1.5*collisions, collisions

def panel_e():
    edges = read_csv(os.path.join(PPI, 'rloop_ppi_edges.csv'))
    vert = read_csv(os.path.join(PPI, 'rloop_ppi_vertices.csv'))
    vert['func'] = vert['name'].map(MODULE_OF)
    nodes = list(vert['name'])
    deg = vert.set_index('name').loc[nodes, 'degree'].values.astype(float)
    deg_norm = (deg - deg.min())/(deg.max()-deg.min())
    sizes = 110 + deg_norm*470
    radius = 0.12 + deg_norm*0.26
    ew = list(zip(edges['from'], edges['to'], edges['weight']))
    # choose the seed that maximises node clearance while avoiding label collisions
    best, best_score = None, -np.inf
    for sd in range(40):
        cand, idx = _fr_layout(nodes, ew, radius, seed=sd)
        sc, ncol = _layout_score(cand, radius, nodes, sizes)
        if sc > best_score:
            best, best_score, best_idx, best_col = cand, sc, idx, ncol
    pos, idx = best, best_idx
    top8 = ['SETX','TOP1','RNASEH1','PARP1','BRCA1','PIF1','DHX9','THOC2']
    present = sorted(vert['func'].dropna().unique())
    fig, ax = plt.subplots(figsize=(5.6, 5.0))
    for _, r in edges.iterrows():
        i, j = idx[r['from']], idx[r['to']]
        ax.plot([pos[i,0], pos[j,0]], [pos[i,1], pos[j,1]],
                color='#9aa6b8', lw=0.3 + r['weight']*1.3,
                alpha=0.10 + r['weight']*0.40, zorder=1, solid_capstyle='round')
    vx = vert.set_index('name')
    for gi, g in enumerate(nodes):
        fc = FUNC_COLORS[int(vx.loc[g,'func'])]
        emph = g in top8
        ax.scatter(pos[gi,0], pos[gi,1], s=sizes[gi], color=fc, zorder=3,
                   ec='#333333' if emph else '#ffffff', lw=1.1 if emph else 0.6, alpha=0.96)
        diam = 2*np.sqrt(sizes[gi]/np.pi)                 # node diameter in points
        fs = 5.8 if emph else 5.3
        fw = 'bold' if emph else 'normal'
        if emph:                                          # hubs: shrink font to fit, keep inside
            while len(g)*fs*0.62 >= diam*0.9 and fs > 4.0:
                fs -= 0.2
            inside = True
        else:
            inside = len(g)*fs*0.62 < diam*0.86
        if inside:
            ax.text(pos[gi,0], pos[gi,1], g, ha='center', va='center',
                    fontsize=fs, zorder=4, fontweight=fw, color='white')
        else:
            _, u = _place_label(pos, gi, radius, nodes)
            off = radius[gi] + 0.13
            lx, ly = pos[gi,0]+u[0]*off, pos[gi,1]+u[1]*off
            ha = 'left' if u[0] > 0.3 else ('right' if u[0] < -0.3 else 'center')
            va = 'bottom' if u[1] > 0.3 else ('top' if u[1] < -0.3 else 'center')
            ax.text(lx, ly, g, ha=ha, va=va, fontsize=fs-0.2, zorder=4,
                    fontweight=fw, color='#222',
                    path_effects=[patheffects.withStroke(linewidth=2.0, foreground='white')])
    ax.set_aspect('equal'); ax.axis('off'); ax.margins(0.10)
    handles = [Patch(fc=FUNC_COLORS[int(k)], label=FUNC_NAMES[int(k)]) for k in present]
    ax.legend(handles=handles, loc='upper center', bbox_to_anchor=(0.5,-0.01),
              ncol=2, fontsize=5.8, columnspacing=1.0, handletextpad=0.4)
    ax.set_title('R-loop-associated PPI network (30 proteins, 133 interactions)',
                 fontsize=7.8, fontweight='bold', loc='left')
    fig.tight_layout()
    save(fig, 'Figure4E_ppi_network')

# ============================================================ F
def panel_f():
    df = read_csv(os.path.join(PPI,'rloop_genes_network_metrics.csv'))
    df['func']=df['gene'].map(MODULE_OF)
    d = df.nsmallest(15,'mean_rank').iloc[::-1]
    fig, ax = plt.subplots(figsize=(4.0,3.8))
    y=np.arange(len(d))
    ax.barh(y, d['mean_rank'], color=[FUNC_COLORS[f] for f in d['func']], height=0.7)
    for yi,v in zip(y,d['mean_rank']):
        ax.text(v+0.15, yi, f'{v:.1f}', va='center', fontsize=6)
    ax.set_yticks(y); ax.set_yticklabels(d['gene'], fontsize=6.5)
    ax.set_xlabel('Mean centrality rank (lower = higher priority)', fontsize=6.8)
    ax.set_xlim(0, d['mean_rank'].max()*1.12)
    handles=[Patch(fc=FUNC_COLORS[k], label=FUNC_NAMES[k]) for k in [1,2,3,4]]
    ax.legend(handles=handles, loc='upper center', bbox_to_anchor=(0.5,-0.14),
              ncol=2, fontsize=5.6, columnspacing=0.9, handletextpad=0.4)
    ax.set_title('Composite PPI centrality ranking (top 15)', fontsize=8, fontweight='bold', loc='left')
    fig.tight_layout()
    save(fig, 'Figure4F_centrality_ranking')

# ============================================================ G
def panel_g():
    df = read_csv(os.path.join(PPI,'rloop_genes_cross_dataset_integrated.csv'))
    cohorts = [('GSE163614','GSE163614_log2FC','GSE163614_padj','Rat brain'),
               ('GSE137482','GSE137482_log2FC','GSE137482_padj','Mouse brain'),
               ('GSE61616','GSE61616_log2FC','GSE61616_padj','Rat brain'),
               ('GSE22255','GSE22255_logFC','GSE22255_padj','Human blood'),
               ('GSE16561','GSE16561_logFC','GSE16561_padj','Human blood')]
    NC=5
    M=np.full((len(df),NC),0); sigc=np.zeros(len(df),int)
    for j,(g,lc,pc,_) in enumerate(cohorts):
        for i in range(len(df)):
            pv,lfc=df.loc[i,pc],df.loc[i,lc]
            if pd.isna(pv) or pd.isna(lfc): M[i,j]=3
            elif pv<0.05 and lfc>0: M[i,j]=1; sigc[i]+=1
            elif pv<0.05 and lfc<0: M[i,j]=-1; sigc[i]+=1
            else: M[i,j]=0
    df['sig']=sigc
    order=df.sort_values(['sig','gene_human'],ascending=[False,True]).index
    df=df.loc[order].reset_index(drop=True); M=M[order]; sigs=sigc[order]
    keep=df['sig']>=1
    Mk=M[keep.values]; genes=df.loc[keep,'gene_human'].tolist(); sk=sigs[keep.values]
    nr=len(genes)
    dist={k:int((sigc==k).sum()) for k in (0,1,2)}   # 15 / 15 / 2

    fig=plt.figure(figsize=(4.9,4.55))
    gs=fig.add_gridspec(2,1,height_ratios=[0.13,0.87],hspace=0.14,
                        left=0.17,right=0.93,top=0.89,bottom=0.21)
    axs=fig.add_subplot(gs[0]); ax=fig.add_subplot(gs[1])
    fig.text(0.17,0.965,'Cross-cohort recurrence of R-loop-gene significance',
             ha='left',va='top',fontsize=8.2,fontweight='bold')

    # ---- top: stability distribution across all 32 genes, aligned to the 5 cohort columns ----
    segs=[(dist[0],'no cohort','#dfe3ea','#444'),
          (dist[1],'1 cohort','#9fb0cc','#1f2d45'),
          (dist[2],'2 cohorts',C_UP,'white')]
    tot=sum(s[0] for s in segs); scale=NC/tot
    x=-0.5
    for n,lab,c,tc in segs:
        w=n*scale
        axs.add_patch(plt.Rectangle((x,0.42),w,0.58,color=c,ec='white',lw=1.2))
        axs.text(x+w/2,0.71,str(n),ha='center',va='center',fontsize=7.2,color=tc,fontweight='bold')
        axs.text(x+w/2,0.18,lab,ha='center',va='center',fontsize=5.7,color='#555')
        x+=w
    axs.set_xlim(-0.5,NC+0.94); axs.set_ylim(0,1.05); axs.axis('off')
    axs.text(-0.62,0.71,'32 genes:',ha='right',va='center',fontsize=5.9,fontweight='bold',color='#333')

    # ---- main: compact matrix of genes with >=1 significant hit ----
    cell_color={1:C_UP,-1:C_DOWN,0:'white',3:'#f4f5f7'}
    for i in range(nr):
        for j in range(NC):
            ax.add_patch(plt.Rectangle((j-0.5,i-0.5),1,1,color=cell_color[int(Mk[i,j])],
                                       ec='#e6e8ec',lw=0.7))
            if Mk[i,j]==3:
                ax.text(j,i,'—',ha='center',va='center',fontsize=6,color='#b3b3b3')
        ax.add_patch(plt.Rectangle((NC+0.06,i-0.5),0.88,1,color='#f6f6f6',ec='none',clip_on=False,zorder=0))
        ax.text(NC+0.50,i,str(int(sk[i])),ha='center',va='center',fontsize=6.4,
                color='#c0504d' if sk[i]>=2 else '#333',fontweight='bold' if sk[i]>=2 else 'normal')
    ax.plot([-0.5,NC-0.5],[1.5,1.5],color='#cccccc',lw=0.9,clip_on=False,zorder=5)
    ax.set_xticks(range(NC)); ax.set_xticklabels([c[3]+'\n'+c[0] for c in cohorts],fontsize=6.0)
    ax.set_yticks(range(nr)); ax.set_yticklabels(genes,fontsize=6.6)
    ax.set_xlim(-0.5,NC+0.94); ax.set_ylim(nr-0.5,-0.5)
    ax.tick_params(length=0,pad=2)
    for s in ['top','right']: ax.spines[s].set_visible(False)
    for s in ['left','bottom']: ax.spines[s].set_color('#cccccc')
    ax.text(NC+0.50,-1.04,'# sig.\ncohorts',ha='center',va='bottom',fontsize=5.9,fontweight='bold')
    handles=[Patch(fc=C_UP,label='Significantly up (padj<0.05)'),
             Patch(fc=C_DOWN,label='Significantly down'),
             Patch(fc='#f4f5f7',ec='#e6e8ec',label='Not detected'),
             Patch(fc='white',ec='#e6e8ec',label='Not significant')]
    ax.legend(handles=handles,loc='upper center',bbox_to_anchor=(0.44,-0.12),
              ncol=2,fontsize=5.9,columnspacing=0.9,handletextpad=0.4,frameon=False)
    fig.text(0.17,0.035,'Only the 17 genes significant in ≥1 cohort are listed; the other 15 (significant in none) are summarised in the top bar.',
             ha='left',va='bottom',fontsize=5.7,color='#666',style='italic')
    save(fig,'Figure4G_lodo_stability')

if __name__ == '__main__':
    panel_a(); panel_b(); panel_c(); panel_d(); panel_e(); panel_f(); panel_g()
    print('ALL FIGURE 4 PANELS DONE ->', OUT)
