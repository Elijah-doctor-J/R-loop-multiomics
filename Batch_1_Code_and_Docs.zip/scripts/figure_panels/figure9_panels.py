# -*- coding: utf-8 -*-
"""
Figure 9 panels — Multi-omic integration prioritizes a candidate network.
Reads final 26-gene complete-case susceptibility-proxy table, final integration table, and PPI edges/vertices.
A  26-gene complete-case heuristic susceptibility-proxy change
B  32-gene composite score ranking
C  top-15 x 8-dimension evidence heatmap
D  5 representative genes evidence radar
E  integrated PPI network (node size = composite score, colour = functional module)
F  26-gene complete-case susceptibility proxy versus integration score
"""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
import os
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Patch, FancyArrowPatch
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.cm import ScalarMappable
from matplotlib import patheffects

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
    "svg.fonttype": "none", "pdf.fonttype": 42, "font.size": 7,
    "axes.spines.right": False, "axes.spines.top": False,
    "axes.linewidth": 0.8, "legend.frameon": False,
    "xtick.major.width": 0.8, "ytick.major.width": 0.8,
})

RES = ROOT / 'data/main_tables'
INTG = os.path.join(RES, r"08_multiomic_integration")
PPI = os.path.join(RES, r"07_ppi_network")
OUT = ROOT / 'outputs/figures/Figure9'
os.makedirs(OUT, exist_ok=True)

# ---- functional modules (human uppercase, same as Table 1) ----
MODULE_OF = {}
for g in ["RNASEH1","RNASEH2A","RNASEH2B","RNASEH2C","SETX","TOP1","TOP1MT","PIF1"]: MODULE_OF[g]=1
for g in ["DDX1","DDX3X","DDX5","DDX19","DDX21","DHX9","AQR"]: MODULE_OF[g]=2
for g in ["ATM","ATR","BRCA1","BRCA2","PARP1","FANCD2","FANCM"]: MODULE_OF[g]=3
for g in ["THOC1","THOC2","THOC3","THOC5","THOC6","THOC7","XRN2","PRMT5"]: MODULE_OF[g]=4
MODULE_OF["BCL7B"]=5; MODULE_OF["VDAC1"]=6
FUNC_COLORS = {1:"#c0504d",2:"#e0a030",3:"#7a8fb0",4:"#5a8a6a",5:"#8e7ab5",6:"#6fb3b8"}
FUNC_NAMES = {1:"R-loop/hybrid resolution",2:"RNA helicases & RNP",3:"DNA-damage response",
              4:"RNA processing/export",5:"Chromatin",6:"Mitochondrial"}

# 8 evidence dimensions: (column, short label, full label, observed dimension maximum)
DIMS = [
    ("bulk_evidence_score",  "Bulk RNA",     "Bulk animal-model differential-expression evidence", 2/3),
    ("human_evidence_score", "Human",        "Human peripheral-blood support", 0.75),
    ("direction_score",      "Direction",    "Cross-dataset direction",      1.5),
    ("wgcna_score",          "WGCNA",        "WGCNA module membership",      1.5),
    ("ppi_score",            "PPI",          "PPI network centrality",       1.5),
    ("scrna_score",          "scRNA",        "Single-cell RNA-seq",          2.0),
    ("atac_score",           "snATAC",       "snATAC accessibility",         1.0),
    ("hichip_score",         "HiChIP",       "H3K27ac HiChIP contacts",      1.5),
]
DIM_COLS = [d[0] for d in DIMS]

def save(fig, name):
    fig.savefig(os.path.join(OUT, f"{name}.png"), dpi=600, bbox_inches="tight")
    fig.savefig(os.path.join(OUT, f"{name}.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, f"{name}.svg"), bbox_inches="tight")
    plt.close(fig)
    print("saved", name)

def load_scores():
    df = pd.read_csv(os.path.join(INTG, "integrated_hub_gene_scoring.csv"))
    df["func"] = df["gene"].map(MODULE_OF)
    return df.sort_values("rank", kind="stable").reset_index(drop=True)

# ============================================================ A: R-loop potential change
def panel_a():
    pot = pd.read_csv(os.path.join(RES, '12_rloop_formation_proxy/rloop_formation_potential_complete_cases.csv'))
    assert len(pot) == 26 and pot["gene"].is_unique
    assert pot[["bulk_log2FC", "atac_log2FC", "potential_change"]].notna().all().all()
    pot["gene_u"] = pot["gene"].str.upper()
    pot = pot.sort_values("potential_change", ascending=False).reset_index(drop=True)

    fig, ax = plt.subplots(figsize=(5.6, 7.8))
    y = np.arange(len(pot))
    pos_mask = pot["potential_change"] > 0
    colors = np.where(pos_mask, "#c0504d", "#4a7a9a")
    pos_set = set(pot.loc[pos_mask, "gene_u"])

    ax.barh(y, pot["potential_change"], color=colors, height=0.72,
            edgecolor=["#222" if g in pos_set else "none" for g in pot["gene_u"]],
            linewidth=[1.2 if g in pos_set else 0 for g in pot["gene_u"]])
    for yi, (v, g) in enumerate(zip(pot["potential_change"], pot["gene_u"])):
        if v >= 0:
            ax.text(v + 0.005, yi, f"{v:+.3f}", va="center", ha="left", fontsize=5.8,
                    fontweight="bold", color="#8a2a2a")
        else:
            ax.text(v - 0.005, yi, f"{v:+.3f}", va="center", ha="right", fontsize=5.6,
                    color="#3a5a7a")
    ax.set_yticks(y); ax.set_yticklabels(pot["gene_u"], fontsize=6.6)
    ax.axvline(0, color="#333", lw=1.0)
    ax.set_xlim(pot["potential_change"].min()-0.06, pot["potential_change"].max()+0.06)
    ax.set_xlabel("Midpoint-centered computational susceptibility proxy (Δ)", fontsize=7.2)
    ax.set_title("Heuristic susceptibility proxy change (26 complete-case genes)",
                 fontsize=8.2, fontweight="bold", loc="left", pad=6)
    ax.text(0.52, 0.96, f"{int(pos_mask.sum())} / {len(pot)} genes\nhave positive midpoint-centered scores",
            transform=ax.transAxes, fontsize=6.6, color="#c0504d",
            fontweight="bold", va="top", ha="left")
    handles = [Patch(fc="#c0504d", label=f"Above midpoint (n = {int(pos_mask.sum())})"),
               Patch(fc="#4a7a9a", label=f"Below midpoint (n = {int((~pos_mask).sum())})")]
    ax.legend(handles=handles, loc="lower right", fontsize=6.0)
    fig.tight_layout()
    save(fig, "Figure9A_rloop_potential_change")

# ============================================================ B: ranking
def panel_b():
    df = load_scores().sort_values("rank", ascending=False).reset_index(drop=True)  # rank1 on top
    fig, ax = plt.subplots(figsize=(5.4, 7.6))
    y = np.arange(len(df))
    colors = [FUNC_COLORS[int(f)] for f in df["func"]]
    # Highlight the first five fixed display positions; equal scores are not distinguished biologically.
    top5_set = set(load_scores().head(5)["gene"])
    bars = ax.barh(y, df["composite_score"], color=colors, height=0.72,
                   ec=["#222" if g in top5_set else "none" for g in df["gene"]],
                   lw=[1.1 if g in top5_set else 0 for g in df["gene"]])
    for yi, (v, g) in enumerate(zip(df["composite_score"], df["gene"])):
        ax.text(v+0.08, yi, f"{v:.2f}", va="center", fontsize=5.8,
                fontweight="bold" if g in top5_set else "normal",
                color="#222" if g in top5_set else "#555")
    ax.set_yticks(y); ax.set_yticklabels(df["gene"], fontsize=6.6)
    ax.set_xlabel("Composite multi-omic evidence score", fontsize=7.2)
    ax.set_xlim(0, 10.2)
    ax.axvline(7.0, color="#c0504d", ls="--", lw=0.8)
    ax.text(7.08, 9.0, "score = 7.0", fontsize=5.8, color="#c0504d", va="center")
    present = sorted(df["func"].dropna().unique())
    handles = [Patch(fc=FUNC_COLORS[int(k)], label=FUNC_NAMES[int(k)]) for k in present]
    ax.legend(handles=handles, loc="lower right", fontsize=5.6, ncol=1,
              bbox_to_anchor=(0.99, 0.01), borderaxespad=0.3)
    ax.set_title("Integrated ranking of 32 R-loop-associated genes",
                 fontsize=8.2, fontweight="bold", loc="left", pad=6)
    fig.tight_layout()
    save(fig, "Figure9B_composite_ranking")

# ============================================================ C: heatmap
def panel_c():
    df = load_scores().head(15)  # rank1 on top (imshow row 0 = top)
    genes = df["gene"].tolist()
    # Normalize by the observed dimension maxima used by the final sensitivity analysis.
    M = np.zeros((len(genes), len(DIMS)))
    raw = np.zeros((len(genes), len(DIMS)))
    for j, (col, _, _, mx) in enumerate(DIMS):
        raw[:, j] = df[col].values
        M[:, j] = df[col].values / mx
    cmap = LinearSegmentedColormap.from_list("ev", ["#f5f7fa", "#9db8d8", "#2f5b8f"])
    fig, ax = plt.subplots(figsize=(6.6, 6.2))
    im = ax.imshow(M, cmap=cmap, vmin=0, vmax=1, aspect="auto")
    for i in range(len(genes)):
        for j in range(len(DIMS)):
            ax.text(j, i, f"{raw[i,j]:.2f}".rstrip("0").rstrip("."),
                    ha="center", va="center", fontsize=6.0,
                    color="white" if M[i,j] > 0.62 else "#333")
    ax.set_xticks(range(len(DIMS)))
    ax.set_xticklabels([d[1] for d in DIMS], fontsize=6.6, rotation=30, ha="right")
    ax.set_yticks(range(len(genes))); ax.set_yticklabels(genes, fontsize=6.8)
    ax.set_xticks(np.arange(-.5, len(DIMS), 1), minor=True)
    ax.set_yticks(np.arange(-.5, len(genes), 1), minor=True)
    ax.grid(which="minor", color="white", lw=1.2)
    ax.tick_params(which="minor", length=0)
    cb = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02)
    cb.set_label("Fraction of dimension maximum", fontsize=6.5)
    cb.ax.tick_params(labelsize=6)
    ax.set_title("Evidence matrix for top-15 candidates (raw scores shown)",
                 fontsize=8, fontweight="bold", loc="left", pad=8)
    fig.tight_layout()
    save(fig, "Figure9C_evidence_matrix")

# ============================================================ D: radar
def panel_d():
    df = load_scores()
    focus = ["RNASEH1", "BCL7B", "DDX21", "DDX3X", "PARP1"]
    radar_colors = ["#c0504d", "#8e7ab5", "#e0a030", "#7a8fb0", "#3f7a52"]
    labels = [d[1] for d in DIMS]
    ang = np.linspace(0, 2*np.pi, len(DIMS), endpoint=False).tolist()
    ang_closed = ang + ang[:1]
    fig, ax = plt.subplots(figsize=(5.6, 5.2), subplot_kw=dict(polar=True))
    for gi, gene in enumerate(focus):
        row = df[df["gene"] == gene].iloc[0]
        vals = []
        for col, _, _, mx in DIMS:
            vals.append(row[col] / mx)  # normalized to [0,1]
        vals_c = vals + vals[:1]
        ax.plot(ang_closed, vals_c, color=radar_colors[gi], lw=1.6, label=gene)
        ax.fill(ang_closed, vals_c, color=radar_colors[gi], alpha=0.10)
    ax.set_xticks(ang); ax.set_xticklabels(labels, fontsize=6.8)
    ax.set_ylim(0, 1.0); ax.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["0.25", "0.50", "0.75", "1.0"], fontsize=5.6, color="#888")
    ax.set_rlabel_position(180/len(DIMS))
    ax.grid(color="#dddddd", lw=0.6)
    ax.spines["polar"].set_color("#cccccc")
    ax.legend(loc="upper right", bbox_to_anchor=(1.28, 1.12), fontsize=7, ncol=1)
    ax.set_title("Distinct evidence profiles of representative candidates\n(values normalized to each dimension's maximum)",
                 fontsize=7.8, fontweight="bold", pad=16)
    fig.tight_layout()
    save(fig, "Figure9D_gene_radar")

# ============================================================ E: integrated network
def _fr_layout(nodes, edges_w, radius, seed=11, iters=1100,
               kscale=42.0, coll=5.5, attr_w=(0.16, 0.26)):
    # Random positions initialize only the network drawing, never any measured data or score.
    n = len(nodes); idx = {g: i for i, g in enumerate(nodes)}
    rng = np.random.default_rng(seed)
    pos = rng.normal(0, 0.3, (n, 2))
    W = np.zeros((n, n))
    for a, b, w in edges_w:
        i, j = idx[a], idx[b]; W[i, j] = w; W[j, i] = w
    adj = W > 0
    k = np.sqrt(kscale / n)
    R = radius[:, None] + radius[None, :] + 0.08
    temp = 0.5
    def step(pos, gravity_on, t, grav_scale=1.0):
        diff = pos[:, None, :] - pos[None, :, :]
        dist = np.linalg.norm(diff, axis=2) + 1e-9
        np.fill_diagonal(dist, 1.0)
        unit = diff / dist[:, :, None]
        rep = k*k/dist
        gap = np.clip(R-dist, 0, None)
        force = rep + coll*gap
        disp = (unit*force[:, :, None]).sum(1)
        if gravity_on:
            for i in range(n):
                for j in np.where(adj[i])[0]:
                    d = pos[i]-pos[j]; dd = np.linalg.norm(d)+1e-9
                    f = dd*dd/k*(attr_w[0]+attr_w[1]*W[i,j])*grav_scale
                    disp[i] -= d/dd*f
        dn = np.linalg.norm(disp, axis=1, keepdims=True)+1e-9
        return pos + disp/dn*np.minimum(dn, t)
    for _ in range(iters):
        pos = step(pos, True, temp); pos -= pos.mean(0); temp = max(temp*0.995, 0.02)
    for _ in range(400):
        pos = step(pos, True, 0.03, grav_scale=0.5); pos -= pos.mean(0)
    return pos, idx

def _worst_gap(pos, radius):
    d = np.linalg.norm(pos[:, None, :]-pos[None, :, :], axis=2)
    R = radius[:, None]+radius[None, :]; np.fill_diagonal(d, np.inf)
    return np.min(d-R)

def _place_label(pos, i, radius, names, n_ang=24):
    n = len(pos); base = np.arctan2(pos[i,1], pos[i,0]); seg = 0.055*len(names[i]); best=None
    for k in range(n_ang):
        ang = base+2*np.pi*k/n_ang; u = np.array([np.cos(ang), np.sin(ang)])
        anchor = pos[i]+u*(radius[i]+0.13); pts=[anchor, anchor+u*seg]
        cmin = min(min(np.linalg.norm(p-pos[j])-radius[j] for j in range(n) if j!=i) for p in pts)
        score = cmin - 0.30*abs(((ang-base+np.pi)%(2*np.pi))-np.pi)
        if best is None or score > best[0]: best=(score, ang, u)
    return best[1], best[2]

def _layout_score(pos, radius, names, sizes, fs_ext=5.3):
    gap = _worst_gap(pos, radius); collisions = 0
    for i, g in enumerate(names):
        diam = 2*np.sqrt(sizes[i]/np.pi)
        if len(g)*fs_ext*0.62 < diam*0.86: continue
        ang, u = _place_label(pos, i, radius, names); anchor = pos[i]+u*(radius[i]+0.13); seg=0.055*len(g)
        for p in [anchor, anchor+u*seg]:
            for j in range(len(names)):
                if j==i: continue
                if np.linalg.norm(p-pos[j]) < radius[j]+0.02: collisions+=1
    return gap-1.5*collisions, collisions

def panel_e():
    edges = pd.read_csv(os.path.join(PPI, "rloop_ppi_edges.csv"))
    vert = pd.read_csv(os.path.join(PPI, "rloop_ppi_vertices.csv"))
    scores = load_scores().set_index("gene")
    vert["func"] = vert["name"].map(MODULE_OF)
    nodes = list(vert["name"])
    # node size driven by composite score (fallback to degree if absent)
    comp = np.array([float(scores.loc[g, "composite_score"]) if g in scores.index else 0.0 for g in nodes])
    cn = (comp - comp.min())/(comp.max()-comp.min()+1e-9)
    sizes = 100 + cn*440
    radius = 0.115 + cn*0.235
    ew = list(zip(edges["from"], edges["to"], edges["weight"]))
    best, best_score = None, -np.inf
    for sd in range(100):
        cand, idx = _fr_layout(nodes, ew, radius, seed=sd, coll=12.0,
                               kscale=54.0, attr_w=(0.10, 0.17))
        sc, _ = _layout_score(cand, radius, nodes, sizes)
        if sc > best_score: best, best_score, best_idx = cand, sc, idx
    pos, idx = best, best_idx
    top5 = set(load_scores().head(5)["gene"])
    present = sorted(vert["func"].dropna().unique())
    fig, ax = plt.subplots(figsize=(6.0, 5.4))
    for _, r in edges.iterrows():
        i, j = idx[r["from"]], idx[r["to"]]
        ax.plot([pos[i,0],pos[j,0]],[pos[i,1],pos[j,1]], color="#9aa6b8",
                lw=0.3+r["weight"]*1.3, alpha=0.10+r["weight"]*0.40,
                zorder=1, solid_capstyle="round")
    vx = vert.set_index("name")
    for gi, g in enumerate(nodes):
        fc = FUNC_COLORS[int(vx.loc[g,"func"])]
        emph = g in top5
        ax.scatter(pos[gi,0], pos[gi,1], s=sizes[gi], color=fc, zorder=3,
                   ec="#222222" if emph else "#ffffff", lw=1.3 if emph else 0.6, alpha=0.96)
        diam = 2*np.sqrt(sizes[gi]/np.pi); fs = 5.9 if emph else 5.3
        fw = "bold" if emph else "normal"
        if emph:
            while len(g)*fs*0.62 >= diam*0.9 and fs > 4.0: fs -= 0.2
            inside = True
        else:
            inside = len(g)*fs*0.62 < diam*0.86
        if inside:
            ax.text(pos[gi,0], pos[gi,1], g, ha="center", va="center",
                    fontsize=fs, zorder=4, fontweight=fw, color="white")
        else:
            _, u = _place_label(pos, gi, radius, nodes); off = radius[gi]+0.13
            lx, ly = pos[gi,0]+u[0]*off, pos[gi,1]+u[1]*off
            ha = "left" if u[0]>0.3 else ("right" if u[0]<-0.3 else "center")
            va = "bottom" if u[1]>0.3 else ("top" if u[1]<-0.3 else "center")
            ax.text(lx, ly, g, ha=ha, va=va, fontsize=fs-0.2, zorder=4, fontweight=fw,
                    color="#222", path_effects=[patheffects.withStroke(linewidth=2.0, foreground="white")])
    ax.set_aspect("equal"); ax.axis("off"); ax.margins(0.18)
    handles = [Patch(fc=FUNC_COLORS[int(k)], label=FUNC_NAMES[int(k)]) for k in present]
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5,-0.01),
              ncol=2, fontsize=5.8, columnspacing=1.0, handletextpad=0.4)
    ax.set_title("Integrated candidate network (node size = composite score)\nBold = first five display positions; tied scores carry equal evidence",
                 fontsize=7.6, fontweight="bold", loc="left")
    fig.tight_layout()
    save(fig, "Figure9E_integrated_network")

# ============================================================ F: potential vs integration
def panel_f():
    from scipy.stats import pearsonr, spearmanr
    pot = pd.read_csv(os.path.join(RES, '12_rloop_formation_proxy/rloop_formation_potential_complete_cases.csv'))
    pot["gene"] = pot["gene"].str.upper()
    scores = load_scores()[["gene", "composite_score", "func"]]
    m = pot.merge(scores, on="gene", how="inner").reset_index(drop=True)
    m = m.loc[np.isfinite(m["potential_change"]) & np.isfinite(m["composite_score"])].copy()
    assert len(m) == 26 and m["gene"].is_unique

    r, p = pearsonr(m["potential_change"], m["composite_score"])
    rs, ps = spearmanr(m["potential_change"], m["composite_score"])

    fig, ax = plt.subplots(figsize=(6.2, 5.4))
    funcs_present = sorted(m["func"].dropna().unique())
    for fk in funcs_present:
        sub = m[m["func"] == fk]
        ax.scatter(sub["potential_change"], sub["composite_score"],
                   s=80, color=FUNC_COLORS[int(fk)], alpha=0.88,
                   edgecolors="white", linewidths=0.9, zorder=3,
                   label=FUNC_NAMES[int(fk)])
    # regression line
    z = np.polyfit(m["potential_change"], m["composite_score"], 1)
    xl = np.linspace(m["potential_change"].min() - 0.01, m["potential_change"].max() + 0.01, 100)
    ax.plot(xl, np.polyval(z, xl), color="#333", lw=1.3, ls="--", zorder=2)

    key = ["DDX21", "DHX9", "BRCA1", "PARP1", "RNASEH2A", "BCL7B", "RNASEH1"]
    for g in key:
        row = m[m["gene"] == g]
        if len(row) == 0:
            continue
        xv, yv = row["potential_change"].iloc[0], row["composite_score"].iloc[0]
        dx, dy = (7, 5)
        ax.annotate(g, (xv, yv), xytext=(dx, dy), textcoords="offset points",
                    fontsize=6.3, fontweight="bold", color="#222", zorder=5,
                    path_effects=[patheffects.withStroke(linewidth=2.2, foreground="white")])

    ax.axvline(0, color="#999", lw=0.8, ls=":")
    ax.set_xlabel("Midpoint-centered computational susceptibility proxy (Δ)", fontsize=7.4)
    ax.set_ylabel("Composite multi-omic evidence score", fontsize=7.4)
    ax.set_title("Susceptibility proxy change vs. integration score",
                 fontsize=8.2, fontweight="bold", loc="left", pad=6)
    ax.text(0.03, 0.97,
            f"Pearson r = {r:.2f},  p = {p:.2e}\nSpearman \u03c1 = {rs:.2f},  p = {ps:.2e}\nn = {len(m)} genes",
            transform=ax.transAxes, fontsize=6.6, va="top", ha="left",
            bbox=dict(boxstyle="round,pad=0.4", fc="white", ec="#cccccc", alpha=0.92))
    ax.legend(loc="lower left", fontsize=5.6, ncol=2, framealpha=0.9,
              handletextpad=0.3, columnspacing=0.8)
    fig.tight_layout()
    save(fig, "Figure9F_potential_vs_integration")

if __name__ == "__main__":
    panel_a(); panel_b(); panel_c(); panel_d(); panel_e(); panel_f()
    print("ALL FIGURE 9 PANELS DONE ->", OUT)
