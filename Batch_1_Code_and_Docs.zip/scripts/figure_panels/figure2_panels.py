# -*- coding: utf-8 -*-
"""
Figure 1 panels B-F for the R-loop cerebral I/R multi-omic study.
Outputs individual PNG (600 dpi), PDF and SVG files for each panel.
Style reference: JAHA Spondin-1 paper + npj Precision Oncology acetylation paper.
"""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
import sys
from pathlib import Path


import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.patches import Patch
from scipy import stats
import seaborn as sns

# ----------------------------------------------------------------------------
# Paths and global style
# ----------------------------------------------------------------------------
BASE = Path(ROOT / 'data/main_tables')
OUT = ROOT / 'outputs/figures/Figure2'
OUT.mkdir(parents=True, exist_ok=True)

# Unified palette (coordinated with Figure 1A)
C_UP = '#e0524d'        # upregulated / MCAO warm red
C_DOWN = '#48639a'      # downregulated / Sham cool blue
C_NS = '#cfd3d8'        # non-significant grey
C_RLOOP_EDGE = '#1a1a1a'  # black circle for R-loop genes
C_GOLD = '#d4a017'      # significance asterisk gold
C_ANIMAL = '#eaf3fb'    # animal cohort header tint
C_HUMAN = '#fff0ed'     # human cohort header tint

mpl.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size': 8,
    'axes.labelsize': 8.5,
    'axes.titlesize': 9.5,
    'xtick.labelsize': 7.5,
    'ytick.labelsize': 7.5,
    'svg.fonttype': 'none',
    'pdf.fonttype': 42,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.linewidth': 0.8,
    'xtick.major.width': 0.8,
    'ytick.major.width': 0.8,
    'legend.frameon': False,
    'figure.facecolor': 'white',
})

# Dataset metadata
DATASETS = [
    # (label, relative path, lfc_col, p_col, kind)
    ('GSE163614\nRat MCAO', '01_bulk_transcriptomics/GSE163614_DESeq2_results.csv.gz',
     'log2FoldChange', 'padj', 'animal'),
    ('GSE137482\nMouse MCAO', '01_bulk_transcriptomics/GSE137482_DESeq2_results.csv.gz',
     'log2FoldChange', 'padj', 'animal'),
    ('GSE61616\nRat MCAO', '01_bulk_transcriptomics/GSE61616_limma_results.csv.gz',
     'logFC', 'adj.P.Val', 'animal'),
    ('GSE22255\nHuman blood', '02_human_validation/GSE22255_limma_results.csv.gz',
     'logFC', 'adj.P.Val', 'human'),
    ('GSE16561\nHuman blood', '02_human_validation/GSE16561_limma_results.csv.gz',
     'logFC', 'adj.P.Val', 'human'),
]

VOLCANO_DATASETS = DATASETS[:3] + [DATASETS[4]]  # exclude GSE22255 (no sig genes)


def save_panel(fig, name):
    for ext, kw in [('png', {'dpi': 600}), ('pdf', {}), ('svg', {})]:
        fig.savefig(OUT / f'{name}.{ext}', bbox_inches='tight', facecolor='white', **kw)
    plt.close(fig)
    print(f'  saved {name}')


# ----------------------------------------------------------------------------
# Panel B: DEG count diverging horizontal bar
# ----------------------------------------------------------------------------
def panel_b():
    records = []
    for label, rel, lfc_col, p_col, kind in DATASETS:
        df = pd.read_csv(BASE / rel)
        sig = df[df[p_col] < 0.05]
        up = int((sig[lfc_col] > 0).sum())
        down = int((sig[lfc_col] < 0).sum())
        records.append({'dataset': label.replace('\n', ' '), 'up': up, 'down': down, 'kind': kind})
    deg = pd.DataFrame(records)

    fig, ax = plt.subplots(figsize=(5.2, 2.6))
    y = np.arange(len(deg))
    h = 0.62

    # down bars to the left, up bars to the right
    ax.barh(y, -deg['down'], height=h, color=C_DOWN, label='Downregulated', zorder=3)
    ax.barh(y, deg['up'], height=h, color=C_UP, label='Upregulated', zorder=3)

    for i, row in deg.iterrows():
        if row['down'] > 0:
            ax.text(-row['down'] - max(deg['down']) * 0.015, i, f"{row['down']}",
                    ha='right', va='center', fontsize=7.5, color=C_DOWN, fontweight='bold')
        else:
            ax.text(-max(deg['down']) * 0.015, i, '0 (NS)',
                    ha='right', va='center', fontsize=6.8, color='#999', style='italic')
        if row['up'] > 0:
            ax.text(row['up'] + max(deg['up']) * 0.015, i, f"{row['up']}",
                    ha='left', va='center', fontsize=7.5, color=C_UP, fontweight='bold')
        elif row['down'] == 0:
            ax.text(max(deg['up']) * 0.015, i, '', ha='left', va='center')

    ax.axvline(0, color='#555', linewidth=0.8)
    ax.set_yticks(y)
    ax.set_yticklabels(deg['dataset'], fontsize=7.5)
    ax.set_xlabel('Number of DEGs (adj. p < 0.05)')
    xmax = max(deg['up'].max(), deg['down'].max()) * 1.18
    ax.set_xlim(-xmax, xmax)
    # positive tick labels on both sides
    xt = ax.get_xticks()
    ax.set_xticks(xt)
    ax.set_xticklabels([f'{abs(int(t))}' for t in xt])
    ax.legend(loc='lower right', fontsize=7, ncol=2, bbox_to_anchor=(1.0, 1.02),
              columnspacing=1.2, handlelength=1.2)
    ax.grid(axis='x', linewidth=0.4, color='#e8eaed', zorder=0)
    save_panel(fig, 'Figure2A_DEG_counts')
    return deg


# ----------------------------------------------------------------------------
# Panel C: Volcano plots (2x2)
# ----------------------------------------------------------------------------
def _load_deg(rel, lfc_col, p_col):
    df = pd.read_csv(BASE / rel)
    df = df.rename(columns={lfc_col: 'log2FC', p_col: 'padj'})
    df = df[['gene', 'log2FC', 'padj']].dropna(subset=['log2FC', 'padj']).copy()
    df['padj'] = df['padj'].clip(lower=1e-50)
    df['neglog10p'] = -np.log10(df['padj'])
    return df


def _rloop_gene_set():
    cross = pd.read_csv(BASE / '01_bulk_transcriptomics/rloop_genes_cross_dataset.csv')
    mouse = set(cross['gene'].dropna())
    human = set(cross['gene_human'].dropna())
    return mouse, human


def panel_c():
    mouse_rloop, human_rloop = _rloop_gene_set()
    # Manual label offsets (dx, dy) in points to avoid overlap; only significant genes labelled.
    label_offset = {
        'GSE163614 Rat MCAO': {'Ddx21': (4, 4)},
        'GSE137482 Mouse MCAO': {'Pif1': (-38, 6), 'Brca1': (4, 4)},
        'GSE61616 Rat MCAO': {
            'Fancd2': (4, 4), 'Parp1': (-42, 2), 'Brca2': (16, 14),
            'Rnaseh2b': (6, -14), 'Xrn2': (-32, 6), 'Ddx3x': (6, -12),
            'Bcl7b': (-38, 0), 'Ddx1': (-34, -14), 'Thoc5': (6, 6),
        },
        'GSE16561 Human blood': {
            'THOC3': (-6, 6), 'RNASEH1': (4, 4), 'ATM': (-30, -2),
            'THOC1': (-32, -12), 'BCL7B': (4, -12), 'TOP1': (4, 2),
            'DDX3X': (4, 4),
        },
    }

    fig, axes = plt.subplots(2, 2, figsize=(7.2, 6.4))
    axes = axes.flatten()

    for ax, (label, rel, lfc_col, p_col, kind) in zip(axes, VOLCANO_DATASETS):
        df = _load_deg(rel, lfc_col, p_col)
        rloop_set = human_rloop if kind == 'human' else mouse_rloop
        short = label.replace('\n', ' ')

        sig_up = (df['padj'] < 0.05) & (df['log2FC'] > 0)
        sig_down = (df['padj'] < 0.05) & (df['log2FC'] < 0)
        is_rloop = df['gene'].isin(rloop_set)

        # cap y for display
        ycap = min(df['neglog10p'].quantile(0.999) * 1.15, 60)
        df['y_disp'] = df['neglog10p'].clip(upper=ycap)

        ax.scatter(df.loc[~sig_up & ~sig_down, 'log2FC'],
                   df.loc[~sig_up & ~sig_down, 'y_disp'],
                   s=2.5, c=C_NS, alpha=0.55, linewidths=0, rasterized=True)
        ax.scatter(df.loc[sig_down, 'log2FC'], df.loc[sig_down, 'y_disp'],
                   s=3.5, c=C_DOWN, alpha=0.65, linewidths=0, rasterized=True)
        ax.scatter(df.loc[sig_up, 'log2FC'], df.loc[sig_up, 'y_disp'],
                   s=3.5, c=C_UP, alpha=0.65, linewidths=0, rasterized=True)

        # R-loop genes: hollow black circles on top (all 32)
        rl = df[is_rloop]
        ax.scatter(rl['log2FC'], rl['y_disp'], s=42, facecolors='none',
                   edgecolors=C_RLOOP_EDGE, linewidths=1.0, zorder=5)

        # label ONLY significant R-loop genes, with manual offsets
        rl_sig = rl[rl['padj'] < 0.05]
        offsets = label_offset.get(short, {})
        for _, gr in rl_sig.iterrows():
            g = gr['gene']
            gx, gy = gr['log2FC'], gr['y_disp']
            dx, dy = offsets.get(g, (4, 4))
            ax.annotate(g, (gx, gy), fontsize=6.4, fontweight='bold',
                        xytext=(dx, dy), textcoords='offset points',
                        color='#111', zorder=6,
                        bbox=dict(boxstyle='round,pad=0.12', fc='white',
                                  ec='none', alpha=0.75))

        ax.axhline(-np.log10(0.05), color='#666', linestyle='--', linewidth=0.7, zorder=4)
        ax.set_title(short, fontsize=8.5, fontweight='bold', loc='left')
        ax.set_xlabel('log$_2$ fold change (MCAO / Stroke vs control)')
        ax.set_ylabel('−log$_{10}$(adj. p)')
        ax.set_ylim(0, ycap * 1.05)
        # ensure labelled genes fit within xlim
        base_xlim = np.nanpercentile(df['log2FC'].abs(), 99.5) * 1.1
        labelled_x = rl_sig['log2FC'].abs().max() if len(rl_sig) else 0
        xlim = max(base_xlim, labelled_x * 1.25)
        ax.set_xlim(-xlim, xlim)
        ax.grid(linewidth=0.35, color='#eef0f2', zorder=0)

    # shared legend
    handles = [
        plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=C_NS, markersize=5, label='Not significant'),
        plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=C_UP, markersize=5, label='Upregulated'),
        plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=C_DOWN, markersize=5, label='Downregulated'),
        plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='none', markeredgecolor=C_RLOOP_EDGE,
                   markeredgewidth=1.0, markersize=7, label='R-loop-associated gene'),
    ]
    fig.legend(handles=handles, loc='upper center', ncol=4, fontsize=7,
               bbox_to_anchor=(0.5, 1.01), columnspacing=1.4, handletextpad=0.4)
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    save_panel(fig, 'Figure2B_volcano')


# ----------------------------------------------------------------------------
# Panel D: 32 genes x 5 datasets annotated heatmap with numbers + asterisks
# ----------------------------------------------------------------------------
def _build_combined_matrix():
    cross = pd.read_csv(BASE / '01_bulk_transcriptomics/rloop_genes_cross_dataset.csv')
    human = pd.read_csv(BASE / '02_human_validation/rloop_genes_human.csv')
    m = cross.merge(human, left_on='gene_human', right_on='gene', suffixes=('', '_h'))

    lfc_map = {
        'GSE163614': ('GSE163614_log2FC', 'GSE163614_padj'),
        'GSE137482': ('GSE137482_log2FC', 'GSE137482_padj'),
        'GSE61616': ('GSE61616_log2FC', 'GSE61616_padj'),
        'GSE22255': ('GSE22255_logFC', 'GSE22255_padj'),
        'GSE16561': ('GSE16561_logFC', 'GSE16561_padj'),
    }
    lfc_df = pd.DataFrame({'gene': m['gene']})
    padj_df = pd.DataFrame({'gene': m['gene']})
    for ds, (lc, pc) in lfc_map.items():
        lfc_df[ds] = m[lc]
        padj_df[ds] = m[pc]

    # sort rows by mean animal log2FC
    animal_cols = ['GSE163614', 'GSE137482', 'GSE61616']
    order = lfc_df[animal_cols].mean(axis=1).sort_values(ascending=False).index
    lfc_df = lfc_df.loc[order].reset_index(drop=True)
    padj_df = padj_df.loc[order].reset_index(drop=True)
    return lfc_df.set_index('gene'), padj_df.set_index('gene')


def panel_d():
    lfc_df, padj_df = _build_combined_matrix()
    cols = ['GSE163614', 'GSE137482', 'GSE61616', 'GSE22255', 'GSE16561']
    col_labels = ['GSE163614\nRat MCAO', 'GSE137482\nMouse MCAO', 'GSE61616\nRat MCAO',
                  'GSE22255\nHuman blood', 'GSE16561\nHuman blood']

    fig, ax = plt.subplots(figsize=(5.6, 9.4))
    # fixed vmax: Pif1 (6.13) is an outlier, cap colour at 2.5 while showing true value as text
    vmax = 2.5
    cmap = sns.diverging_palette(240, 12, s=75, l=50, as_cmap=True)

    sns.heatmap(lfc_df[cols], ax=ax, cmap=cmap, center=0,
                vmin=-vmax, vmax=vmax, linewidths=0.4, linecolor='white',
                cbar_kws={'label': 'log$_2$ fold change', 'shrink': 0.35, 'pad': 0.02},
                xticklabels=col_labels, yticklabels=True,
                annot=False, square=False)

    # annotate numeric values + gold asterisks
    for i, gene in enumerate(lfc_df.index):
        for j, ds in enumerate(cols):
            val = lfc_df.loc[gene, ds]
            pv = padj_df.loc[gene, ds]
            if pd.isna(val):
                ax.text(j + 0.5, i + 0.5, '—', ha='center', va='center', fontsize=6.5, color='#999')
                continue
            txt = f'{val:.2f}'
            if pd.notna(pv) and pv < 0.05:
                txt += ' *'
                ax.text(j + 0.5, i + 0.5, txt, ha='center', va='center',
                        fontsize=6.3, fontweight='bold', color=C_GOLD)
            else:
                # dark/light text based on value magnitude
                ax.text(j + 0.5, i + 0.5, txt, ha='center', va='center', fontsize=6.3,
                        color='#222' if abs(val) < vmax * 0.55 else 'white')

    # top group bar (animal vs human)
    for j, kind in enumerate(['animal'] * 3 + ['human'] * 2):
        ax.add_patch(mpl.patches.Rectangle((j, -1.0), 1, 1.0,
                     facecolor=C_ANIMAL if kind == 'animal' else C_HUMAN,
                     edgecolor='white', linewidth=0.5, clip_on=False))
    ax.text(1.5, -0.5, 'Animal MCAO models', ha='center', va='center', fontsize=7,
            fontweight='bold', color='#2c4a73', clip_on=False)
    ax.text(4.0, -0.5, 'Human stroke blood', ha='center', va='center', fontsize=7,
            fontweight='bold', color='#a8443c', clip_on=False)

    ax.tick_params(axis='y', labelsize=7)
    ax.tick_params(axis='x', labelsize=7)
    ax.set_xlabel('')
    ax.set_ylabel('')
    plt.setp(ax.get_yticklabels(), rotation=0, fontstyle='italic')
    # asterisk note above the group bar
    ax.text(0.0, -1.35, '* adj. p < 0.05', transform=ax.transData, fontsize=6.8, color=C_GOLD,
            fontweight='bold', va='center', clip_on=False)
    save_panel(fig, 'Figure2C_heatmap')


# ----------------------------------------------------------------------------
# Panel E: UpSet (animal sig overlap) + direction-consistent heatmap
# ----------------------------------------------------------------------------
def panel_e():
    from itertools import combinations
    cross = pd.read_csv(BASE / '01_bulk_transcriptomics' / 'rloop_genes_cross_dataset.csv')
    set_names = ['GSE163614', 'GSE137482', 'GSE61616']
    animal_sets = {
        'GSE163614': set(cross.loc[cross['GSE163614_padj'] < 0.05, 'gene']),
        'GSE137482': set(cross.loc[cross['GSE137482_padj'] < 0.05, 'gene']),
        'GSE61616': set(cross.loc[cross['GSE61616_padj'] < 0.05, 'gene']),
    }

    # Build UpSet intersection sizes (only non-empty subsets, sorted by size desc)
    subsets = []
    for r in range(1, 4):
        for combo in combinations(set_names, r):
            genes_in = set.intersection(*[animal_sets[n] for n in combo])
            genes_out = set()
            for n in set_names:
                if n not in combo:
                    genes_out |= animal_sets[n]
            exact = genes_in - genes_out
            if len(exact) > 0:
                subsets.append((combo, len(exact)))
    subsets.sort(key=lambda x: -x[1])
    # guarantee each single set shows even if zero
    present_combos = {c for c, _ in subsets}
    for n in set_names:
        if (n,) not in present_combos:
            subsets.append(((n,), 0))
    subsets.sort(key=lambda x: -x[1])

    # direction-consistent genes heatmap
    cons_mask = cross['direction_consistent'].fillna(False).astype(bool)
    cons = cross[cons_mask].copy()
    lfc_cols = ['GSE163614_log2FC', 'GSE137482_log2FC', 'GSE61616_log2FC']
    p_cols = ['GSE163614_padj', 'GSE137482_padj', 'GSE61616_padj']
    cons = cons.sort_values(by=lfc_cols, ascending=False).reset_index(drop=True)
    hm = cons[lfc_cols].set_index(cons['gene'])
    hm_p = cons[p_cols].set_index(cons['gene'])

    fig = plt.figure(figsize=(9.6, 5.8))
    outer = GridSpec(1, 2, width_ratios=[1.0, 1.05], wspace=0.38, figure=fig)

    # --- left: hand-drawn UpSet ---
    gs_l = outer[0, 0].subgridspec(2, 1, height_ratios=[1.0, 0.62], hspace=0.08)
    ax_bar = fig.add_subplot(gs_l[0])
    ax_dot = fig.add_subplot(gs_l[1])

    n_sub = len(subsets)
    x = np.arange(n_sub)
    counts_v = [c for _, c in subsets]
    ax_bar.bar(x, counts_v, color='#48639a', width=0.6, zorder=3)
    for xi, c in zip(x, counts_v):
        ax_bar.text(xi, c + 0.15, str(c), ha='center', va='bottom', fontsize=7.5, fontweight='bold')
    ax_bar.set_xticks([])
    ax_bar.set_ylabel('Number of\nsignificant genes', fontsize=7.5)
    ax_bar.set_ylim(0, max(counts_v) * 1.25 + 0.5)
    ax_bar.set_title('Overlap of significant R-loop genes\nacross animal MCAO models (adj. p < 0.05)',
                     fontsize=8.5, fontweight='bold')
    ax_bar.grid(axis='y', linewidth=0.35, color='#eef0f2', zorder=0)

    # dot matrix
    ypos = {n: i for i, n in enumerate(set_names)}
    ax_dot.set_ylim(-0.6, 2.6)
    ax_dot.set_xlim(-0.6, n_sub - 0.4)
    for xi, (combo, _) in enumerate(subsets):
        for n in set_names:
            y = ypos[n]
            active = n in combo
            ax_dot.scatter(xi, y, s=70 if active else 42,
                           c='#48639a' if active else '#d9dde2',
                           edgecolors='#48639a' if active else '#d9dde2',
                           linewidths=0.8, zorder=3)
        # connect active dots
        active_ys = [ypos[n] for n in combo]
        if len(active_ys) > 1:
            ax_dot.plot([xi, xi], [min(active_ys), max(active_ys)],
                        color='#48639a', linewidth=1.4, zorder=2)
    ax_dot.set_yticks(list(ypos.values()))
    ax_dot.set_yticklabels(list(ypos.keys()), fontsize=7.2)
    ax_dot.set_xticks([])
    ax_dot.invert_yaxis()
    for s in ['top', 'right', 'bottom']:
        ax_dot.spines[s].set_visible(False)
    ax_dot.tick_params(axis='both', length=0)

    # --- right: consistent-direction heatmap ---
    ax_hm = fig.add_subplot(outer[0, 1])
    cmap = sns.diverging_palette(240, 12, s=75, l=50, as_cmap=True)
    vmax = 2.5
    sns.heatmap(hm, ax=ax_hm, cmap=cmap, center=0, vmin=-vmax, vmax=vmax,
                linewidths=0.4, linecolor='white',
                cbar_kws={'label': 'log$_2$ fold change', 'shrink': 0.5, 'pad': 0.03},
                xticklabels=['GSE163614', 'GSE137482', 'GSE61616'],
                yticklabels=True, annot=False)
    ax_hm.set_ylabel('')
    for i, gene in enumerate(hm.index):
        for j in range(3):
            val = hm.iloc[i, j]
            pv = hm_p.iloc[i, j]
            if pd.isna(val):
                ax_hm.text(j + 0.5, i + 0.5, '—', ha='center', va='center', fontsize=6.5, color='#999')
                continue
            star = ' *' if pd.notna(pv) and pv < 0.05 else ''
            color = C_GOLD if star else ('#222' if abs(val) < vmax * 0.55 else 'white')
            fw = 'bold' if star else 'normal'
            ax_hm.text(j + 0.5, i + 0.5, f'{val:.2f}{star}', ha='center', va='center',
                       fontsize=6.3, color=color, fontweight=fw)
    ax_hm.set_title('14 genes with concordant direction\nacross animal models',
                    fontsize=8.5, fontweight='bold')
    plt.setp(ax_hm.get_yticklabels(), rotation=0, fontstyle='italic', fontsize=7)
    ax_hm.tick_params(axis='x', labelsize=6.8)
    save_panel(fig, 'Figure2D_upset_consistent')


# ----------------------------------------------------------------------------
# Panel F: boxplot + jitter for 6 candidate genes (GSE163614)
# ----------------------------------------------------------------------------
def panel_f():
    expr = pd.read_csv(BASE / '01_bulk_transcriptomics/GSE163614_normalized_expr.csv.gz')
    expr = expr.rename(columns={'Unnamed: 0': 'gene'}).set_index('gene')
    mcao_cols = [c for c in expr.columns if 'MCAO' in c]
    sham_cols = [c for c in expr.columns if 'Sham' in c]

    candidates = ['Ddx21', 'Bcl7b', 'Brca1', 'Parp1', 'Rnaseh1', 'Ddx3x']
    rng = np.random.default_rng(42)

    fig, axes = plt.subplots(2, 3, figsize=(7.4, 5.2))
    axes = axes.flatten()

    for ax, gene in zip(axes, candidates):
        row = expr.loc[gene]
        sham_vals = row[sham_cols].values.astype(float)
        mcao_vals = row[mcao_cols].values.astype(float)

        # Mann-Whitney U
        u, p = stats.mannwhitneyu(mcao_vals, sham_vals, alternative='two-sided')

        positions = [0, 1]
        data = [sham_vals, mcao_vals]
        bp = ax.boxplot(data, positions=positions, widths=0.42, patch_artist=True,
                        showfliers=False, zorder=3,
                        medianprops=dict(color='#222', linewidth=1.2),
                        whiskerprops=dict(linewidth=0.9, color='#444'),
                        capprops=dict(linewidth=0.9, color='#444'))
        for patch, c in zip(bp['boxes'], [C_DOWN, C_UP]):
            patch.set_facecolor(c)
            patch.set_alpha(0.30)
            patch.set_edgecolor(c)
            patch.set_linewidth(1.1)

        for x, vals, c in [(0, sham_vals, C_DOWN), (1, mcao_vals, C_UP)]:
            jitter = rng.uniform(-0.09, 0.09, size=len(vals))
            ax.scatter(np.full(len(vals), x) + jitter, vals, s=22, c=c,
                       alpha=0.9, zorder=5, edgecolors='white', linewidths=0.5)

        # p-value annotation
        ptext = 'p = 0.10' if abs(p - 0.1) < 0.011 else f'p = {p:.2f}'
        ytop = max(sham_vals.max(), mcao_vals.max())
        ybot = min(sham_vals.min(), mcao_vals.min())
        yr = ytop - ybot
        ax.plot([0, 0, 1, 1], [ytop + yr * 0.10, ytop + yr * 0.18, ytop + yr * 0.18, ytop + yr * 0.10],
                color='#333', linewidth=0.8)
        ax.text(0.5, ytop + yr * 0.20, ptext, ha='center', va='bottom', fontsize=6.8)

        ax.set_xticks(positions)
        ax.set_xticklabels(['Sham', 'MCAO'], fontsize=7.2)
        ax.set_title(gene, fontsize=8.5, fontweight='bold', fontstyle='italic')
        ax.set_ylabel('Normalized expression', fontsize=7.2)
        ax.set_xlim(-0.55, 1.55)
        ax.grid(axis='y', linewidth=0.35, color='#eef0f2', zorder=0)

    fig.tight_layout()
    save_panel(fig, 'Figure2E_boxplots')


# ----------------------------------------------------------------------------
if __name__ == '__main__':
    print('Panel B...'); deg = panel_b()
    print(deg.to_string())
    print('Panel C...'); panel_c()
    print('Panel D...'); panel_d()
    print('Panel E...'); panel_e()
    print('Panel F...'); panel_f()
    print('\nAll Figure 2 panels done ->', OUT)
