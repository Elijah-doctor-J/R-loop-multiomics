# -*- coding: utf-8 -*-
"""Figure 1A (v2): study design & multi-omic workflow.
Four clear layers: (1) 9 public datasets across 4 omics types ->
(2) curated 32 R-loop gene set -> (3) six parallel analyses mapped to Figures ->
(4) 8-dimension multi-omic integration -> core candidate network.
Uses the py3.13-compatible bundle (python_pkgs)."""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
import sys
from pathlib import Path

import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle

OUT = ROOT / 'outputs/figures/Figure1'
OUT.mkdir(parents=True, exist_ok=True)

mpl.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size': 8,
    'svg.fonttype': 'none',
    'pdf.fonttype': 42,
})

# ---- unified, restrained palette ----
INK      = '#1b2430'   # primary text
SUB      = '#46515c'   # secondary text
LINE     = '#9aa7b4'   # neutral arrows / borders
NAVY     = '#48639a'   # primary brand (matches panels B-F)
NAVY_F   = '#eef2f8'
# four omics accents (low saturation)
C_BULK,  C_BULK_F  = '#3f6ea8', '#eaf1f9'
C_SC,    C_SC_F    = '#2f9e8f', '#e8f6f3'
C_ATAC,  C_ATAC_F  = '#7a6fb0', '#f0eef8'
C_HICHIP,C_HICHIP_F= '#a9804f', '#f8f2e9'
ACCENT,  ACCENT_F  = '#d9534a', '#fdf0ee'   # core gene set / integration
STAGE_F  = '#f6f8fa'


def rbox(ax, x, y, w, h, fc, ec, lw=1.3, rs=0.012, z=1):
    p = FancyBboxPatch((x, y), w, h,
                       boxstyle=f'round,pad=0.004,rounding_size={rs}',
                       linewidth=lw, edgecolor=ec, facecolor=fc,
                       transform=ax.transAxes, clip_on=False, zorder=z)
    ax.add_patch(p)
    return p


def txt(ax, x, y, s, size=8, color=INK, weight='normal', style='normal',
        ha='center', va='center', ls=1.25, z=3, bbox=None):
    return ax.text(x, y, s, fontsize=size, color=color, fontweight=weight,
                   fontstyle=style, ha=ha, va=va, linespacing=ls,
                   transform=ax.transAxes, zorder=z, clip_on=False, bbox=bbox)


def down_arrow(ax, x, y0, y1, color='#6b7689'):
    ax.add_patch(FancyArrowPatch((x, y0), (x, y1), transform=ax.transAxes,
                 arrowstyle='-|>', mutation_scale=28, linewidth=2.8,
                 color=color, shrinkA=4, shrinkB=2, zorder=4, clip_on=False))


def stage_num(ax, x, y, n, color=NAVY):
    """numbered circle for the left step axis (screen-perfect circle via scatter)."""
    ax.scatter([x], [y], s=320, facecolor=color, edgecolor='white', linewidth=1.5,
               transform=ax.transAxes, zorder=6, clip_on=False)
    txt(ax, x, y, str(n), size=9.2, color='white', weight='bold', z=7)


def stage_tag(ax, x, y, n, title, subtitle=''):
    """numbered stage marker at the left of a layer."""
    stage_num(ax, x, y, n)
    txt(ax, x + 0.022, y + 0.002, title, size=10.5, color=INK, weight='bold', ha='left')
    if subtitle:
        txt(ax, x + 0.022, y - 0.017, subtitle, size=7.4, color=SUB, ha='left', style='italic')


fig = plt.figure(figsize=(14, 10.6), facecolor='white')
ax = fig.add_axes([0, 0, 1, 1])
ax.set_axis_off()
ax.set_xlim(0, 1); ax.set_ylim(0, 1)

# panel title (no panel letter — this is a methods figure, not a Figure 1 panel)
txt(ax, 0.5, 0.972, 'Study design and multi-omic analysis workflow',
    size=15.5, color='white', weight='bold',
    bbox=dict(boxstyle='round,pad=0.65', facecolor=NAVY, edgecolor='none'))

# =====================================================================
# LAYER 1 : public multi-omic datasets
# =====================================================================
L1_top, L1_bot = 0.918, 0.662
rbox(ax, 0.018, L1_bot, 0.964, L1_top - L1_bot, STAGE_F, '#d7dee6', lw=1.0, rs=0.014)
stage_tag(ax, 0.045, 0.895, 1, 'Public multi-omic datasets',
          'nine independent datasets spanning four molecular layers')

# card geometry inside layer 1
cy_b, cy_t = 0.678, 0.835          # card bottom / top
def dataset_card(x, w, edge, face, title, count, body_lines, body_size=7.3, title_size=8.6):
    rbox(ax, x, cy_b, w, cy_t - cy_b, face, edge, lw=1.4, rs=0.012)
    txt(ax, x + w/2, cy_t - 0.020, title, size=title_size, color=edge, weight='bold')
    txt(ax, x + w/2, cy_t - 0.040, count, size=7.0, color=SUB, style='italic')
    txt(ax, x + w/2, (cy_b + cy_t)/2 - 0.028, body_lines, size=body_size,
        color=INK, ls=1.32)

# --- Bulk (wide card, 5 datasets in two sub-columns: animal | human) ---
bx, bw = 0.038, 0.372
rbox(ax, bx, cy_b, bw, cy_t - cy_b, C_BULK_F, C_BULK, lw=1.5, rs=0.012)
txt(ax, bx + bw/2, cy_t - 0.018, 'Bulk transcriptomics', size=9.2, color=C_BULK, weight='bold')
txt(ax, bx + bw/2, cy_t - 0.038, 'five cohorts · three animal models + two human', size=6.9, color=SUB, style='italic')
# left sub-column: animal models
lx = bx + 0.011
txt(ax, lx, cy_t - 0.062, 'Animal MCAO models (3)', size=7.1, color=NAVY, weight='bold', ha='left')
for i, r_ in enumerate(['GSE163614 · Rat · RNA-seq',
                        'GSE137482 · Mouse · RNA-seq',
                        'GSE61616 · Rat · microarray']):
    txt(ax, lx, cy_t - 0.085 - i*0.0235, r_, size=6.8, color=INK, ha='left')
# right sub-column: human blood
rx = bx + 0.200
txt(ax, rx, cy_t - 0.062, 'Human stroke blood (2)', size=7.1, color=ACCENT, weight='bold', ha='left')
for i, r_ in enumerate(['GSE22255 · microarray',
                        'GSE16561 · 39 vs 24 ctrl']):
    txt(ax, rx, cy_t - 0.085 - i*0.0235, r_, size=6.8, color=INK, ha='left')

# --- scRNA ---
dataset_card(0.428, 0.158, C_SC, C_SC_F, 'Single-cell RNA-seq', 'two mouse MCAO cohorts',
             'GSE174574\nMCAO vs Sham · 24 h\n\nGSE225948 · time course\nSham / Day 2 / Day 14\n43,269 cells · 13 cell types')
# --- snATAC ---
dataset_card(0.602, 0.158, C_ATAC, C_ATAC_F, 'snATAC-seq', 'chromatin accessibility',
             'Figshare 25558785\nmouse MCAO time series\n\n7 timepoints\nSham → 14 days\n32 curated (31 detected)')
# --- HiChIP ---
dataset_card(0.776, 0.186, C_HICHIP, C_HICHIP_F, 'H3K27ac HiChIP', 'microglia-specific',
             'GSE319240\nmicroglia · Sham vs Day 6\n\n19,061 → 42,905 called loops\n(2.25× in the Day-6 file)\nenhancer–gene contacts')

down_arrow(ax, 0.5, 0.662, 0.628)

# =====================================================================
# LAYER 2 : curated R-loop gene set (central hub)
# =====================================================================
L2_top, L2_bot = 0.628, 0.520
rbox(ax, 0.16, L2_bot, 0.68, L2_top - L2_bot, ACCENT_F, ACCENT, lw=1.8, rs=0.020)
stage_num(ax, 0.045, (L2_top + L2_bot)/2, 2, color=ACCENT)
txt(ax, 0.5, 0.598, 'Curated R-loop-associated gene set  —  32 genes in six functional modules',
    size=10.6, color=ACCENT, weight='bold')
txt(ax, 0.5, 0.558,
    'RNase H complexes   ·   DNA–RNA helicases   ·   topoisomerases   ·   DNA-damage response   ·   RNA processing & export',
    size=8.0, color=INK)
txt(ax, 0.5, 0.534,
    'orthology-mapped across rat / mouse / human; tested in every dataset',
    size=7.2, color=SUB, style='italic')

down_arrow(ax, 0.5, 0.520, 0.486)

# =====================================================================
# LAYER 3 : six parallel analyses, mapped to figures
# =====================================================================
L3_top, L3_bot = 0.486, 0.255
rbox(ax, 0.018, L3_bot, 0.964, L3_top - L3_bot, STAGE_F, '#d7dee6', lw=1.0, rs=0.014)
stage_tag(ax, 0.045, 0.462, 3, 'Multi-layer analyses',
          'six parallel analytical modules')

mods = [
    ('Multi-cohort\nDE analysis', 'Five-cohort DEGs\n32-gene focused view\ncross-dataset direction\nconsistency (UpSet)'),
    ('Functional\nenrichment', 'GO / KEGG / GSEA\ninflammatory, DNA-damage\n& RNA-processing\nprograms'),
    ('Co-expression\n& PPI network', 'WGCNA modules (kME)\nSTRING / Cytoscape\ncentrality-based\nhub prioritization'),
    ('Single-cell\nmapping', 'Cell composition shifts\ncell-type-specific DE\nmicroglia-focused\nsignature'),
    ('Chromatin\ndynamics', 'snATAC time / cell-type\naccessibility trajectories\nformation-potential\nproxy score'),
    ('Enhancer\ninteractions', 'H3K27ac HiChIP loops\ndifferential contacts\nenhancer–gene\nregulatory context'),
]
n = 6
gap = 0.012
total_w = 0.964 - 2*0.020
mw = (total_w - (n-1)*gap) / n
mx0 = 0.038
my_b, my_t = 0.270, 0.395
for i, (t, b) in enumerate(mods):
    x = mx0 + i*(mw+gap)
    rbox(ax, x, my_b, mw, my_t-my_b, 'white', NAVY, lw=1.4, rs=0.012)
    # top accent bar
    rbox(ax, x, my_t-0.028, mw, 0.028, NAVY, NAVY, lw=0, rs=0.006)
    txt(ax, x+mw/2, my_t-0.014, t, size=8.4, color='white', weight='bold', ls=1.1)
    txt(ax, x+mw/2, (my_b + my_t - 0.028)/2 + 0.002, b, size=7.15, color=SUB, ls=1.3)

down_arrow(ax, 0.5, 0.255, 0.220)

# =====================================================================
# LAYER 4 : integration
# =====================================================================
L4_top, L4_bot = 0.220, 0.052
rbox(ax, 0.10, L4_bot, 0.80, L4_top-L4_bot, NAVY, NAVY, lw=1.5, rs=0.018)
stage_num(ax, 0.045, (L4_top + L4_bot)/2, 4)
txt(ax, 0.5, 0.160, 'Eight-dimension multi-omic evidence integration',
    size=10.8, color='white', weight='bold')
txt(ax, 0.5, 0.128,
    'bulk significance · peripheral-blood support · direction consistency · WGCNA · PPI · scRNA-seq · snATAC-seq · HiChIP',
    size=7.6, color='#dde5f0')
txt(ax, 0.5, 0.096,
    'Prioritized candidate network; see Figure 9 and Table S4',
    size=9.0, color='white', weight='bold')

for ext, kw in [('png', {'dpi': 600}), ('pdf', {}), ('svg', {})]:
    fig.savefig(OUT / f'Figure1_study_design_workflow.{ext}', bbox_inches='tight', facecolor='white', **kw)
plt.close(fig)
print('saved', OUT / 'Figure1_study_design_workflow.png')
