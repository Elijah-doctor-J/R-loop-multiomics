# -*- coding: utf-8 -*-
"""
Figure 3 (R-loop SCI paper): functional enrichment panels.
All quantitative values are read live from the enrichment result CSVs; nothing is hard-coded.
The 32-gene functional classification is provided in manuscript Table 1.
Outputs: results/figures/Figure3_panels/Figure3A, 3B, 3D, 3E  (PNG 600dpi + PDF + SVG)
"""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
import sys, os
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle

# ---------------------------------------------------------------------------- setup
mpl.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['DejaVu Sans'],
    'font.size': 7,
    'axes.spines.right': False,
    'axes.spines.top': False,
    'axes.linewidth': 0.8,
    'xtick.major.width': 0.8, 'ytick.major.width': 0.8,
    'xtick.major.size': 3, 'ytick.major.size': 3,
    'svg.fonttype': 'none', 'pdf.fonttype': 42,
    'legend.frameon': False,
})
C_UP, C_DOWN, C_GOLD = '#e0524d', '#48639a', '#d4a017'
ENR = ROOT / 'data/main_tables/03_functional_enrichment'
OUT = ROOT / 'outputs/figures/Figure3'
os.makedirs(OUT, exist_ok=True)
ANIMAL = ['GSE163614', 'GSE137482', 'GSE61616']
ANIMAL_LABEL = ['GSE163614\n(Rat, MCAO/R)', 'GSE137482\n(Mouse, pMCAO)', 'GSE61616\n(Rat, MCAO/R)']
ALL5 = ['GSE163614', 'GSE137482', 'GSE61616', 'GSE16561', 'GSE22255']
ALL5_LABEL = ['GSE163614\nRat brain', 'GSE137482\nMouse brain', 'GSE61616\nRat brain',
              'GSE16561\nHuman blood', 'GSE22255\nHuman blood']



def read_csv(path, *args, **kwargs):
    path = Path(path)
    if not path.exists() and path.with_name(path.name + '.gz').exists():
        path = path.with_name(path.name + '.gz')
    return pd.read_csv(path, *args, **kwargs)

def save(fig, name):
    for ext in ['png', 'pdf', 'svg']:
        fig.savefig(os.path.join(OUT, name + '.' + ext),
                    dpi=600 if ext == 'png' else None, bbox_inches='tight')
    plt.close(fig)
    print('saved', name)


def go_ora(ds, dirc):
    d = read_csv(os.path.join(ENR, f'{ds}_GO_BP_{dirc}.csv'))
    return d.set_index('Description')


def gsea(ds):
    return read_csv(os.path.join(ENR, f'{ds}_GSEA_GO.csv')).set_index('Description')


GSEA = {ds: gsea(ds) for ds in ALL5 if os.path.exists(os.path.join(ENR, f'{ds}_GSEA_GO.csv')) or os.path.exists(os.path.join(ENR, f'{ds}_GSEA_GO.csv.gz'))}


def wrap(t, n=34):
    """simple label wrap by words"""
    words, lines, cur = t.split(), [], ''
    for w in words:
        if len(cur) + len(w) + 1 <= n:
            cur = (cur + ' ' + w).strip()
        else:
            lines.append(cur); cur = w
    if cur: lines.append(cur)
    return '\n'.join(lines)


# ============================================================ Panel A / B : cross-cohort GO dotplot
TERMS_UP = [
    'regulation of inflammatory response', 'leukocyte migration', 'myeloid leukocyte activation',
    'leukocyte cell-cell adhesion', 'cell activation involved in immune response',
    'positive regulation of innate immune response', 'cell chemotaxis',
    'regulation of vasculature development', 'regulation of angiogenesis', 'wound healing']
TERMS_DOWN = [
    'regulation of synapse structure or activity', 'regulation of synapse organization',
    'postsynapse organization', 'synapse assembly', 'neurotransmitter transport',
    'synaptic vesicle cycle', 'dendrite development', 'learning or memory',
    'potassium ion transport', 'vesicle-mediated transport in synapse']


def panel_go_dot(terms, direction, fname, base_color):
    tables = {ds: go_ora(ds, direction) for ds in ANIMAL}
    # matrix of -log10 padj and Count
    n_t, n_d = len(terms), len(ANIMAL)
    lp = np.full((n_t, n_d), np.nan); cnt = np.full((n_t, n_d), np.nan)
    for i, t in enumerate(terms):
        for j, ds in enumerate(ANIMAL):
            if t in tables[ds].index:
                r = tables[ds].loc[t]
                if isinstance(r, pd.DataFrame): r = r.iloc[0]
                p = max(r['p.adjust'], 1e-60)
                lp[i, j] = -np.log10(p); cnt[i, j] = r['Count']
    # order terms by mean significance
    order = np.argsort(-np.nanmean(lp, axis=1))
    terms = [terms[i] for i in order]; lp = lp[order]; cnt = cnt[order]

    cmap = mpl.colormaps['Reds'] if direction == 'up' else mpl.colormaps['Blues']
    vmax = np.nanmax(lp)
    fig, ax = plt.subplots(figsize=(4.7, 0.42 * n_t + 1.1))
    for i in range(n_t):
        for j in range(n_d):
            y = n_t - 1 - i
            if np.isnan(lp[i, j]):
                ax.scatter(j, y, marker='x', s=18, c='#b9bdc2', lw=1.0, zorder=2)
                continue
            s = 22 + (cnt[i, j] / np.nanmax(cnt)) * 150
            frac = 0.40 + 0.60 * min(lp[i, j] / vmax, 1.0)
            ax.scatter(j, y, s=s, color=cmap(frac),
                       edgecolors='white', linewidths=0.5, zorder=3)
    ax.set_yticks(range(n_t)); ax.set_yticklabels([wrap(t, 30) for t in terms][::-1], fontsize=6.6)
    ax.set_xticks(range(n_d)); ax.set_xticklabels(ANIMAL_LABEL, fontsize=6.6)
    ax.set_xlim(-0.55, n_d - 0.55); ax.set_ylim(-0.6, n_t - 0.4)
    ax.grid(axis='y', color='#ececec', lw=0.6, zorder=0)
    ax.set_axisbelow(True)
    # size legend
    sm_cnt = [30, 80, 140]
    for k, c in enumerate(sm_cnt):
        ax.scatter([], [], s=22 + (c / np.nanmax(cnt)) * 150, c='#9aa0a6',
                   edgecolors='white', linewidths=0.5, label=str(c))
    leg = ax.legend(title='Gene count', loc='upper left', bbox_to_anchor=(1.02, 1.0),
                    fontsize=6.2, title_fontsize=6.6, handletextpad=0.4, labelspacing=0.8,
                    borderpad=0.5, columnspacing=0.5)
    sm = ScalarMappable(Normalize(0, vmax), cmap)
    cb = fig.colorbar(sm, ax=ax, fraction=0.045, pad=0.20, shrink=0.5, anchor=(0, 0.28))
    cb.set_label('-log$_{10}$(adj. p)', fontsize=6.6); cb.ax.tick_params(labelsize=6, length=2)
    cb.outline.set_linewidth(0.6)
    ttl = 'Up-regulated DEGs — GO biological process' if direction == 'up' \
        else 'Down-regulated DEGs — GO biological process'
    ax.set_title(ttl, fontsize=8.2, fontweight='bold', pad=6)
    save(fig, fname)


def panel_a():
    panel_go_dot(TERMS_UP, 'up', 'Figure3A_GO_up_dotplot', C_UP)


def panel_b():
    panel_go_dot(TERMS_DOWN, 'down', 'Figure3B_GO_down_dotplot', C_DOWN)


# The curated functional modules are provided in manuscript Table 1.
# Figure 3 = A (up GO), B (down GO), D (GSEA NES), E (cross-cohort NES heatmap).


# ============================================================ Panel D : GSEA NES grouped bars (discovery cohort)
D_GROUPS = [
    ('Inflammatory / immune', '#c0504d', [
        'acute inflammatory response', 'regulation of inflammatory response', 'neuroinflammatory response',
        'cytokine production involved in immune response']),
    ('DNA damage / p53 axis', C_GOLD, [
        'DNA damage response, signal transduction by p53 class mediator',
        'signal transduction by p53 class mediator',
        'intrinsic apoptotic signaling pathway by p53 class mediator',
        'regulation of signal transduction by p53 class mediator']),
    ('Cell death / stress', '#8e7ab5', [
        'intrinsic apoptotic signaling pathway in response to DNA damage',
        'extrinsic apoptotic signaling pathway', 'response to oxidative stress', 'cellular senescence']),
]


def panel_d():
    ds = 'GSE163614'
    tab = GSEA[ds]
    rows = []
    for gname, col, terms in D_GROUPS:
        for t in terms:
            nes = tab.loc[t, 'NES'] if t in tab.index else np.nan
            pa = tab.loc[t, 'p.adjust'] if t in tab.index else np.nan
            rows.append((gname, col, t, nes, pa))
    rows = rows[::-1]
    fig, ax = plt.subplots(figsize=(5.4, 0.46 * len(rows) + 1.0))
    for i, (gname, col, t, nes, pa) in enumerate(rows):
        ax.barh(i, nes, color=col, alpha=0.85, height=0.66, zorder=3)
        star = '**' if pa < 0.01 else ('*' if pa < 0.05 else '')
        ax.text(nes + 0.03, i, f'{nes:+.2f}{star}', va='center', fontsize=6.2, color='#333')
    ax.axvline(0, color='#555', lw=0.8)
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels([wrap(t, 40) for _, _, t, _, _ in rows], fontsize=6.4)
    ax.set_xlabel('Normalized enrichment score (NES)', fontsize=7)
    xmax = max(r[3] for r in rows if not np.isnan(r[3]))
    ax.set_xlim(0, xmax * 1.16)
    ax.grid(axis='x', color='#ececec', lw=0.6, zorder=0); ax.set_axisbelow(True)
    ax.set_title(f'GSEA enriched programs, {ds} (Rat MCAO/R)\n* adj.p<0.05  ** adj.p<0.01',
                 fontsize=8.0, fontweight='bold', loc='left', pad=6)
    from matplotlib.patches import Patch
    handles = [Patch(fc=col, label=g) for g, col, _ in D_GROUPS]
    ax.legend(handles=handles, loc='upper center', bbox_to_anchor=(0.5, -0.10), ncol=3,
              fontsize=6.4, columnspacing=1.2, handlelength=1.4, handletextpad=0.5)
    save(fig, 'Figure3C_GSEA_NES')


# ============================================================ Panel E : 5-cohort NES heatmap
E_TERMS = [
    ('Inflammatory / immune', [
        'acute inflammatory response', 'regulation of inflammatory response', 'neuroinflammatory response',
        'cytokine production involved in immune response', 'myeloid leukocyte activation',
        'humoral immune response', 'adaptive immune response']),
    ('DNA damage / p53 / cell cycle', [
        'signal transduction by p53 class mediator', 'cell cycle checkpoint signaling',
        'mitotic DNA replication', 'cellular senescence']),
    ('Neuronal / synaptic (suppressed)', [
        'regulation of neurotransmitter receptor activity',
        'positive regulation of excitatory postsynaptic potential', 'neurotransmitter secretion']),
    ('Mitochondrial / ribosomal (suppressed)', [
        'mitochondrial translation', 'rRNA processing', 'ribosome biogenesis',
        'proton motive force-driven mitochondrial ATP synthesis']),
]


def panel_e():
    terms, groups, gcolors = [], [], []
    gpalette = ['#c0504d', C_GOLD, C_DOWN, '#5a8a6a']
    for (g, ts), gc in zip(E_TERMS, gpalette):
        for t in ts:
            terms.append(t); groups.append(g); gcolors.append(gc)
    M = np.full((len(terms), len(ALL5)), np.nan)
    for i, t in enumerate(terms):
        for j, ds in enumerate(ALL5):
            if ds in GSEA and t in GSEA[ds].index:
                M[i, j] = GSEA[ds].loc[t, 'NES']
    fig, ax = plt.subplots(figsize=(5.0, 0.40 * len(terms) + 1.5))
    cmap = LinearSegmentedColormap.from_list('div', ['#48639a', '#f4f6f8', '#e0524d'])
    vlim = 2.8
    im = ax.imshow(M, cmap=cmap, vmin=-vlim, vmax=vlim, aspect='auto')
    for i in range(len(terms)):
        for j in range(len(ALL5)):
            v = M[i, j]
            if np.isnan(v):
                ax.text(j, i, '—', ha='center', va='center', fontsize=6.4, color='#aab0b6')
            else:
                ax.text(j, i, f'{v:+.1f}', ha='center', va='center', fontsize=5.8,
                        color='white' if abs(v) > 1.7 else '#333')
    ax.set_xticks(range(len(ALL5))); ax.set_xticklabels(ALL5_LABEL, fontsize=6.2)
    ax.set_yticks(range(len(terms))); ax.set_yticklabels([wrap(t, 32) for t in terms], fontsize=6.2)
    ax.set_xticks(np.arange(-.5, len(ALL5), 1), minor=True)
    ax.set_yticks(np.arange(-.5, len(terms), 1), minor=True)
    ax.grid(which='minor', color='white', lw=1.4); ax.tick_params(which='minor', length=0)
    # tight group side bars (group names given in a bottom legend)
    gi = 0
    for g_idx, (g, ts) in enumerate(E_TERMS):
        for i in range(gi, gi + len(ts)):
            ax.add_patch(plt.Rectangle((-0.62, i - 0.5), 0.12, 1, color=gpalette[g_idx],
                                       clip_on=False, lw=0))
        gi += len(ts)
    cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.05, shrink=0.45, anchor=(0, 0.2))
    cb.set_label('GSEA NES', fontsize=6.6); cb.ax.tick_params(labelsize=6, length=2)
    cb.outline.set_linewidth(0.6)
    ax.set_title('Cross-cohort concordance of GSEA programs', fontsize=8.2, fontweight='bold', pad=8)
    from matplotlib.patches import Patch
    leg_lab = ['Inflammatory / immune', 'DNA damage / p53 / cycle',
               'Neuronal / synaptic', 'Mitochondrial / ribosomal']
    h = [Patch(fc=c, label=l) for c, l in zip(gpalette, leg_lab)]
    ax.legend(handles=h, loc='upper center', bbox_to_anchor=(0.5, -0.075), ncol=2,
              fontsize=6.0, columnspacing=1.4, handlelength=1.2, handletextpad=0.4)
    save(fig, 'Figure3D_NES_heatmap')


# Figure 3 contains enrichment and cross-cohort GSEA panels.


if __name__ == '__main__':
    panel_a(); panel_b(); panel_d(); panel_e()
    print('Figure 3 panels (A, B, D, E) done ->', OUT)
