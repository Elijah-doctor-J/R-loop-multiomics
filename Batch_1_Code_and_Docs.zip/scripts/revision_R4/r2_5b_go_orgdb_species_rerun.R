# R2.5b: species-specific OrgDb GO BP over-representation analysis.
#
# The package contains the CSV snapshots used for this revision, so no private
# RDS objects or machine-specific paths are required. Run from the extracted
# project root:
#   Rscript scripts/revision_R4/r2_5b_go_orgdb_species_rerun.R
# Optional arguments are a bulk-result directory and an output directory:
#   Rscript ... <bulk_result_dir> <output_dir>
# The default output is outputs/revision_R4/tables/GO_orgdb_species_rerun.

if (.Platform$OS.type == "windows" && getRversion() < "4.2.0") {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.936"))
}
suppressPackageStartupMessages({
  library(clusterProfiler)
  library(org.Rn.eg.db)
  library(org.Mm.eg.db)
})

file_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(file_arg)) stop("Run this script with Rscript so the project root can be located.")
script_path <- normalizePath(sub("^--file=", "", file_arg[1]), winslash = "/")
project_root <- normalizePath(file.path(dirname(script_path), "../.."), winslash = "/", mustWork = TRUE)
args <- commandArgs(trailingOnly = TRUE)
bulk_dir <- if (length(args) >= 1) normalizePath(args[1], winslash = "/", mustWork = TRUE) else
  file.path(project_root, "data", "main_tables", "01_bulk_transcriptomics")
out_dir <- if (length(args) >= 2) args[2] else
  file.path(project_root, "outputs", "revision_R4", "tables", "GO_orgdb_species_rerun")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

read_result <- function(path) {
  if (!file.exists(path)) stop("Missing bulk result file: ", path)
  con <- gzfile(path, "rt")
  on.exit(close(con))
  utils::read.csv(con, stringsAsFactors = FALSE, check.names = FALSE)
}

configs <- list(
  list(id = "GSE163614", file = "GSE163614_DESeq2_results.csv.gz", db = org.Rn.eg.db,
       pcol = "padj", lfc = "log2FoldChange"),
  list(id = "GSE137482", file = "GSE137482_DESeq2_results.csv.gz", db = org.Mm.eg.db,
       pcol = "padj", lfc = "log2FoldChange"),
  list(id = "GSE61616", file = "GSE61616_limma_results.csv.gz", db = org.Rn.eg.db,
       pcol = "adj.P.Val", lfc = "logFC")
)

summary <- list()
all_results <- list()
for (cfg in configs) {
  res <- read_result(file.path(bulk_dir, cfg$file))
  if (!"gene" %in% names(res)) stop("No gene column in ", cfg$file)
  if (!all(c(cfg$pcol, cfg$lfc) %in% names(res))) stop("Missing required columns in ", cfg$file)
  mapped <- suppressMessages(clusterProfiler::bitr(res$gene, fromType = "SYMBOL",
                                                   toType = "ENTREZID", OrgDb = cfg$db))
  merged <- merge(res, mapped, by.x = "gene", by.y = "SYMBOL")
  merged <- merged[!duplicated(merged$ENTREZID), , drop = FALSE]
  universe <- as.character(merged$ENTREZID)
  for (direction in c("up", "down")) {
    lfc <- suppressWarnings(as.numeric(merged[[cfg$lfc]]))
    pv <- suppressWarnings(as.numeric(merged[[cfg$pcol]]))
    genes <- if (direction == "up") as.character(merged$ENTREZID[pv < 0.05 & lfc > 0]) else
      as.character(merged$ENTREZID[pv < 0.05 & lfc < 0])
    for (background in c("defaultBg", "detectedBg")) {
      universe_arg <- if (background == "detectedBg") universe else NULL
      ego <- suppressMessages(clusterProfiler::enrichGO(
        gene = genes, OrgDb = cfg$db, keyType = "ENTREZID", ont = "BP",
        universe = universe_arg, pAdjustMethod = "BH", pvalueCutoff = 0.05,
        qvalueCutoff = 0.2, minGSSize = 10, maxGSSize = 500, readable = FALSE))
      # Keep all tested terms, matching the supplied original @result tables;
      # as.data.frame(enrichResult) would instead apply the result cutoffs.
      if (is.null(ego)) stop("No enrichment result for ", cfg$id, "/", direction, "/", background)
      tab <- ego@result
      tab$accession <- cfg$id
      tab$direction <- direction
      tab$background <- background
      tab <- tab[, c("accession", "direction", "background", setdiff(names(tab), c("accession", "direction", "background"))), drop = FALSE]
      key <- paste(cfg$id, direction, background, sep = "__")
      all_results[[key]] <- tab
      utils::write.csv(tab, file.path(out_dir, paste0(cfg$id, "_GO_BP_", direction, "_", background, ".csv")), row.names = FALSE)
      summary[[length(summary) + 1L]] <- data.frame(dataset = cfg$id, direction = direction,
                                                    background = background, input_genes = length(genes),
                                                    universe_size = length(universe),
                                                    significant_terms = sum(tab$p.adjust < 0.05, na.rm = TRUE),
                                                    stringsAsFactors = FALSE)
    }
  }
}
summary_df <- do.call(rbind, summary)
utils::write.csv(summary_df, file.path(out_dir, "GO_orgdb_rerun_summary.csv"), row.names = FALSE)
utils::write.csv(summary_df, file.path(out_dir, "GO_orgdb_species_summary.csv"), row.names = FALSE)
combined <- do.call(rbind, all_results)
utils::write.csv(combined, file.path(out_dir, "GO_orgdb_species_all_results.csv"), row.names = FALSE)
print(summary_df)
