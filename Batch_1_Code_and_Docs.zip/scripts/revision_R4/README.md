# Revision analyses and figure mapping

Run `python scripts/revision_R4/SCRIPT.py` from the project root. New numerical
outputs and panels go under `outputs/revision_R4/`; supplied tables are not
automatically replaced. Python dependencies are listed at the project root.

| Script | Inputs | Outputs / manuscript connection |
|---|---|---|
| `R4_1_cross_cohort_meta.py` | Three animal DE tables and the 32-gene index | Corrected `meta_analysis_rloop_32genes_corrected_variance.csv` and forest plot; Figure2F and S8 meta results |
| `R4_1b_meta_sensitivity.py` | Same bulk tables | Corrected platform-restricted and leave-one-cohort-out table |
| `extract_lineage_marker_inputs.py` | Released GSM7060815–GSM7060826 matrices plus bundled cell metadata | Compact unchanged 34-marker input; optional rebuild of `data/reference/GSE225948_lineage_markers.csv.gz` |
| `R4_2b_microglia_vs_monocyte.py` | Compact marker matrix and GSE225948 metadata | Parent/subcluster marker, detection, lineage-score and classification tables |
| `R4_2c_composition.py` | GSE225948 metadata | Per-animal cell proportions/counts, group summaries and composition diagnostics |
| `R4_2c_subcluster_trajectory_data.py` | Same metadata | Subcluster percentages within parent lineages |
| `R4_2c_panelC_subcluster_trajectory.py` | Same metadata | Subcluster percentages of all recovered cells and diagnostic trajectory plot |
| `R4_plot_new_analysis_panels.py` | Supplied marker, score and composition tables | Figure6A marker dot plot; 6B score space; 6C proportion; 6D count; supplementary marker violin, log-ratio and subcluster panels |
| `r2_5_enrichment_background.py` | Bulk DE and human GO snapshot | Default/detected-background GO tables and key-term comparison; S5/background sensitivity |
| `r2_6_control_signatures.py` | Bulk DE and human GO snapshot | Expression-matched and broader-signature control tables; S8 |
| `r2_6b_crosscohort_null.py` | Three animal DE tables | Cross-cohort null/control table; S8 |

Canonical meta scripts use sampling variance = SE squared and the DL model.
The supplied final main/sensitivity CSVs are in `data/revision_R4_tables/`.
The Figure6 renderer does not generate a separate meta forest.

The compact lineage input copies released expression values without
normalization; the lineage script applies log1p. Source URLs and checksums are
in `data/reference/lineage_source_manifest.csv`. No large raw matrices are
included. Download/rebuild instructions are in `docs/DATA_SOURCES.md`.

The human GO annotation snapshot has no recorded database version/date; rodent
symbol uppercasing is a heuristic rather than full orthology mapping. Existing
control code defines curated/background quantile bins separately; this does not
guarantee common expression-bin boundaries. Cross-cohort identifier sorting is
deterministic; historical unordered-set summaries may differ. These methods
were not revised by package cleanup.
