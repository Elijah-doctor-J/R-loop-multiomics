"""Extract only lineage-marker rows from the 12 released GSE225948 brain matrices.

Download the original GSM7060815--GSM7060826 gene-by-cell CSV.gz files from GEO
to data/external/03_scrnaseq/supplementary/GSE225948/extracted first. This step
performs no normalization, thresholding or statistical testing. The compact
matrix shipped in data/reference preserves these source values unchanged.
"""
from pathlib import Path
import glob
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
EXTR=ROOT/'data/external/03_scrnaseq/supplementary/GSE225948/extracted'
META=ROOT/'data/main_tables/10_scrna_gse225948/GSE225948_merged_metadata.csv.gz'
OUT=ROOT/'outputs/revision_R4/inputs/GSE225948_lineage_markers.csv.gz'
MARKERS=['Tmem119','P2ry12','Hexb','Cx3cr1','Sall1','Gpr34','Slc2a5','Siglech',
         'Ccr2','Plac8','Ly6c2','Ly6c1','Ifitm1','Fn1','S100a4','Chil3','Cd52',
         'Mrc1','Cd163','Lyve1','Pf4','F13a1','Aif1','Itgam','Ptprc',
         'Cst7','Itgax','Lpl','Apoe','Trem2','Tyrobp','Axl','Ccl2','Clec7a']

def extract(source_dir=EXTR, output=OUT):
    meta=pd.read_csv(META).set_index('cell_id')
    parts=[]
    for gsm in sorted(meta['sample'].unique()):
        hits=sorted(Path(source_dir).glob(f'{gsm}_*_counts.csv.gz'))
        if len(hits)!=1:
            raise FileNotFoundError(f'Expected exactly one source matrix for {gsm}, found {len(hits)}')
        keep=[]
        for chunk in pd.read_csv(hits[0],index_col=0,chunksize=256):
            selected=chunk.loc[chunk.index.intersection(MARKERS)]
            if len(selected): keep.append(selected)
        frame=pd.concat(keep)
        frame.columns=[f'{gsm}_{barcode}' for barcode in frame.columns]
        parts.append(frame)
    expr=pd.concat(parts,axis=1,join='outer')
    absent=meta.index.difference(expr.columns)
    if len(absent):raise ValueError(f'{len(absent)} metadata cells lack source expression')
    expr=expr.loc[:,meta.index]
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    expr.to_csv(output,compression='gzip')
    print(f'{expr.shape[0]} marker rows x {expr.shape[1]} cells -> {output}')

if __name__=='__main__': extract()
