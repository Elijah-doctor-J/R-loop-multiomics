# -*- coding: utf-8 -*-
"""R2.5: Approximate human-annotation GO BP background sensitivity.
Rodent symbols are uppercased, not orthology mapped. Terms are restricted to
10-500 genes within each background. This is descriptive; the main species-
specific analysis is r2_5b_go_orgdb_species_rerun.R. Hypergeometric ORA, BH
correction, and paired key-term comparison are retained unchanged."""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
import sys, pandas as pd, numpy as np
from scipy.stats import hypergeom
def bh_fdr(pvals):
    p = np.asarray(pvals, float); n = len(p)
    order = np.argsort(p); ranked = p[order]
    q = ranked*n/np.arange(1, n+1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    out = np.empty(n); out[order] = np.clip(q, 0, 1)
    return out
sys.stdout.reconfigure(encoding="utf-8")
import os


ANN = ROOT / 'data/reference/human_GO_BP_genes.csv.gz'
BULK = str(ROOT / 'data/main_tables/01_bulk_transcriptomics')
OUT = str(ROOT / 'outputs/revision_R4/tables')
Path(OUT).mkdir(parents=True, exist_ok=True)

go = pd.read_csv(ANN)
go["SYMBOL"] = go["SYMBOL"].str.upper()
term_name = go.drop_duplicates("GO").set_index("GO")["TERM"].to_dict()
# term -> set of genes
term_genes = go.groupby("GO")["SYMBOL"].apply(set).to_dict()
all_go_genes = set(go["SYMBOL"])  # 18722 default annotated universe

DATASETS = {
 "GSE163614": dict(f="GSE163614_DESeq2_results.csv.gz", fc="log2FoldChange", p="padj", kind="DESeq2"),
 "GSE137482": dict(f="GSE137482_DESeq2_results.csv.gz", fc="log2FoldChange", p="padj", kind="DESeq2"),
 "GSE61616":  dict(f="GSE61616_limma_results.csv.gz", fc="logFC", p="adj.P.Val", kind="limma"),
}

# key terms relevant to the manuscript claims (matched by GO id where possible)
KEY_GO = {
 "GO:0006281":"DNA repair",
 "GO:0006396":"RNA processing",
 "GO:0006397":"mRNA processing",
 "GO:0008380":"RNA splicing",
 "GO:0042254":"ribosome biogenesis",
 "GO:0006412":"translation",
 "GO:0006955":"immune response",
 "GO:0006954":"inflammatory response",
 "GO:0006915":"apoptotic process",
 "GO:0012501":"programmed cell death",
 "GO:0006952":"defense response",
 "GO:0007049":"cell cycle",
}

def hypergeom_enrich(geneset, universe, terms):
    """Return DataFrame: GO, K, k, OR, p, for terms with 10<=K<=500 in universe."""
    N = len(universe); n = len(geneset)
    rows = []
    for t, g in terms.items():
        gt = g & universe
        K = len(gt)
        if K < 10 or K > 500:
            continue
        k = len(gt & geneset)
        if k == 0:
            continue
        p = hypergeom.sf(k-1, N, K, n)
        # OR
        a = k; b = n-k; c = K-k; d = N-K-n+k
        OR = (a*d)/(b*c) if b>0 and c>0 and d>0 else np.inf
        rows.append((t, K, k, OR, p))
    r = pd.DataFrame(rows, columns=["GO","K","k","OR","p"])
    if len(r):
        r["padj"] = bh_fdr(r["p"].values)
        r = r.sort_values("padj")
        r["term"] = r["GO"].map(term_name)
        r["rank"] = range(1, len(r)+1)
    return r

summary = []
all_results = []
for ds, cfg in DATASETS.items():
    df = pd.read_csv(BULK+"/"+cfg["f"])
    df["HG"] = df["gene"].str.upper()
    # detected universe = genes in result table that map to GO annotation
    detected = set(df["HG"]) & all_go_genes
    df = df[df["HG"].isin(detected)].dropna(subset=[cfg["p"]])
    up = set(df.loc[(df[cfg["p"]]<0.05)&(df[cfg["fc"]]>0),"HG"])
    dn = set(df.loc[(df[cfg["p"]]<0.05)&(df[cfg["fc"]]<0),"HG"])
    print(f"\n{'='*90}\n{ds}: detected(in GO)={len(detected)}  up={len(up)} down={len(dn)}")
    for direction, glist in [("up",up),("down",dn)]:
        e_default = hypergeom_enrich(glist, all_go_genes, term_genes)
        e_detect  = hypergeom_enrich(glist, detected, term_genes)
        all_results.append(e_default.assign(accession=ds, direction=direction, background="defaultBg"))
        all_results.append(e_detect.assign(accession=ds, direction=direction, background="detectedBg"))
        n_sig_def = int((e_default["padj"]<0.05).sum()) if len(e_default) else 0
        n_sig_det = int((e_detect["padj"]<0.05).sum()) if len(e_detect) else 0
        print(f"  [{direction}] terms tested: default={len(e_default)} detected={len(e_detect)} | BH<0.05: default={n_sig_def} detected={n_sig_det}")
        # top 8 detected-background
        print("   top(detected-bg):", " | ".join(f"{r.term[:34]}({r.padj:.1e})" for r in e_detect.head(8).itertuples()))
        # key terms compare
        for gid, gname in KEY_GO.items():
            rd = e_default[e_default.GO==gid]; rt = e_detect[e_detect.GO==gid]
            pd_def = rd["padj"].iloc[0] if len(rd) else np.nan
            pd_det = rt["padj"].iloc[0] if len(rt) else np.nan
            OR_det = rt["OR"].iloc[0] if len(rt) else np.nan
            k_det  = rt["k"].iloc[0] if len(rt) else 0
            K_det  = rt["K"].iloc[0] if len(rt) else 0
            rk_det = rt["rank"].iloc[0] if len(rt) else np.nan
            summary.append((ds,direction,gid,gname,K_det,k_det,OR_det,pd_def,pd_det,rk_det))

pd.concat(all_results, ignore_index=True).to_csv(f"{OUT}/GO_background_sensitivity_all_results.csv.gz", index=False)
s = pd.DataFrame(summary, columns=["dataset","direction","GO","term","K_in_universe","k_DEG","OR_detectedBg","padj_defaultBg","padj_detectedBg","rank_detectedBg"])
s.to_csv(f"{OUT}/R2_5_GO_universe_comparison_keyterms.csv", index=False)
print("\n\nSaved key-term comparison.")
# print compact key-term table
for ds in DATASETS:
    for direction in ["up","down"]:
        sub = s[(s.dataset==ds)&(s.direction==direction)]
        sig = sub[sub.padj_detectedBg<0.05]
        print(f"\n{ds} {direction}: key terms significant under DETECTED bg:")
        for r in sig.itertuples():
            print(f"   {r.term:24s} k={r.k_DEG:4d}/{r.K_in_universe:4d} OR={r.OR_detectedBg:5.2f} padj_default={r.padj_defaultBg:.2e} padj_detected={r.padj_detectedBg:.2e} rank={r.rank_detectedBg}")
