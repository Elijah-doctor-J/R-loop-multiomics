# -*- coding: utf-8 -*-
"""GSE225948 subcluster percentages within lineages and among all recovered cells.

Each GSM is a pooled sample library, with four libraries per condition; it is
not an individual mouse. Both denominator conventions are exported explicitly.
"""
import os
import numpy as np
import pandas as pd

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
META = str(ROOT / 'data/main_tables/10_scrna_gse225948/GSE225948_merged_metadata.csv.gz')
OUT_TAB = str(ROOT / 'outputs/revision_R4/tables')
Path(OUT_TAB).mkdir(parents=True, exist_ok=True)
TREATS = ["Sham", "D02", "D14"]

md = pd.read_csv(META)
# 每样本每亚群细胞数
ct = pd.crosstab(md["sample"], md["sub.celltype"])
# All-cell denominator used in the plotted subcluster time course.
allcell = ct.div(ct.sum(axis=1), axis=0) * 100.0
info = md[["sample", "treatment", "Replicate"]].drop_duplicates().set_index("sample")
# Preserve GSM order and alphabetic subcluster columns of the supplied table.
allcell.insert(0, "replicate", info.loc[allcell.index, "Replicate"].astype(int))
allcell["treatment"] = info.loc[allcell.index, "treatment"]
allcell.reset_index().to_csv(
    os.path.join(OUT_TAB, "subcluster_trajectory_per_sample_allcell.csv"),
    index=False, encoding="utf-8-sig")
ct = ct.join(info["treatment"])

mg_subs = [f"Mg{i}" for i in range(1, 9)]
mdc_subs = [f"MdC{i}" for i in range(1, 7)]

rows = []
for s, r in ct.iterrows():
    tr = r["treatment"]
    n_mg = sum(r[c] for c in mg_subs)
    n_md = sum(r[c] for c in mdc_subs)
    row = dict(sample=s, treatment=tr, replicate=int(sample_info := info.loc[s, "Replicate"]),
               n_Mg=int(n_mg), n_MdC=int(n_md))
    for c in mg_subs:
        row[f"{c}_within"] = 100.0 * r[c] / n_mg if n_mg else np.nan
    for c in mdc_subs:
        row[f"{c}_within"] = 100.0 * r[c] / n_md if n_md else np.nan
    rows.append(row)
per = pd.DataFrame(rows).sort_values(["treatment", "replicate"])
per.to_csv(os.path.join(OUT_TAB, "subcluster_trajectory_per_sample.csv"), index=False, encoding="utf-8-sig")

def lineage_table(subs, col_n):
    recs = []
    for c in subs:
        row = {"subcluster": c}
        for tr in TREATS:
            d = per[per["treatment"] == tr][f"{c}_within"]
            row[f"{tr}_mean"] = d.mean()
            row[f"{tr}_sd"] = d.std()
        recs.append(row)
    return pd.DataFrame(recs).set_index("subcluster")

print("========== Mg 谱系内部亚群比例（% of Mg，mean±SD，n=4） ==========")
tmg = lineage_table(mg_subs, "n_Mg")
print(tmg.round(1).to_string())
print("\n========== MdC 谱系内部亚群比例（% of MdC，mean±SD，n=4） ==========")
tmd = lineage_table(mdc_subs, "n_MdC")
print(tmd.round(1).to_string())
