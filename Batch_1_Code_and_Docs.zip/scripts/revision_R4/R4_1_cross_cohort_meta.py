# -*- coding: utf-8 -*-
"""
R4-1 跨队列随机效应 meta 分析（response to Reviewer 4, comment 1）
====================================================================
用正式的随机效应模型（DerSimonian-Laird 法）合并三个动物 MCAO 队列
32 个 R-loop 相关基因的 log2 fold-change，替代原稿的“方向一致计数”。

三个动物队列：
  - GSE163614 大鼠 MCAO/R RNA-seq （DESeq2, Wald）
  - GSE137482 小鼠 MCAO   RNA-seq （DESeq2, Wald，含 age 协变量）
  - GSE61616  大鼠 MCAO/R microarray（limma empirical-Bayes，仅 Sham vs Model）

效应量与标准误：
  - DESeq2：yi = log2FoldChange，sei = lfcSE（Wald 标准误）
  - limma ：yi = logFC，sei = |logFC / t|（moderated t 反推的标准误）
合并方法：
  - 主分析：随机效应（DerSimonian-Laird tau^2），报告合并 log2FC、95%CI、
            z、p、Cochran Q、I^2、tau^2
  - 敏感性：Stouffer 加权 z（带方向，双侧 p 转换）与 Fisher 合并 p（chi-square）
仅纳入至少 2 个队列有有效估计的基因；k=0/1 的基因仅在表中标注、不做合并。

输出：
  tables/meta_analysis_rloop_32genes_corrected_variance.csv
  figures/Fig_meta_forest_corrected_variance.png / .pdf
"""
import os
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
BULK = str(ROOT / 'data/main_tables/01_bulk_transcriptomics')
OUT_TAB = str(ROOT / 'outputs/revision_R4/tables')
OUT_FIG = str(ROOT / 'outputs/revision_R4/figures')
os.makedirs(OUT_TAB, exist_ok=True)
os.makedirs(OUT_FIG, exist_ok=True)

# Corrected canonical calculation: pass sampling variances (SE squared).
# Historical-error comparison utilities are omitted from this distribution.
P_CLIP = 1e-300  # 防止 -2ln(p) 溢出

# ---------- 1. 读入三个队列的差异结果 ----------
d163 = pd.read_csv(os.path.join(BULK, "GSE163614_DESeq2_results.csv.gz"))
d137 = pd.read_csv(os.path.join(BULK, "GSE137482_DESeq2_results.csv.gz"))
d616 = pd.read_csv(os.path.join(BULK, "GSE61616_limma_results.csv.gz"))

# 统一为 (gene, log2fc, se, p)
def prep_deseq(df, tag):
    out = df[["gene", "log2FoldChange", "lfcSE", "pvalue"]].copy()
    out.columns = ["gene", f"{tag}_log2fc", f"{tag}_se", f"{tag}_p"]
    return out

def prep_limma(df, tag):
    out = df[["gene", "logFC", "t", "P.Value"]].copy()
    # moderated t 反推标准误：t = logFC / se_mod
    se = np.where(np.isclose(out["t"].abs(), 0.0), np.nan,
                  (out["logFC"] / out["t"]).abs())
    out[f"{tag}_se"] = se
    out = out.rename(columns={"logFC": f"{tag}_log2fc", "P.Value": f"{tag}_p"})
    return out[["gene", f"{tag}_log2fc", f"{tag}_se", f"{tag}_p"]]

a = prep_deseq(d163, "GSE163614")
b = prep_deseq(d137, "GSE137482")
c = prep_limma(d616, "GSE61616")

# 32 基因主表（含 human 符号）
cross = pd.read_csv(os.path.join(BULK, "rloop_genes_cross_dataset.csv"))[["gene", "gene_human"]]
m = cross.merge(a, on="gene", how="left").merge(b, on="gene", how="left").merge(c, on="gene", how="left")

STUDIES = ["GSE163614", "GSE137482", "GSE61616"]

# ---------- 2. 逐基因随机效应 meta ----------
def dl_random_effects(y, v):
    """DerSimonian-Laird 随机效应。返回 dict。"""
    y = np.asarray(y, float); v = np.asarray(v, float)
    ok = ~np.isnan(y) & ~np.isnan(v) & (v > 0)
    y, v = y[ok], v[ok]
    k = len(y)
    if k < 2:
        return None
    w = 1.0 / v
    fe = np.sum(w * y) / np.sum(w)
    Q = np.sum(w * (y - fe) ** 2)
    dfq = k - 1
    C = np.sum(w) - np.sum(w ** 2) / np.sum(w)
    tau2 = max(0.0, (Q - dfq) / C) if C > 0 else 0.0
    wr = 1.0 / (v + tau2)
    re = np.sum(wr * y) / np.sum(wr)
    se_re = np.sqrt(1.0 / np.sum(wr))
    z = re / se_re
    p = 2.0 * stats.norm.sf(abs(z))
    lo, hi = re - 1.96 * se_re, re + 1.96 * se_re
    I2 = max(0.0, (Q - dfq) / Q) * 100.0 if Q > 0 else 0.0
    Qp = stats.chi2.sf(Q, dfq) if dfq > 0 else np.nan
    # 固定效应
    fe_se = np.sqrt(1.0 / np.sum(w))
    fe_z = fe / fe_se
    fe_p = 2.0 * stats.norm.sf(abs(fe_z))
    return dict(k=k, fe=fe, fe_p=fe_p, re=re, se=se_re, lo=lo, hi=hi, z=z, p=p,
                tau2=tau2, Q=Q, Qp=Qp, I2=I2,
                studies=";".join(np.array(STUDIES)[ok]))

def stouffer(y, p):
    """带方向的 Stouffer：双侧 p 转 z，再按 sign(log2fc) 定向。"""
    y = np.asarray(y, float); p = np.asarray(p, float)
    ok = ~np.isnan(y) & ~np.isnan(p)
    y, p = y[ok], np.clip(p[ok], P_CLIP, 1.0)
    if len(y) < 2:
        return np.nan, np.nan
    z_one = stats.norm.isf(p / 2.0)        # 单侧大小
    z = np.sign(y) * z_one
    Z = np.sum(z) / np.sqrt(len(z))
    return Z, 2.0 * stats.norm.sf(abs(Z))

def fisher(p):
    p = np.asarray(p, float)
    p = np.clip(p[~np.isnan(p)], P_CLIP, 1.0)
    if len(p) < 2:
        return np.nan
    stat = -2.0 * np.sum(np.log(p))
    return stats.chi2.sf(stat, 2.0 * len(p))

rows = []
for _, r in m.iterrows():
    y = [r[f"{s}_log2fc"] for s in STUDIES]
    v = [r[f"{s}_se"] ** 2 for s in STUDIES]
    p = [r[f"{s}_p"] for s in STUDIES]
    dl = dl_random_effects(y, v)
    stz, stp = stouffer(y, p)
    fp = fisher(p)
    rec = dict(gene=r["gene"], gene_human=r["gene_human"])
    if dl is None:
        rec.update(k=int(np.sum(np.isfinite(y) & np.isfinite(v) & (np.asarray(v) > 0))))
    else:
        rec.update(dl)
    rec["stouffer_z"] = stz
    rec["stouffer_p"] = stp
    rec["fisher_p"] = fp
    for s in STUDIES:
        rec[f"{s}_log2fc"] = r[f"{s}_log2fc"]
        rec[f"{s}_p"] = r[f"{s}_p"]
    rows.append(rec)

res = pd.DataFrame(rows)
# 多重检验校正（对能做 meta 的基因）
mask = res["k"] >= 2
res["re_padj"] = np.nan
res.loc[mask, "re_padj"] = stats.false_discovery_control(res.loc[mask, "p"].values, method="bh")
res["stouffer_padj"] = np.nan
res.loc[mask, "stouffer_padj"] = stats.false_discovery_control(res.loc[mask, "stouffer_p"].values, method="bh")

# 排序：按随机效应 p 值
res = res.sort_values("p", na_position="last").reset_index(drop=True)
res["meta_rank"] = np.nan
idx_ok = res.index[res["k"] >= 2]
res.loc[idx_ok, "meta_rank"] = np.arange(1, len(idx_ok) + 1)

# 方向一致性标记（保留旧指标，便于对照）
def sign_consistent(vals):
    vals = [x for x in vals if not pd.isna(x)]
    if len(vals) < 2:
        return np.nan
    return len(set(np.sign(vals))) == 1
res["sign_consistent"] = [sign_consistent([res.loc[i, f"{s}_log2fc"] for s in STUDIES]) for i in res.index]
res["direction"] = np.where(res["re"].isna(), "not_estimable", np.where(res["re"] > 0, "up", "down"))

cols = ["meta_rank", "gene", "gene_human", "k", "studies", "direction",
        "GSE163614_log2fc", "GSE137482_log2fc", "GSE61616_log2fc",
        "fe", "fe_p", "re", "se", "lo", "hi", "z", "p", "re_padj",
        "tau2", "Q", "Qp", "I2", "stouffer_z", "stouffer_p", "stouffer_padj",
        "fisher_p", "sign_consistent",
        "GSE163614_p", "GSE137482_p", "GSE61616_p"]
res = res[cols]
res.to_csv(os.path.join(OUT_TAB, "meta_analysis_rloop_32genes_corrected_variance.csv"), index=False, encoding="utf-8-sig")

# ---------- 3. 打印结果 ----------
pd.set_option("display.width", 200); pd.set_option("display.max_columns", 50)
show = res[res["k"] >= 2].copy()
print("可做 meta 的基因数:", len(show), "；仅单队列(不合并):", res[res["k"] < 2]["gene"].tolist())
print(show[["meta_rank", "gene", "k", "re", "lo", "hi", "z", "p", "re_padj", "I2", "direction", "stouffer_p"]].round(3).to_string(index=False))
print("\n随机效应显著 (padj<0.05):")
print(show.loc[show["re_padj"] < 0.05, ["gene", "re", "re_padj", "direction", "I2"]].round(4).to_string(index=False))
print("\n名义显著 (p<0.05, padj 未过):")
print(show.loc[(show["p"] < 0.05) & (show["re_padj"] >= 0.05), ["gene", "re", "p", "re_padj", "direction"]].round(4).to_string(index=False))

# ---------- 4. 森林图（大字号，回应图字号意见） ----------
plot_df = show.sort_values("re").reset_index(drop=True)
fig, ax = plt.subplots(figsize=(11, 11))
colors = {"GSE163614": "#9ecae1", "GSE137482": "#bdbdbd", "GSE61616": "#fdae6b"}
ypos = np.arange(len(plot_df))
for i, (_, rr) in enumerate(plot_df.iterrows()):
    # 各队列原始估计（小点）
    for s in STUDIES:
        yv = rr[f"{s}_log2fc"]
        if pd.notna(yv):
            ax.scatter(yv, i, s=28, color=colors[s], edgecolor="gray", linewidth=0.4, zorder=2)
    # 合并效应 95%CI + 点
    sig = rr["re_padj"] < 0.05
    ax.plot([rr["lo"], rr["hi"]], [i, i], color="#b2182b" if sig else "#444444", lw=1.6, zorder=3)
    ax.scatter(rr["re"], i, s=70, color="#b2182b" if sig else "#2166ac",
               edgecolor="black", linewidth=0.5, zorder=4, marker="D")

ax.axvline(0, color="black", lw=1.0, ls="--")
ax.set_yticks(ypos)
ax.set_yticklabels(plot_df["gene"], fontsize=11)
ax.set_xlabel("log2 fold-change (MCAO vs control)", fontsize=13)
ax.set_title("Random-effects meta-analysis across three animal MCAO cohorts\n"
             "Diamonds = pooled estimate (DL); bars = 95% CI; small dots = individual cohorts",
             fontsize=12.5)
from matplotlib.lines import Line2D
handles = [Line2D([0], [0], marker="o", color="w", markerfacecolor=colors[s],
                  markeredgecolor="gray", markersize=8, label=s.replace("GSE", "GSE")) for s in STUDIES]
handles += [Line2D([0], [0], marker="D", color="w", markerfacecolor="#b2182b",
                   markeredgecolor="black", markersize=9, label="Pooled (FDR<0.05)"),
            Line2D([0], [0], marker="D", color="w", markerfacecolor="#2166ac",
                   markeredgecolor="black", markersize=9, label="Pooled (n.s.)")]
ax.legend(handles=handles, loc="lower right", fontsize=10, framealpha=0.9)
ax.grid(axis="x", ls=":", alpha=0.5)
plt.tight_layout()
plt.savefig(os.path.join(OUT_FIG, "Fig_meta_forest_corrected_variance.png"), dpi=300)
plt.savefig(os.path.join(OUT_FIG, "Fig_meta_forest_corrected_variance.pdf"))
plt.close()
print("\n森林图已保存:", os.path.join(OUT_FIG, "Fig_meta_forest_corrected_variance.png"))
