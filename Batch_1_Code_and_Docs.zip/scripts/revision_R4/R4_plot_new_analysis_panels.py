# -*- coding: utf-8 -*-
"""
R4 新增分析：独立单面板小图（不拼大图，供作者手动拼版）
=====================================================================
基于提供的谱系标记和组成结果表绘图，不重跑分析。
Outputs: outputs/revision_R4/figures/
每张图：PNG 300 dpi + PDF 矢量（TrueType 嵌入），统一放大字号。

对应关系：
  R4.2b 驻留 vs 单核 marker  -> R4_marker_dotplot / R4_marker_scorespace / R4_marker_violin
  R4.2c 组成约束             -> R4_composition_proportion / _count / _logratio
                                R4_subcluster_mg / R4_subcluster_mdc
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.stats import gaussian_kde

# ----------------------------------------------------------------------
# 全局样式：科研风格、放大字号
# ----------------------------------------------------------------------
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
    "font.size": 11,
    "axes.titlesize": 12.5,
    "axes.labelsize": 12,
    "xtick.labelsize": 11,
    "ytick.labelsize": 11,
    "legend.fontsize": 10,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.9,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
TD = str(ROOT / 'data/revision_R4_tables')
OUT = str(ROOT / 'outputs/revision_R4/figures')
os.makedirs(OUT, exist_ok=True)

C_MG = "#2166ac"
C_MD = "#b2182b"
C_BAM = "#5aae61"
TREATS = ["Sham", "D02", "D14"]
TREAT_LAB = ["Sham", "D2", "D14"]
X = np.array([0, 1, 2])


def save(fig, name):
    png = os.path.join(OUT, name + ".png")
    pdf = os.path.join(OUT, name + ".pdf")
    fig.savefig(png, dpi=300, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    print("saved:", name)


# ======================================================================
# 2. R4.2b 经典 marker 点图（parent）
# ======================================================================
RESIDENT = ["Tmem119", "P2ry12", "Hexb", "Cx3cr1", "Sall1", "Gpr34", "Slc2a5", "Siglech"]
MONO = ["Ccr2", "Plac8", "Ly6c2", "Ly6c1", "Ifitm1", "Fn1", "S100a4", "Chil3", "Cd52"]
BAM = ["Mrc1", "Cd163", "Lyve1", "Pf4", "F13a1"]
PANMYE = ["Aif1", "Itgam", "Ptprc"]
DAM = ["Cst7", "Itgax", "Lpl", "Apoe", "Trem2", "Tyrobp", "Axl", "Ccl2", "Clec7a"]
GENES = RESIDENT + MONO + BAM + PANMYE + DAM
parent_order = ["Mg", "MdC", "BAM", "MaC", "DC", "MC", "Gran", "NK", "Tc", "Bc", "EC", "OD", "Epi"]

avg = pd.read_csv(os.path.join(TD, "parent_avg_logexpr_matrix.csv"), index_col=0)
pct = pd.read_csv(os.path.join(TD, "parent_pct_matrix.csv"), index_col=0)
cts = [c for c in parent_order if c in avg.columns]
avg = avg.reindex(GENES)[cts]
pct = pct.reindex(GENES)[cts]

# 每个基因跨细胞类型 z-score
zmat = avg.sub(avg.mean(axis=1), axis=0).div(avg.std(axis=1, ddof=0).replace(0, np.nan), axis=0)
cmap = plt.cm.RdYlBu_r
fig, ax = plt.subplots(figsize=(12.5, 10.5))
for i, g in enumerate(GENES):
    for j, ct in enumerate(cts):
        z = zmat.loc[g, ct]
        ps = pct.loc[g, ct]
        if pd.isna(z):
            continue
        ax.scatter(j, i, s=ps * 100 * 6.0,
                   c=[cmap(np.clip((z + 2.0) / 4.0, 0, 1))],
                   edgecolors="gray", linewidths=0.3, zorder=3)
ax.set_xticks(range(len(cts)))
ax.set_xticklabels(cts, rotation=45, ha="right")
ax.set_yticks(range(len(GENES)))
ax.set_yticklabels(GENES, fontstyle="italic")
ax.set_xlim(-0.6, len(cts) - 0.4)
ax.set_ylim(len(GENES) - 0.6, -0.6)
ax.set_xticks(np.arange(-0.5, len(cts), 1), minor=True)
ax.set_yticks(np.arange(-0.5, len(GENES), 1), minor=True)
ax.grid(which="minor", color="0.9", linewidth=0.7)
ax.tick_params(which="minor", length=0)
bounds = np.cumsum([len(RESIDENT), len(MONO), len(BAM), len(PANMYE)]) - 0.5
for b in bounds[:-1]:
    ax.axhline(b, color="black", lw=1.2)
group_lab = [(RESIDENT, "Resident microglia"), (MONO, "Monocyte-derived"),
             (BAM, "BAM/macrophage"), (PANMYE, "Pan-myeloid"), (DAM, "DAM/activated")]
for glist, lab in group_lab:
    yc = GENES.index(glist[0]) + (len(glist) - 1) / 2
    ax.text(len(cts) - 0.3, yc, lab, ha="left", va="center", rotation=-90,
            color="#333333", fontsize=10)
ax.set_title("Canonical marker expression by major cell type (GSE225948)\n"
             "Color = scaled average log-expression; size = % expressing cells")
save(fig, "R4_marker_dotplot")


# ======================================================================
# 3. R4.2b 双 marker 空间分离（scorespace）
# ======================================================================
sc = pd.read_csv(os.path.join(TD, "Mg_vs_MdC_scores_percell.csv.gz"), index_col=0)
rng = np.random.default_rng(42)
mg_pts = sc[sc["parent"] == "Mg"][["resident_score", "monocyte_score"]].dropna().values
md_pts = sc[sc["parent"] == "MdC"][["resident_score", "monocyte_score"]].dropna().values


def samp(x, n=6000):
    return x[rng.choice(len(x), min(n, len(x)), replace=False)]


mg_s, md_s = samp(mg_pts), samp(md_pts)
fig, ax = plt.subplots(figsize=(8.5, 7.5))
xmin, xmax = -1.3, 2.0
ymin, ymax = -1.3, 2.2
ax.scatter(mg_s[:, 0], mg_s[:, 1], s=3, color=C_MG, alpha=0.10,
           rasterized=True, label="Mg (resident microglia)")
ax.scatter(md_s[:, 0], md_s[:, 1], s=3, color=C_MD, alpha=0.10,
           rasterized=True, label="MdC (monocyte-derived)")


def kde_contour(pts, color, levels):
    k = gaussian_kde(pts.T)
    xx, yy = np.mgrid[xmin:xmax:120j, ymin:ymax:120j]
    z = k(np.vstack([xx.ravel(), yy.ravel()])).reshape(xx.shape)
    ax.contour(xx, yy, z, levels=levels, colors=color, linewidths=1.7)


kde_contour(mg_s, C_MG, [0.15, 0.45, 0.8])
kde_contour(md_s, C_MD, [0.15, 0.45, 0.8])
ax.plot([xmin, xmax], [xmin, xmax], "k--", lw=1.2)
ax.set_xlim(xmin, xmax)
ax.set_ylim(ymin, ymax)
ax.axhline(0, color="0.8", lw=0.6)
ax.axvline(0, color="0.8", lw=0.6)
ax.set_xlabel("Resident-microglia module score\n"
              "(Tmem119, P2ry12, Hexb, Cx3cr1, Sall1, Gpr34, Slc2a5, Siglech)")
ax.set_ylabel("Monocyte-derived module score\n"
              "(Ccr2, Plac8, Ly6c2, Ly6c1, Ifitm1, Fn1, S100a4, Chil3, Cd52)")
ax.set_title("Resident microglia and monocyte-derived cells occupy\n"
             "distinct canonical-marker space (GSE225948; 96.0% agreement)")
ax.text(1.55, -1.05, "Mg", color=C_MG, fontsize=17, weight="bold")
ax.text(-1.05, 1.85, "MdC", color=C_MD, fontsize=17, weight="bold")
ax.legend(loc="upper center", framealpha=0.95, markerscale=4)
ax.grid(ls=":", alpha=0.4)
save(fig, "R4_marker_scorespace")


# ======================================================================
# 4. R4.2b module score 小提琴
# ======================================================================
plot_df = sc[sc["parent"].isin(["Mg", "MdC", "BAM"])].copy()
fig, ax = plt.subplots(figsize=(9.5, 6.5))
cols = {"Mg": C_MG, "MdC": C_MD, "BAM": C_BAM}
for k, lab in enumerate(["Mg", "MdC", "BAM"]):
    for j, score_col in enumerate(["resident_score", "monocyte_score"]):
        v = plot_df.loc[plot_df["parent"] == lab, score_col].values
        pos = k * 2 + j
        parts = ax.violinplot(v, positions=[pos], showmedians=True, widths=0.8)
        for pc in parts["bodies"]:
            pc.set_facecolor(cols[lab])
            pc.set_alpha(0.6 if j == 0 else 0.28)
ax.set_xticks([0, 1, 2, 3, 4, 5])
ax.set_xticklabels(["Mg\nresident", "Mg\nmonocyte", "MdC\nresident",
                    "MdC\nmonocyte", "BAM\nresident", "BAM\nmonocyte"])
ax.set_ylabel("Module score (mean z-scored expression)")
ax.set_title("Resident-microglia vs monocyte-derived module scores\n"
             "Marker-based classification agreement with annotation: 96.0%")
ax.grid(axis="y", ls=":", alpha=0.5)
save(fig, "R4_marker_violin")


# ======================================================================
# 5-7. R4.2c 组成：比例 / 绝对数 / log-ratio（独立面板）
# ======================================================================
psd = pd.read_csv(os.path.join(TD, "composition_per_sample.csv"))
jitter = 0.08


def panel_abundance(value_col, ylabel, title, name):
    fig, ax = plt.subplots(figsize=(6.2, 5.4))
    for t, off, col in [("Mg", -0.18, C_MG), ("MdC", 0.18, C_MD)]:
        means, sds, pts = [], [], []
        for tr in TREATS:
            d = psd[psd["treatment"] == tr]
            means.append(d[value_col.format(t)].mean())
            sds.append(d[value_col.format(t)].std())
            pts.append(d[value_col.format(t)].values)
        means = np.array(means)
        ax.errorbar(X + off, means, yerr=np.array(sds), fmt="o", color=col,
                    lw=2, ms=10, capsize=5, label=t, zorder=3)
        for xi, arr in zip(X, pts):
            rr = np.random.default_rng(1 if t == "Mg" else 2)
            ax.scatter(np.full(len(arr), xi + off) + rr.uniform(-jitter, jitter, len(arr)),
                       arr, color=col, alpha=0.45, s=30, zorder=2)
    ax.set_xticks(X)
    ax.set_xticklabels(TREAT_LAB)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend(framealpha=0.95)
    ax.grid(axis="y", ls=":", alpha=0.5)
    save(fig, name)


panel_abundance("{}_pct", "Proportion of cells (%)",
                "Sample-library proportions (n = 4/group)",
                "R4_composition_proportion")
panel_abundance("{}_n", "Cells recovered per sample library",
                "Recovered cell counts (n = 4 libraries/group)",
                "R4_composition_count")

# log-ratio
fig, ax = plt.subplots(figsize=(6.2, 5.4))
means, sds, pts = [], [], []
for tr in TREATS:
    d = psd[psd["treatment"] == tr]
    means.append(d["logratio_Mg_vs_MdC"].mean())
    sds.append(d["logratio_Mg_vs_MdC"].std())
    pts.append(d["logratio_Mg_vs_MdC"].values)
ax.errorbar(X, means, yerr=np.array(sds), fmt="o", color="#333333",
            lw=2, ms=10, capsize=5, zorder=3)
for xi, arr in zip(X, pts):
    rr = np.random.default_rng(3)
    ax.scatter(np.full(len(arr), xi) + rr.uniform(-jitter, jitter, len(arr)),
               arr, color="#666666", alpha=0.6, s=32, zorder=2)
ax.axhline(0, color="gray", ls="--", lw=1)
ax.set_xticks(X)
ax.set_xticklabels(TREAT_LAB)
ax.set_ylabel("log(Mg / MdC)  (+0.5 pseudocount)")
ax.set_title("Composition-aware log-ratio")
ax.grid(axis="y", ls=":", alpha=0.5)
save(fig, "R4_composition_logratio")


# ======================================================================
# 8-9. R4.2c 亚簇时间轨迹（Mg / MdC 独立面板，放大字号）
# ======================================================================
sub = pd.read_csv(os.path.join(TD, "subcluster_trajectory_per_sample_allcell.csv"))
mg_groups = {"homeostatic": ["Mg1", "Mg2"], "acute reactive": ["Mg4", "Mg5", "Mg8"],
             "late / recovery": ["Mg3", "Mg6", "Mg7"]}
md_groups = {"early infiltrating": ["MdC1", "MdC2"],
             "intermediate": ["MdC3", "MdC4", "MdC5"], "late / recovery": ["MdC6"]}
mg_colors = {"Mg1": "#08306b", "Mg2": "#2171b5", "Mg4": "#4292c6",
             "Mg5": "#6baed6", "Mg8": "#b3d3e8", "Mg3": "#6a51a3",
             "Mg6": "#9e9ac8", "Mg7": "#cbc9e2"}
md_colors = {"MdC1": "#99000d", "MdC2": "#cb181d", "MdC3": "#fb6a4a",
             "MdC4": "#f08c68", "MdC5": "#fcbba1", "MdC6": "#e67e22"}
group_color_mg = {"homeostatic": "#08306b", "acute reactive": "#4292c6",
                  "late / recovery": "#6a51a3"}
group_color_md = {"early infiltrating": "#99000d", "intermediate": "#fb6a4a",
                  "late / recovery": "#e67e22"}


def spread_labels(items, min_gap, ytop):
    """按 Day14 数据 y 排序并撑开，保证标签间距；返回 {name: label_y}。"""
    items = sorted(items, key=lambda t: t[1])
    names = [it[0] for it in items]
    ys = [it[1] for it in items]
    for i in range(1, len(ys)):
        if ys[i] - ys[i - 1] < min_gap:
            ys[i] = ys[i - 1] + min_gap
    top_limit = ytop - 1.0
    if ys[-1] > top_limit:
        shift = ys[-1] - top_limit
        ys = [y - shift for y in ys]
        for i in range(1, len(ys)):
            if ys[i] - ys[i - 1] < min_gap:
                ys[i] = ys[i - 1] + min_gap
    if ys[0] < 0.4:
        shift = 0.4 - ys[0]
        ys = [y + shift for y in ys]
    return dict(zip(names, ys))


def draw_sub(groups_d, colors_d, group_colors, title, ytop, name, bold):
    fig, ax = plt.subplots(figsize=(7.0, 5.8))
    cache = {}
    all_columns = [c for columns in groups_d.values() for c in columns]
    individual_max = sub[all_columns].max().max()
    errorbar_max = max((sub.groupby("treatment")[c].mean() + sub.groupby("treatment")[c].std()).max() for c in all_columns)
    ytop = max(ytop, float(individual_max) * 1.08, float(errorbar_max) * 1.08)
    for gname, subs_list in groups_d.items():
        for sname in subs_list:
            means, sds, pts = [], [], []
            for tr in TREATS:
                d = sub[sub["treatment"] == tr]
                means.append(d[sname].mean())
                sds.append(d[sname].std(ddof=1))
                pts.append(d[sname].values)
            means = np.array(means)
            cache[sname] = means
            lw = 2.1 if sname in bold else 1.2
            ax.errorbar(X, means, yerr=np.array(sds), fmt="-", color=colors_d[sname],
                        lw=lw, capsize=3, elinewidth=1, zorder=3, marker="o",
                        ms=6 if sname in bold else 4.5, mfc=colors_d[sname],
                        mec="white", mew=0.5)
            for xi, arr in zip(X, pts):
                rr = np.random.default_rng(7)
                ax.scatter(np.full(len(arr), xi) + rr.uniform(-0.06, 0.06, len(arr)),
                           arr, s=12, color=colors_d[sname], alpha=0.45,
                           zorder=2, edgecolors="none")
    # 末端直接标签（防重叠 + 引导线）
    label_y = spread_labels([(sname, cache[sname][2]) for sname in cache],
                            min_gap=ytop * 0.058, ytop=ytop)
    for sname in cache:
        data_y = cache[sname][2]
        ax.annotate(sname, xy=(2, data_y), xytext=(2.1, label_y[sname]),
                    fontsize=9.5, color=colors_d[sname], va="center",
                    fontweight="bold" if sname in bold else "normal",
                    arrowprops=dict(arrowstyle="-", color=colors_d[sname],
                                    lw=0.7, alpha=0.8, shrinkA=1, shrinkB=2))
    ax.set_xticks(X)
    ax.set_xticklabels(["Sham", "Day 2", "Day 14"])
    ax.set_ylim(0, ytop)
    ax.set_xlim(-0.3, 2.95)
    ax.set_ylabel("Fraction of all cells (%)")
    ax.set_title(title)
    handles = [Line2D([0], [0], color=group_colors[g], lw=3, label=g)
               for g in groups_d]
    ax.legend(handles=handles, loc="upper right", framealpha=0.95)
    ax.grid(axis="y", ls=":", alpha=0.4, lw=0.6)
    ax.text(0.02, 0.97, "n = 4 pooled libraries/group", transform=ax.transAxes,
            fontsize=9.5, va="top", color="0.35")
    save(fig, name)


draw_sub(mg_groups, mg_colors, group_color_mg,
         "Resident microglia subclusters (Mg1–8)", 44,
         "R4_subcluster_mg", {"Mg1", "Mg2", "Mg3", "Mg4", "Mg5"})
draw_sub(md_groups, md_colors, group_color_md,
         "Monocyte-derived subclusters (MdC1–6)", 20,
         "R4_subcluster_mdc", {"MdC1", "MdC2", "MdC6"})

print("\nALL DONE. output folder:", OUT)
