# -*- coding: utf-8 -*-
"""R2.6 cross-cohort replication null:
Is the curated set's cross-cohort DIRECTION REPLICATION (the paper's actual claim)
greater than expression-matched random gene sets? Uses the 3 bulk cohorts.
Thirty bins are defined from non-curated background mean expression ranks,
then applied unchanged to curated genes. Outer bin edges are unbounded.
Each of 2,000 draws selects one control per curated gene, with replacement
across target slots. Empty bins use the eight nearest background genes."""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
import sys, pandas as pd, numpy as np
sys.stdout.reconfigure(encoding="utf-8")
rng = np.random.default_rng(20261027)
BULK = str(ROOT / 'data/main_tables/01_bulk_transcriptomics')
OUT = str(ROOT / 'outputs/revision_R4/tables')
Path(OUT).mkdir(parents=True, exist_ok=True)
RL_MOUSE=["Rnaseh1","Rnaseh2a","Rnaseh2b","Rnaseh2c","Top1","Top1mt","Setx","Dhx9","Ddx1","Ddx3x",
 "Ddx5","Ddx19","Ddx21","Aqr","Pif1","Fancm","Brca1","Brca2","Fancd2","Atr","Atm","Parp1",
 "Thoc1","Thoc2","Thoc3","Thoc5","Thoc6","Thoc7","Xrn2","Prmt5","Bcl7b","Vdac1"]
RL=set(g.upper() for g in RL_MOUSE)
cfg={"GSE163614":("GSE163614_DESeq2_results.csv.gz","log2FoldChange","baseMean"),
     "GSE137482":("GSE137482_DESeq2_results.csv.gz","log2FoldChange","baseMean"),
     "GSE61616":("GSE61616_limma_results.csv.gz","logFC","AveExpr")}
M={}
for ds,(f,fc,ex) in cfg.items():
    d=pd.read_csv(BULK+"/"+f); d["HG"]=d["gene"].str.upper()
    d=d.dropna(subset=[fc])
    d=d.reindex(d[fc].abs().sort_values(ascending=False).index).drop_duplicates("HG")
    d["exprRank"]=d[ex].rank(pct=True)
    M[ds]=d.set_index("HG")[[fc,"exprRank"]]
common=set(M["GSE163614"].index)&set(M["GSE137482"].index)&set(M["GSE61616"].index)
print("三队列共同检测基因:",len(common))
rows=[]
for g in sorted(common):
    fc=[M[ds].loc[g,M[ds].columns[0]] for ds in cfg]
    er=[M[ds].loc[g,"exprRank"] for ds in cfg]
    rows.append((g,*fc,np.mean(er),int(np.all(np.sign(fc)>0)),int(np.all(np.sign(fc)<0)),
                 int(np.sign(fc[0])==np.sign(fc[1])==np.sign(fc[2]))))
tab=pd.DataFrame(rows,columns=["HG","fc163","fc137","fc616","meanExprRank","all_up","all_down","all_sameSign"])
rl_tab=tab[tab.HG.isin(RL)].copy()
print("32基因中三队列都检测:",len(rl_tab))
print(rl_tab[["HG","fc163","fc137","fc616","all_up","all_sameSign"]].to_string(index=False))
obs=dict(all_up=rl_tab.all_up.mean(), all_same=rl_tab.all_sameSign.mean(),
         meanFC=rl_tab[["fc163","fc137","fc616"]].values.flatten().mean())
print("\nOBSERVED 32: frac all-up=%.3f  frac same-sign=%.3f  pooled meanFC=%.3f"%(obs["all_up"],obs["all_same"],obs["meanFC"]))
pool=tab[~tab.HG.isin(RL)].copy()
nbins=30
_, edges = pd.qcut(pool.meanExprRank, nbins, retbins=True, duplicates="drop")
edges[0], edges[-1] = -np.inf, np.inf
pool["bin"] = pd.cut(pool.meanExprRank, edges, labels=False, include_lowest=True)
rl_bins = pd.cut(rl_tab.meanExprRank, edges, labels=False, include_lowest=True)
if rl_bins.isna().any():
    raise ValueError("Non-finite target mean expression rank prevents matching")
candidates = []
for i, b in enumerate(rl_bins):
    cand = pool[pool["bin"] == b]
    if cand.empty:
        distance = (pool.meanExprRank - rl_tab.meanExprRank.iloc[i]).abs()
        cand = pool.loc[distance.sort_values(kind="stable").index[:8]]
    candidates.append(cand)
n=len(rl_tab); B=2000
null={k:[] for k in ["all_up","all_same","meanFC"]}
for it in range(B):
    pick=[]
    for cand in candidates:
        pick.append(cand.sample(1,random_state=rng.integers(1e9)))
    c=pd.concat(pick)
    null["all_up"].append(c.all_up.mean()); null["all_same"].append(c.all_sameSign.mean())
    null["meanFC"].append(c[["fc163","fc137","fc616"]].values.flatten().mean())
def ep(o,a): return float((1+np.sum(np.array(a)>=o))/(B+1))
out=[]
for k in ["all_up","all_same","meanFC"]:
    arr=np.array(null[k])
    print(f"{k:10s} obs={obs[k]:.3f} null={arr.mean():.3f} 95%CI=({np.percentile(arr,2.5):.3f},{np.percentile(arr,97.5):.3f}) empirical p={ep(obs[k],arr):.4f}")
    out.append((k,obs[k],arr.mean(),np.percentile(arr,2.5),np.percentile(arr,97.5),ep(obs[k],arr)))
pd.DataFrame(out,columns=["metric","observed32","null_mean","null_CIlo","null_CIhi","empirical_p"]).to_csv(OUT+"/R2_6_crosscohort_replication_null.csv",index=False)
print("\nSaved.")
