# -*- coding: utf-8 -*-
"""R2.6:
(a) expression-matched control gene sets (1000 draws) vs curated 32 R-loop genes;
(b) curated 32 vs broader GO RNA-processing / DNA-repair / ribosome / immune signatures.
Metrics: DE fraction, up-regulated fraction, median |log2FC|, mean signed log2FC."""

from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
import sys, pandas as pd, numpy as np
sys.stdout.reconfigure(encoding="utf-8")
rng = np.random.default_rng(20261027)

ANN = ROOT / 'data/reference/human_GO_BP_genes.csv.gz'
BULK = str(ROOT / 'data/main_tables/01_bulk_transcriptomics')
OUT = str(ROOT / 'outputs/revision_R4/tables')
Path(OUT).mkdir(parents=True, exist_ok=True)

RL_MOUSE = ["Rnaseh1","Rnaseh2a","Rnaseh2b","Rnaseh2c","Top1","Top1mt","Setx","Dhx9","Ddx1","Ddx3x",
 "Ddx5","Ddx19","Ddx21","Aqr","Pif1","Fancm","Brca1","Brca2","Fancd2","Atr","Atm","Parp1",
 "Thoc1","Thoc2","Thoc3","Thoc5","Thoc6","Thoc7","Xrn2","Prmt5","Bcl7b","Vdac1"]
RL = set(g.upper() for g in RL_MOUSE)

go = pd.read_csv(ANN); go["SYMBOL"]=go["SYMBOL"].str.upper()
term_name = go.drop_duplicates("GO").set_index("GO")["TERM"].to_dict()
term_genes = go.groupby("GO")["SYMBOL"].apply(set).to_dict()

SIG = {
 "RNA processing (GO:0006396)":"GO:0006396",
 "mRNA processing (GO:0006397)":"GO:0006397",
 "DNA repair (GO:0006281)":"GO:0006281",
 "translation (GO:0006412)":"GO:0006412",
 "ribosome biogenesis (GO:0042254)":"GO:0042254",
 "immune response (GO:0006955)":"GO:0006955",
 "inflammatory response (GO:0006954)":"GO:0006954",
}

DATASETS = {
 "GSE163614": dict(f="GSE163614_DESeq2_results.csv.gz", fc="log2FoldChange", p="padj", expr="baseMean"),
 "GSE137482": dict(f="GSE137482_DESeq2_results.csv.gz", fc="log2FoldChange", p="padj", expr="baseMean"),
 "GSE61616":  dict(f="GSE61616_limma_results.csv.gz", fc="logFC", p="adj.P.Val", expr="AveExpr"),
}

def metrics(sub):
    return dict(
        n=len(sub),
        DE_frac=float((sub["isDE"]).mean()),
        up_frac=float((sub[fc]>0).mean()),
        med_absFC=float(sub[fc].abs().median()),
        mean_FC=float(sub[fc].mean()),
    )

matched_rows=[]; sig_rows=[]
for ds,cfg in DATASETS.items():
    fc=cfg["fc"]; p=cfg["p"]; ex=cfg["expr"]
    df=pd.read_csv(BULK+"/"+cfg["f"])
    df["HG"]=df["gene"].str.upper()
    df=df.dropna(subset=[p]).copy()
    df["logExpr"]=np.log10(df[ex].clip(lower=df[ex][df[ex]>0].min()))
    df["isDE"]=df[p]<0.05
    rl_det = df[df.HG.isin(RL)].copy()
    pool = df[~df.HG.isin(RL)].copy()
    print(f"\n{'='*95}\n{ds}: 32-gene members detected = {len(rl_det)} / 32 ; background pool = {len(pool)}")
    obs = metrics(rl_det)
    print(f"  OBSERVED 32: DE={obs['DE_frac']:.3f} up={obs['up_frac']:.3f} med|FC|={obs['med_absFC']:.3f} meanFC={obs['mean_FC']:.3f}")
    # ---- (a) expression-matched null, 1000 draws (bin-based) ----
    nbins=50
    pool["bin"]=pd.qcut(pool["logExpr"], nbins, labels=False, duplicates="drop")
    rl_bins=pd.qcut(rl_det["logExpr"], nbins, labels=False, duplicates="drop")
    null={k:[] for k in ["DE_frac","up_frac","med_absFC","mean_FC"]}
    for it in range(1000):
        pick=[]
        for b in rl_bins:
            cand=pool[pool["bin"]==b]
            if len(cand)==0:
                cand=pool.iloc[(pool["logExpr"]-rl_det["logExpr"].iloc[len(pick)]).abs().argsort().iloc[:5]]
            pick.append(cand.sample(1, random_state=rng.integers(1e9)))
        ctrl=pd.concat(pick)
        m=metrics(ctrl)
        for k in null: null[k].append(m[k])
    def ep(obs_v, arr, higher=True):
        arr=np.array(arr)
        return float((1+np.sum(arr>=obs_v if higher else arr<=obs_v))/(len(arr)+1))
    for k in ["DE_frac","up_frac","med_absFC","mean_FC"]:
        arr=np.array(null[k])
        matched_rows.append((ds,k,obs[k],arr.mean(),arr.std(),np.percentile(arr,[2.5,97.5])[0],np.percentile(arr,[2.5,97.5])[1],
                             ep(obs[k],arr,higher=True), float(np.mean(arr>=obs[k]))))
    print(f"  NULL(matched) DE={np.mean(null['DE_frac']):.3f} up={np.mean(null['up_frac']):.3f} med|FC|={np.mean(null['med_absFC']):.3f} meanFC={np.mean(null['mean_FC']):.3f}")
    # ---- (b) broader signatures ----
    for sname,gid in SIG.items():
        sg = term_genes[gid] & set(df.HG)
        ssub = df[df.HG.isin(sg)]
        m=metrics(ssub)
        # exclude the curated 32 overlap for fairness? report overlap size
        overlap = len(sg & set(rl_det.HG))
        sig_rows.append((ds,sname,len(ssub),overlap,m["DE_frac"],m["up_frac"],m["med_absFC"],m["mean_FC"]))
        print(f"  SIG {sname:34s} n={len(ssub):5d} overlap32={overlap:2d} DE={m['DE_frac']:.3f} up={m['up_frac']:.3f} med|FC|={m['med_absFC']:.3f} meanFC={m['mean_FC']:.3f}")

mm=pd.DataFrame(matched_rows,columns=["dataset","metric","observed32","null_mean","null_sd","null_CIlo","null_CIhi","empirical_p_oneSided","frac_null_ge_obs"])
mm.to_csv(OUT+"/R2_6_expression_matched_controls.csv",index=False)
ss=pd.DataFrame(sig_rows,columns=["dataset","signature","n_genes","overlap_with_32","DE_frac","up_frac","med_absFC","mean_FC"])
ss.to_csv(OUT+"/R2_6_broad_signature_comparison.csv",index=False)

print("\n\n===== Empirical p (expression-matched, one-sided higher) =====")
for ds in DATASETS:
    print(f"\n{ds}:")
    for r in mm[mm.dataset==ds].itertuples():
        print(f"  {r.metric:12s} obs={r.observed32:7.3f}  null={r.null_mean:7.3f} ({r.null_CIlo:7.3f},{r.null_CIhi:7.3f})  p={r.empirical_p_oneSided:.4f}")
print("\nSaved.")
