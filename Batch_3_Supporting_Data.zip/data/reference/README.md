# Reference inputs for revision analyses

`human_GO_BP_genes.csv.gz` is the supplied human GO biological-process gene
annotation snapshot (columns GO, SYMBOL, TERM), retained without modification.
The original database version and retrieval date were not recorded. Revision
code uppercases rodent symbols to compare against this human-symbol table;
this is the historical matching heuristic, not full orthology inference.

`GSE225948_lineage_markers.csv.gz` contains 34 lineage-marker rows and 43,269
metadata-aligned cell columns extracted from the 12 released brain sample
matrices GSM7060815–GSM7060826 in
[GSE225948](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE225948).
Cell identifiers are the sample accession plus the released cell barcode.
Expression values are copied from the source CSVs without normalization or
statistical processing. `scripts/revision_R4/extract_lineage_marker_inputs.py`
provides the exact extraction method. The later lineage analysis applies
`log1p` to these values and defines the marker groups in its source code.

`lineage_source_manifest.csv` records source filenames and SHA256 checksums.
The large original matrices are not duplicated in this repository. These are
reused public mouse data, governed by the source dataset's terms and attribution.


`hichip_source_manifest.csv` records the two omitted public HiChIP interaction files, including source accession, expected size, and SHA256 checksum. Download and extract the archive before running the HiChIP script.
